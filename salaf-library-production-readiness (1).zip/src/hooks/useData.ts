import { useState } from 'react';
import booksData from '../../public/data/books.json';
import scholarsData from '../../public/data/scholars.json';
import categoriesData from '../../public/data/categories.json';

// Import JSON directly for single-file build compatibility
// This ensures all data is embedded in the bundle

export function useBooks() {
  const [books] = useState<any[]>(booksData);
  const [loading] = useState(false);
  const [error] = useState<string | null>(null);
  return { books, loading, error };
}

export function useScholars() {
  const [scholars] = useState<any[]>(scholarsData);
  const [loading] = useState(false);
  const [error] = useState<string | null>(null);
  return { scholars, loading, error };
}

export function useCategories() {
  const [categories] = useState<any[]>(categoriesData);
  const [loading] = useState(false);
  const [error] = useState<string | null>(null);
  return { categories, loading, error };
}
