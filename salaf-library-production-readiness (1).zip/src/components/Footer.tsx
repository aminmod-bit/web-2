import { Link } from 'react-router-dom';
import { BookOpen, Heart, ExternalLink } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#07182e] border-t border-amber-900/20 text-slate-400" dir="rtl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-amber-300 font-bold text-lg font-arabic">مكتبة السلف</p>
                <p className="text-slate-500 text-xs tracking-widest uppercase">Salaf Library</p>
              </div>
            </div>
            <p className="text-slate-500 text-sm leading-relaxed max-w-xs">
              مكتبة إسلامية رقمية تُعنى بنشر التراث العلمي لأئمة السلف الصالح رحمهم الله.
            </p>
            <div className="flex items-center gap-1 mt-4 text-xs text-slate-600">
              <span>صُنع بـ</span>
              <Heart className="w-3 h-3 text-red-500 fill-red-500" />
              <span>لخدمة طلاب العلم</span>
            </div>
          </div>

          {/* Links */}
          <div>
            <h3 className="text-amber-400 font-semibold text-sm mb-4">المحتوى</h3>
            <ul className="space-y-2">
              {[
                { to: '/books', label: 'الكتب' },
                { to: '/categories', label: 'التصنيفات' },
                { to: '/scholars', label: 'العلماء' },
                { to: '/search', label: 'البحث' },
              ].map(link => (
                <li key={link.to}>
                  <Link to={link.to} className="text-sm hover:text-amber-300 transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Info */}
          <div>
            <h3 className="text-amber-400 font-semibold text-sm mb-4">معلومات</h3>
            <ul className="space-y-2">
              {[
                { to: '/about', label: 'حول المكتبة' },
              ].map(link => (
                <li key={link.to}>
                  <Link to={link.to} className="text-sm hover:text-amber-300 transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
              <li>
                <a
                  href="https://github.com/aminmod-bit/web-2"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm hover:text-amber-300 transition-colors flex items-center gap-1"
                >
                  <span>GitHub</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a href="/sitemap.xml" className="text-sm hover:text-amber-300 transition-colors">
                  خريطة الموقع
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 mt-8 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-slate-600">
            © {new Date().getFullYear()} مكتبة السلف · جميع الحقوق محفوظة
          </p>
          <p className="text-xs text-slate-700 font-mono">v1.0.0 · Production Build</p>
        </div>
      </div>
    </footer>
  );
}
