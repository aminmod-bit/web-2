import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, BookOpen, Search } from 'lucide-react';

const navLinks = [
  { to: '/', label: 'الرئيسية' },
  { to: '/books', label: 'المكتبة' },
  { to: '/categories', label: 'التصنيفات' },
  { to: '/scholars', label: 'العلماء' },
  { to: '/search', label: 'البحث' },
  { to: '/about', label: 'حول المكتبة' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  return (
    <header className="sticky top-0 z-50 bg-[#0f2a4a]/95 backdrop-blur-md border-b border-amber-900/30 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
            <div className="flex flex-col leading-none">
              <span className="text-amber-300 font-bold text-base tracking-wide font-arabic">مكتبة السلف</span>
              <span className="text-slate-400 text-[10px] tracking-widest uppercase">Salaf Library</span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1" dir="rtl">
            {navLinks.map(link => (
              <Link
                key={link.to}
                to={link.to}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  location.pathname === link.to
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'text-slate-300 hover:text-amber-300 hover:bg-white/5'
                }`}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Right: Search icon + hamburger */}
          <div className="flex items-center gap-2">
            <Link
              to="/search"
              className="p-2 rounded-lg text-slate-400 hover:text-amber-300 hover:bg-white/5 transition-colors"
              aria-label="بحث"
            >
              <Search className="w-5 h-5" />
            </Link>
            <button
              className="md:hidden p-2 rounded-lg text-slate-400 hover:text-amber-300 hover:bg-white/5 transition-colors"
              onClick={() => setOpen(!open)}
              aria-label="القائمة"
            >
              {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-[#0c2240] border-t border-amber-900/20 px-4 py-3" dir="rtl">
          <nav className="flex flex-col gap-1">
            {navLinks.map(link => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setOpen(false)}
                className={`px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                  location.pathname === link.to
                    ? 'bg-amber-500/20 text-amber-300'
                    : 'text-slate-300 hover:bg-white/5 hover:text-amber-300'
                }`}
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
