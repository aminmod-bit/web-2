import { Star, Download, FileText, BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';

interface Props {
  book: {
    id: number;
    title: string;
    author: string;
    category: string;
    year: string;
    pages: number;
    description: string;
    rating: number;
    downloads: number;
    featured?: boolean;
    new?: boolean;
  };
}

export default function BookCard({ book }: Props) {
  const colors: Record<string, string> = {
    'حديث': 'bg-blue-500/10 text-blue-300 border-blue-500/20',
    'تفسير': 'bg-green-500/10 text-green-300 border-green-500/20',
    'فقه': 'bg-purple-500/10 text-purple-300 border-purple-500/20',
    'عقيدة': 'bg-amber-500/10 text-amber-300 border-amber-500/20',
    'سيرة': 'bg-teal-500/10 text-teal-300 border-teal-500/20',
    'تزكية': 'bg-pink-500/10 text-pink-300 border-pink-500/20',
    'أصول الفقه': 'bg-orange-500/10 text-orange-300 border-orange-500/20',
    'شروح': 'bg-indigo-500/10 text-indigo-300 border-indigo-500/20',
  };

  const catColor = colors[book.category] || 'bg-slate-500/10 text-slate-300 border-slate-500/20';

  return (
    <Link
      to={`/books/${book.id}`}
      className="group block bg-[#0c2240]/80 border border-slate-700/40 rounded-2xl overflow-hidden hover:border-amber-500/40 hover:shadow-xl hover:shadow-amber-900/10 transition-all duration-300 hover:-translate-y-1"
      dir="rtl"
    >
      {/* Cover placeholder */}
      <div className="relative h-40 bg-gradient-to-br from-[#0f2a4a] to-[#0a1e35] flex items-center justify-center overflow-hidden">
        <BookOpen className="w-16 h-16 text-amber-900/30 group-hover:text-amber-800/50 transition-colors" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0c2240] to-transparent" />
        
        {/* Badges */}
        <div className="absolute top-3 right-3 flex flex-col gap-1">
          {book.featured && (
            <span className="px-2 py-0.5 bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[10px] rounded-full">
              مميز
            </span>
          )}
          {book.new && (
            <span className="px-2 py-0.5 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[10px] rounded-full">
              جديد
            </span>
          )}
        </div>

        {/* Category badge */}
        <div className="absolute bottom-3 right-3">
          <span className={`px-2 py-0.5 border text-[11px] rounded-full ${catColor}`}>
            {book.category}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <h3 className="text-amber-100 font-bold text-base leading-snug mb-1 group-hover:text-amber-300 transition-colors line-clamp-2">
          {book.title}
        </h3>
        <p className="text-slate-500 text-xs mb-3 line-clamp-1">{book.author}</p>
        <p className="text-slate-500 text-xs leading-relaxed line-clamp-2 mb-4">{book.description}</p>

        {/* Meta */}
        <div className="flex items-center justify-between text-xs text-slate-600">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
              <span className="text-amber-400">{book.rating}</span>
            </span>
            <span className="flex items-center gap-1">
              <FileText className="w-3 h-3" />
              <span>{book.pages.toLocaleString('ar-EG')} ص</span>
            </span>
          </div>
          <span className="flex items-center gap-1">
            <Download className="w-3 h-3" />
            <span>{(book.downloads / 1000).toFixed(0)}k</span>
          </span>
        </div>
      </div>
    </Link>
  );
}
