import { BookOpen, Shield, Heart, Globe, Smartphone, Zap } from 'lucide-react';

export default function About() {
  const features = [
    {
      icon: BookOpen,
      title: 'مكتبة شاملة',
      desc: 'تضم مئات الكتب والمراجع العلمية لأئمة السلف في شتى فنون العلم الشرعي',
    },
    {
      icon: Shield,
      title: 'محتوى موثوق',
      desc: 'جميع الكتب من المصادر الأصيلة المعتمدة، مع توثيق دقيق للمؤلف والطبعة',
    },
    {
      icon: Globe,
      title: 'وصول مفتوح',
      desc: 'متاح للجميع مجانًا دون قيود، في أي مكان وأي وقت',
    },
    {
      icon: Smartphone,
      title: 'متوافق مع كل الأجهزة',
      desc: 'يعمل بسلاسة على الحاسوب والجوال والتابلت بجميع أحجام الشاشات',
    },
    {
      icon: Zap,
      title: 'سريع وخفيف',
      desc: 'مبني بأحدث التقنيات لضمان سرعة التحميل وتجربة مستخدم مميزة',
    },
    {
      icon: Heart,
      title: 'خدمة طلاب العلم',
      desc: 'هدفنا الأسمى نشر العلم الشرعي الصحيح وتيسير الوصول إليه',
    },
  ];

  return (
    <div className="min-h-screen bg-[#0a1e35]" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#07182e] to-[#0f2a4a] border-b border-amber-900/20 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center mx-auto mb-6 shadow-xl shadow-amber-900/30">
            <BookOpen className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-4">حول مكتبة السلف</h1>
          <p className="text-slate-400 text-lg leading-relaxed">
            مشروع رقمي لنشر التراث العلمي الإسلامي الأصيل
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        {/* Mission */}
        <div className="bg-[#0c2240]/80 border border-slate-700/40 rounded-2xl p-8 mb-10">
          <h2 className="text-xl font-bold text-amber-300 mb-4">رسالتنا</h2>
          <p className="text-slate-300 leading-loose text-base">
            مكتبة السلف مشروع رقمي يهدف إلى الحفاظ على التراث العلمي لأئمة السلف الصالح 
            ونشره بصورة رقمية حديثة تُيسّر وصول طلاب العلم إليه في أي مكان وأي وقت.
            نؤمن بأن العلم الشرعي الأصيل هو السبيل لفهم الإسلام على بصيرة، 
            وأن تيسيره للناس من أعظم القربات.
          </p>
        </div>

        {/* Features */}
        <h2 className="text-xl font-bold text-white mb-6">مميزات المكتبة</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-14">
          {features.map(f => (
            <div
              key={f.title}
              className="bg-[#0c2240]/60 border border-slate-700/30 rounded-2xl p-5"
            >
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mb-4">
                <f.icon className="w-5 h-5 text-amber-400" />
              </div>
              <h3 className="text-amber-100 font-semibold mb-2">{f.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>

        {/* Tech stack */}
        <div className="bg-[#0c2240]/60 border border-slate-700/30 rounded-2xl p-6">
          <h2 className="text-lg font-bold text-white mb-4">التقنيات المستخدمة</h2>
          <div className="flex flex-wrap gap-3">
            {['React 19', 'TypeScript', 'Vite 7', 'Tailwind CSS 4', 'React Router v7', 'PWA', 'GitHub Pages'].map(tech => (
              <span
                key={tech}
                className="px-3 py-1.5 bg-white/5 border border-white/10 text-slate-400 text-xs rounded-xl font-mono"
              >
                {tech}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
