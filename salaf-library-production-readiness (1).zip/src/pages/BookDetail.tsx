import { useParams, Link } from 'react-router-dom';
import { ArrowRight, Star, FileText, Download, Tag, Calendar, User, BookOpen } from 'lucide-react';
import { useBooks } from '../hooks/useData';
import LoadingSpinner from '../components/LoadingSpinner';

const COLORS: Record<string, string> = {
  'حديث': 'text-blue-300 bg-blue-500/10 border-blue-500/20',
  'تفسير': 'text-green-300 bg-green-500/10 border-green-500/20',
  'فقه': 'text-purple-300 bg-purple-500/10 border-purple-500/20',
  'عقيدة': 'text-amber-300 bg-amber-500/10 border-amber-500/20',
  'سيرة': 'text-teal-300 bg-teal-500/10 border-teal-500/20',
  'تزكية': 'text-pink-300 bg-pink-500/10 border-pink-500/20',
  'أصول الفقه': 'text-orange-300 bg-orange-500/10 border-orange-500/20',
  'شروح': 'text-indigo-300 bg-indigo-500/10 border-indigo-500/20',
};

export default function BookDetail() {
  const { id } = useParams<{ id: string }>();
  const { books, loading } = useBooks();

  if (loading) return <div className="min-h-screen bg-[#0a1e35]"><LoadingSpinner message="جارٍ تحميل بيانات الكتاب..." /></div>;

  const book = books.find(b => b.id === Number(id));
  if (!book) {
    return (
      <div className="min-h-screen bg-[#0a1e35] flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <BookOpen className="w-20 h-20 text-slate-700 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">الكتاب غير موجود</h2>
          <p className="text-slate-500 mb-6">لم يتم العثور على الكتاب المطلوب</p>
          <Link to="/books" className="px-5 py-2.5 bg-amber-500 text-white rounded-xl hover:bg-amber-400 transition-colors">
            العودة إلى المكتبة
          </Link>
        </div>
      </div>
    );
  }

  const catColor = COLORS[book.category] || 'text-slate-300 bg-slate-500/10 border-slate-500/20';

  return (
    <div className="min-h-screen bg-[#0a1e35]" dir="rtl">
      {/* Breadcrumb */}
      <div className="bg-[#07182e] border-b border-amber-900/20 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <Link to="/" className="hover:text-amber-300 transition-colors">الرئيسية</Link>
            <ArrowRight className="w-3 h-3 rotate-180" />
            <Link to="/books" className="hover:text-amber-300 transition-colors">المكتبة</Link>
            <ArrowRight className="w-3 h-3 rotate-180" />
            <span className="text-slate-400 line-clamp-1">{book.title}</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Left sidebar: Cover & meta */}
          <div className="space-y-6">
            {/* Cover */}
            <div className="bg-gradient-to-br from-[#0f2a4a] to-[#07182e] border border-slate-700/40 rounded-2xl h-72 flex items-center justify-center shadow-xl">
              <BookOpen className="w-24 h-24 text-amber-800/40" />
            </div>

            {/* Meta */}
            <div className="bg-[#0c2240]/80 border border-slate-700/40 rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2">
                <span className={`px-3 py-1 rounded-full border text-xs ${catColor}`}>{book.category}</span>
              </div>
              {[
                { icon: User, label: 'المؤلف', value: book.author },
                { icon: Calendar, label: 'سنة الوفاة', value: book.year },
                { icon: FileText, label: 'عدد الصفحات', value: `${book.pages.toLocaleString('ar-EG')} صفحة` },
                { icon: Star, label: 'التقييم', value: `${book.rating} / 5.0` },
                { icon: Download, label: 'مرات التحميل', value: `${book.downloads.toLocaleString('ar-EG')}` },
              ].map(item => (
                <div key={item.label} className="flex items-start gap-3">
                  <item.icon className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-xs text-slate-500">{item.label}</p>
                    <p className="text-sm text-slate-300">{item.value}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Download button */}
            <button className="w-full flex items-center justify-center gap-2 py-3 bg-amber-500 hover:bg-amber-400 text-white font-semibold rounded-xl transition-all shadow-lg shadow-amber-900/20">
              <Download className="w-5 h-5" />
              <span>تحميل الكتاب</span>
            </button>
          </div>

          {/* Main content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Title */}
            <div>
              {book.featured && (
                <span className="inline-block px-2 py-0.5 bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs rounded-full mb-3">
                  كتاب مميز
                </span>
              )}
              <h1 className="text-3xl md:text-4xl font-bold text-amber-100 mb-2 leading-snug">{book.title}</h1>
              <p className="text-slate-400 text-lg">{book.author}</p>
            </div>

            {/* Description */}
            <div className="bg-[#0c2240]/60 border border-slate-700/30 rounded-2xl p-6">
              <h2 className="text-amber-400 font-semibold mb-4 flex items-center gap-2">
                <BookOpen className="w-4 h-4" />
                عن الكتاب
              </h2>
              <p className="text-slate-300 leading-loose text-base">{book.description}</p>
            </div>

            {/* Tags */}
            {book.tags && book.tags.length > 0 && (
              <div className="bg-[#0c2240]/60 border border-slate-700/30 rounded-2xl p-6">
                <h2 className="text-amber-400 font-semibold mb-4 flex items-center gap-2">
                  <Tag className="w-4 h-4" />
                  الكلمات المفتاحية
                </h2>
                <div className="flex flex-wrap gap-2">
                  {(book.tags as string[]).map((tag: string) => (
                    <span key={tag} className="px-3 py-1 bg-white/5 border border-white/10 text-slate-400 text-xs rounded-full hover:border-amber-500/30 hover:text-amber-300 transition-colors cursor-default">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Rating visual */}
            <div className="bg-[#0c2240]/60 border border-slate-700/30 rounded-2xl p-6">
              <h2 className="text-amber-400 font-semibold mb-4 flex items-center gap-2">
                <Star className="w-4 h-4" />
                تقييم الكتاب
              </h2>
              <div className="flex items-center gap-3">
                <span className="text-5xl font-bold text-amber-300">{book.rating}</span>
                <div>
                  <div className="flex gap-1 mb-1">
                    {[1,2,3,4,5].map(i => (
                      <Star
                        key={i}
                        className={`w-5 h-5 ${i <= Math.floor(book.rating) ? 'text-amber-400 fill-amber-400' : 'text-slate-600'}`}
                      />
                    ))}
                  </div>
                  <p className="text-slate-500 text-xs">{book.downloads.toLocaleString('ar-EG')} قارئ</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
