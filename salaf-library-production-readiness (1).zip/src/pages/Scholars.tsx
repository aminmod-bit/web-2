import { Link } from 'react-router-dom';
import { Users, BookOpen } from 'lucide-react';
import { useScholars, useBooks } from '../hooks/useData';
import LoadingSpinner from '../components/LoadingSpinner';

export default function Scholars() {
  const { scholars, loading, error } = useScholars();
  const { books } = useBooks();

  return (
    <div className="min-h-screen bg-[#0a1e35]" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#07182e] to-[#0f2a4a] border-b border-amber-900/20 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 mb-2">
            <Users className="w-6 h-6 text-amber-400" />
            <h1 className="text-3xl font-bold text-white">أعلام العلماء</h1>
          </div>
          <p className="text-slate-400 text-sm">تعرّف على كبار علماء السلف الصالح وتراثهم العلمي</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {loading ? <LoadingSpinner /> : error ? (
          <div className="text-center text-red-400 py-20">{error}</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {scholars.map((scholar: any) => {
              const scholarBooks = books.filter((b: any) => scholar.books.includes(b.id));
              return (
                <div
                  key={scholar.id}
                  className="bg-[#0c2240]/80 border border-slate-700/40 rounded-2xl p-6 hover:border-amber-500/40 hover:shadow-xl hover:shadow-amber-900/10 transition-all duration-300"
                >
                  {/* Avatar */}
                  <div className="flex items-center gap-4 mb-5">
                    <div className="w-14 h-14 rounded-full bg-gradient-to-br from-amber-500/20 to-amber-700/20 border border-amber-500/30 flex items-center justify-center text-amber-300 text-xl font-bold shrink-0">
                      {scholar.name.charAt(scholar.name.indexOf(' ') + 1) || '؟'}
                    </div>
                    <div>
                      <h3 className="text-amber-100 font-bold text-base leading-snug">{scholar.name}</h3>
                      <p className="text-slate-500 text-xs">{scholar.nameEn}</p>
                    </div>
                  </div>

                  {/* Dates */}
                  <div className="flex gap-4 mb-4 text-xs text-slate-500">
                    <div>
                      <span className="text-slate-600">وُلد: </span>
                      <span>{scholar.born}</span>
                    </div>
                    <div>
                      <span className="text-slate-600">توفي: </span>
                      <span>{scholar.died}</span>
                    </div>
                  </div>

                  {/* Specialization */}
                  <div className="inline-block px-2.5 py-1 bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs rounded-full mb-4">
                    {scholar.specialization}
                  </div>

                  {/* Bio */}
                  <p className="text-slate-400 text-sm leading-relaxed mb-5">{scholar.bio}</p>

                  {/* Books */}
                  {scholarBooks.length > 0 && (
                    <div>
                      <p className="text-slate-500 text-xs mb-2 flex items-center gap-1">
                        <BookOpen className="w-3 h-3" />
                        مؤلفاته في المكتبة
                      </p>
                      <div className="flex flex-col gap-1">
                        {scholarBooks.map((b: any) => (
                          <Link
                            key={b.id}
                            to={`/books/${b.id}`}
                            className="text-xs text-amber-400 hover:text-amber-300 transition-colors flex items-center gap-1"
                          >
                            <span>◈</span>
                            <span className="line-clamp-1">{b.title}</span>
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
