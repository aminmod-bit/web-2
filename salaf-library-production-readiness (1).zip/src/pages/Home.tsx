import { lazy, Suspense } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Search, ChevronLeft, Sparkles, TrendingUp, Clock } from 'lucide-react';
import { useBooks } from '../hooks/useData';
import LoadingSpinner from '../components/LoadingSpinner';

const BookCard = lazy(() => import('../components/BookCard'));

function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-[#07182e] via-[#0f2a4a] to-[#0c2240] py-20 md:py-32" dir="rtl">
      {/* Decorative */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-24 -left-24 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-amber-400/3 rounded-full blur-3xl" />
      </div>

      {/* Arabic calligraphy pattern */}
      <div className="absolute inset-0 opacity-[0.02] pointer-events-none select-none" aria-hidden="true">
        <div className="absolute top-8 right-8 text-[200px] text-amber-300 font-arabic leading-none">و</div>
        <div className="absolute bottom-8 left-8 text-[150px] text-amber-300 font-arabic leading-none rotate-12">ع</div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-amber-500/10 border border-amber-500/20 rounded-full text-amber-300 text-xs mb-6">
            <Sparkles className="w-3.5 h-3.5" />
            <span>مكتبة إسلامية رقمية شاملة</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            <span className="text-amber-300">مكتبة السلف</span>
            <br />
            <span className="text-2xl md:text-3xl text-slate-300 font-normal mt-2 block">
              التراث العلمي لأئمة أهل السنة
            </span>
          </h1>
          <p className="text-slate-400 text-lg leading-relaxed mb-8 max-w-2xl">
            استكشف مئات الكتب والمراجع العلمية لعلماء السلف الصالح في التفسير والحديث 
            والفقه والعقيدة والتزكية — متاحة للجميع، في أي وقت، من أي مكان.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link
              to="/books"
              className="inline-flex items-center gap-2 px-6 py-3 bg-amber-500 hover:bg-amber-400 text-white font-semibold rounded-xl transition-all shadow-lg shadow-amber-900/30 hover:shadow-amber-900/50 hover:-translate-y-0.5"
            >
              <BookOpen className="w-5 h-5" />
              <span>تصفح المكتبة</span>
            </Link>
            <Link
              to="/search"
              className="inline-flex items-center gap-2 px-6 py-3 bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 font-semibold rounded-xl transition-all"
            >
              <Search className="w-5 h-5" />
              <span>ابحث في الكتب</span>
            </Link>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl">
          {[
            { value: '12+', label: 'كتاب متاح' },
            { value: '6', label: 'علماء موثّقون' },
            { value: '8', label: 'تصنيف علمي' },
            { value: '∞', label: 'وصول مجاني' },
          ].map(stat => (
            <div key={stat.label} className="bg-white/5 border border-white/5 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-amber-300 mb-1">{stat.value}</div>
              <div className="text-xs text-slate-500">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FeaturedBooks() {
  const { books, loading } = useBooks();
  const featured = books.filter(b => b.featured).slice(0, 4);

  return (
    <section className="py-16" dir="rtl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-amber-400" />
              <span className="text-amber-400 text-sm font-medium">الكتب المميزة</span>
            </div>
            <h2 className="text-2xl font-bold text-white">أبرز المراجع العلمية</h2>
          </div>
          <Link to="/books" className="flex items-center gap-1 text-amber-400 hover:text-amber-300 text-sm transition-colors">
            <span>عرض الكل</span>
            <ChevronLeft className="w-4 h-4" />
          </Link>
        </div>

        {loading ? (
          <LoadingSpinner />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <Suspense fallback={<LoadingSpinner />}>
              {featured.map(book => (
                <BookCard key={book.id} book={book} />
              ))}
            </Suspense>
          </div>
        )}
      </div>
    </section>
  );
}

function NewBooks() {
  const { books, loading } = useBooks();
  const newBooks = books.filter(b => b.new).slice(0, 3);

  if (newBooks.length === 0) return null;

  return (
    <section className="py-12 bg-[#07182e]/60" dir="rtl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2 mb-6">
          <Clock className="w-4 h-4 text-emerald-400" />
          <h2 className="text-xl font-bold text-white">أحدث الإضافات</h2>
        </div>
        {loading ? <LoadingSpinner /> : (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <Suspense fallback={<LoadingSpinner />}>
              {newBooks.map(book => (
                <BookCard key={book.id} book={book} />
              ))}
            </Suspense>
          </div>
        )}
      </div>
    </section>
  );
}

function QuickSearch() {
  return (
    <section className="py-16" dir="rtl">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-2xl font-bold text-white mb-3">ابحث في المكتبة</h2>
        <p className="text-slate-400 text-sm mb-8">ابحث عن الكتب بالعنوان أو المؤلف أو الموضوع</p>
        <Link
          to="/search"
          className="inline-flex items-center gap-3 w-full max-w-lg bg-[#0c2240] border border-slate-700/50 hover:border-amber-500/50 rounded-2xl px-5 py-4 text-slate-500 hover:text-slate-400 transition-all group cursor-text shadow-lg"
        >
          <Search className="w-5 h-5 group-hover:text-amber-400 transition-colors" />
          <span className="text-base">ابحث عن كتاب، مؤلف، موضوع...</span>
        </Link>
      </div>
    </section>
  );
}

export default function Home() {
  return (
    <div className="min-h-screen bg-[#0a1e35]">
      <HeroSection />
      <FeaturedBooks />
      <NewBooks />
      <QuickSearch />
    </div>
  );
}
