import { Link } from 'react-router-dom';
import { Grid3X3, ChevronLeft } from 'lucide-react';
import { useCategories } from '../hooks/useData';
import LoadingSpinner from '../components/LoadingSpinner';

export default function Categories() {
  const { categories, loading, error } = useCategories();

  return (
    <div className="min-h-screen bg-[#0a1e35]" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#07182e] to-[#0f2a4a] border-b border-amber-900/20 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 mb-2">
            <Grid3X3 className="w-6 h-6 text-amber-400" />
            <h1 className="text-3xl font-bold text-white">التصنيفات العلمية</h1>
          </div>
          <p className="text-slate-400 text-sm">استعرض الكتب مرتبةً حسب التخصص العلمي</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {loading ? <LoadingSpinner /> : error ? (
          <div className="text-center text-red-400 py-20">{error}</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {categories.map((cat: any) => (
              <Link
                key={cat.id}
                to={`/books?category=${encodeURIComponent(cat.name)}`}
                className="group bg-[#0c2240]/80 border border-slate-700/40 rounded-2xl p-6 hover:border-amber-500/40 hover:shadow-xl hover:shadow-amber-900/10 transition-all duration-300 hover:-translate-y-1"
              >
                <div className="flex items-start justify-between mb-4">
                  <span className="text-4xl">{cat.icon}</span>
                  <span
                    className="px-2 py-0.5 rounded-full text-xs font-mono text-slate-500 bg-white/5 border border-white/5"
                  >
                    {cat.count}
                  </span>
                </div>
                <h3 className="text-amber-100 font-bold text-lg mb-1 group-hover:text-amber-300 transition-colors">
                  {cat.name}
                </h3>
                <p className="text-slate-500 text-xs mb-1">{cat.nameEn}</p>
                <p className="text-slate-500 text-sm leading-relaxed">{cat.description}</p>
                <div className="flex items-center gap-1 mt-4 text-amber-400 text-xs opacity-0 group-hover:opacity-100 transition-opacity">
                  <span>تصفح الكتب</span>
                  <ChevronLeft className="w-3 h-3" />
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
