import { lazy, Suspense, useState, useMemo } from 'react';
import { BookOpen, Filter, SortAsc } from 'lucide-react';
import { useBooks } from '../hooks/useData';
import LoadingSpinner from '../components/LoadingSpinner';

const BookCard = lazy(() => import('../components/BookCard'));

const CATEGORIES = ['الكل', 'حديث', 'تفسير', 'فقه', 'عقيدة', 'سيرة', 'تزكية', 'أصول الفقه', 'شروح'];
const SORTS = [
  { value: 'rating', label: 'الأعلى تقييمًا' },
  { value: 'downloads', label: 'الأكثر تحميلًا' },
  { value: 'pages_asc', label: 'الأقل صفحات' },
  { value: 'title', label: 'أبجدي' },
];

export default function Books() {
  const { books, loading, error } = useBooks();
  const [activeCategory, setActiveCategory] = useState('الكل');
  const [sort, setSort] = useState('rating');

  const filtered = useMemo(() => {
    let list = activeCategory === 'الكل' ? [...books] : books.filter(b => b.category === activeCategory);
    if (sort === 'rating') list.sort((a, b) => b.rating - a.rating);
    else if (sort === 'downloads') list.sort((a, b) => b.downloads - a.downloads);
    else if (sort === 'pages_asc') list.sort((a, b) => a.pages - b.pages);
    else if (sort === 'title') list.sort((a, b) => a.title.localeCompare(b.title, 'ar'));
    return list;
  }, [books, activeCategory, sort]);

  return (
    <div className="min-h-screen bg-[#0a1e35]" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#07182e] to-[#0f2a4a] border-b border-amber-900/20 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 mb-2">
            <BookOpen className="w-6 h-6 text-amber-400" />
            <h1 className="text-3xl font-bold text-white">المكتبة</h1>
          </div>
          <p className="text-slate-400 text-sm">استعرض جميع الكتب المتاحة في المكتبة الإسلامية الرقمية</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          {/* Category filter */}
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-500" />
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all ${
                    activeCategory === cat
                      ? 'bg-amber-500 text-white border-amber-500 shadow-lg shadow-amber-900/20'
                      : 'bg-transparent text-slate-400 border-slate-700/50 hover:border-amber-500/50 hover:text-amber-300'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Sort */}
          <div className="flex items-center gap-2">
            <SortAsc className="w-4 h-4 text-slate-500" />
            <select
              value={sort}
              onChange={e => setSort(e.target.value)}
              className="bg-[#0c2240] border border-slate-700/50 text-slate-300 text-xs rounded-xl px-3 py-2 outline-none focus:border-amber-500/50"
            >
              {SORTS.map(s => (
                <option key={s.value} value={s.value}>{s.label}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Result count */}
        <p className="text-slate-500 text-sm mb-6">
          {loading ? 'جارٍ التحميل...' : `${filtered.length} كتاب`}
        </p>

        {/* Grid */}
        {loading ? (
          <LoadingSpinner />
        ) : error ? (
          <div className="text-center text-red-400 py-20">{error}</div>
        ) : filtered.length === 0 ? (
          <div className="text-center text-slate-500 py-20">لا توجد كتب في هذا التصنيف</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <Suspense fallback={<LoadingSpinner />}>
              {filtered.map(book => (
                <BookCard key={book.id} book={book} />
              ))}
            </Suspense>
          </div>
        )}
      </div>
    </div>
  );
}
