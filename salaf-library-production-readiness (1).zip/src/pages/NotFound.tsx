import { Link } from 'react-router-dom';
import { BookOpen, Home, Search } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#0a1e35] flex items-center justify-center" dir="rtl">
      <div className="text-center max-w-md px-4">
        {/* 404 */}
        <div className="text-8xl font-bold text-amber-900/30 mb-4 select-none">404</div>
        
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-700/20 border border-amber-500/30 flex items-center justify-center mx-auto mb-6">
          <BookOpen className="w-8 h-8 text-amber-400" />
        </div>

        <h1 className="text-2xl font-bold text-white mb-3">الصفحة غير موجودة</h1>
        <p className="text-slate-400 text-sm leading-relaxed mb-8">
          عذرًا، الصفحة التي تبحث عنها غير متاحة أو تم نقلها.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            to="/"
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-white font-semibold rounded-xl transition-all"
          >
            <Home className="w-4 h-4" />
            <span>الصفحة الرئيسية</span>
          </Link>
          <Link
            to="/search"
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 font-semibold rounded-xl transition-all"
          >
            <Search className="w-4 h-4" />
            <span>البحث</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
