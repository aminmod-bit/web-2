import { useState, useMemo, lazy, Suspense } from 'react';
import { Search as SearchIcon, BookOpen } from 'lucide-react';
import { useBooks } from '../hooks/useData';
import LoadingSpinner from '../components/LoadingSpinner';

const BookCard = lazy(() => import('../components/BookCard'));

export default function Search() {
  const { books, loading } = useBooks();
  const [query, setQuery] = useState('');

  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return books.filter(b =>
      b.title.toLowerCase().includes(q) ||
      b.author.toLowerCase().includes(q) ||
      b.category.toLowerCase().includes(q) ||
      (b.tags as string[]).some((t: string) => t.toLowerCase().includes(q)) ||
      b.description.toLowerCase().includes(q)
    );
  }, [books, query]);

  return (
    <div className="min-h-screen bg-[#0a1e35]" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#07182e] to-[#0f2a4a] border-b border-amber-900/20 py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-white mb-6 text-center">البحث في المكتبة</h1>
          <div className="relative">
            <SearchIcon className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
            <input
              type="search"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="ابحث بالعنوان، المؤلف، الموضوع..."
              className="w-full bg-[#0c2240] border border-slate-700/50 focus:border-amber-500/60 text-slate-200 placeholder-slate-600 rounded-2xl py-4 pr-12 pl-4 text-base outline-none transition-colors shadow-xl"
              autoFocus
            />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {loading ? (
          <LoadingSpinner />
        ) : query.trim() === '' ? (
          <div className="text-center py-20">
            <BookOpen className="w-16 h-16 text-slate-700 mx-auto mb-4" />
            <p className="text-slate-500 text-lg">اكتب كلمة للبحث في المكتبة</p>
            <p className="text-slate-600 text-sm mt-2">يمكنك البحث بالعنوان أو المؤلف أو الكلمات المفتاحية</p>
          </div>
        ) : results.length === 0 ? (
          <div className="text-center py-20">
            <SearchIcon className="w-16 h-16 text-slate-700 mx-auto mb-4" />
            <p className="text-slate-400 text-lg">لا نتائج لـ «{query}»</p>
            <p className="text-slate-600 text-sm mt-2">جرّب كلمة أخرى أو تصفح التصنيفات</p>
          </div>
        ) : (
          <div>
            <p className="text-slate-500 text-sm mb-6">
              {results.length} نتيجة لـ «<span className="text-amber-300">{query}</span>»
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              <Suspense fallback={<LoadingSpinner />}>
                {results.map(book => (
                  <BookCard key={book.id} book={book} />
                ))}
              </Suspense>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
