export interface Book {
  id: number;
  title: string;
  titleEn: string;
  author: string;
  authorEn: string;
  category: string;
  categoryEn: string;
  year: string;
  pages: number;
  description: string;
  tags: string[];
  rating: number;
  downloads: number;
  cover: string;
  featured: boolean;
  new: boolean;
}

export interface Scholar {
  id: number;
  name: string;
  nameEn: string;
  fullName: string;
  born: string;
  died: string;
  specialization: string;
  bio: string;
  books: number[];
  image: string;
}

export interface Category {
  id: number;
  name: string;
  nameEn: string;
  icon: string;
  description: string;
  count: number;
  color: string;
}
