import { lazy, Suspense } from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import LoadingSpinner from './components/LoadingSpinner';

// Lazy-loaded pages for optimal bundle splitting
const Home = lazy(() => import('./pages/Home'));
const Books = lazy(() => import('./pages/Books'));
const BookDetail = lazy(() => import('./pages/BookDetail'));
const Categories = lazy(() => import('./pages/Categories'));
const Scholars = lazy(() => import('./pages/Scholars'));
const Search = lazy(() => import('./pages/Search'));
const About = lazy(() => import('./pages/About'));
const NotFound = lazy(() => import('./pages/NotFound'));

function PageLayout() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1">
        <Suspense fallback={
          <div className="min-h-[60vh] bg-[#0a1e35] flex items-center justify-center">
            <LoadingSpinner message="جارٍ تحميل الصفحة..." />
          </div>
        }>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/books" element={<Books />} />
            <Route path="/books/:id" element={<BookDetail />} />
            <Route path="/categories" element={<Categories />} />
            <Route path="/scholars" element={<Scholars />} />
            <Route path="/search" element={<Search />} />
            <Route path="/about" element={<About />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  // HashRouter works perfectly with:
  // - viteSingleFile builds (single HTML output)
  // - GitHub Pages (no server-side routing needed)
  // - All browsers including older ones
  return (
    <HashRouter>
      <PageLayout />
    </HashRouter>
  );
}
