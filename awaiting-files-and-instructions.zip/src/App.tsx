import { useEffect } from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useStore } from './store/useStore';
import { booksData } from './data/books';
import { biographiesData } from './data/biographies';
import { audioData } from './data/audio';
import { fawaidData } from './data/fawaid';
import { categoriesData } from './data/categories';

import Sidebar from './components/Sidebar';
import Header from './components/Header';
import AudioPlayer from './components/AudioPlayer';
import HomePage from './pages/HomePage';
import BooksPage from './pages/BooksPage';
import BookDetailPage from './pages/BookDetailPage';
import BiographiesPage from './pages/BiographiesPage';
import BiographyDetailPage from './pages/BiographyDetailPage';
import AudioPage from './pages/AudioPage';
import FawaidPage from './pages/FawaidPage';
import SearchPage from './pages/SearchPage';
import FavoritesPage from './pages/FavoritesPage';
import HistoryPage from './pages/HistoryPage';
import CategoriesPage from './pages/CategoriesPage';
import AdminPage from './pages/AdminPage';

function AudioPlayerWrapper() {
  const { currentAudio } = useStore();
  if (!currentAudio) return null;
  return <AudioPlayer />;
}

export default function App() {
  const { setBooks, setBiographies, setAudioLessons, setFawaid, setCategories, setLoading } = useStore();

  useEffect(() => {
    // Load data
    setTimeout(() => {
      setBooks(booksData);
      setBiographies(biographiesData);
      setAudioLessons(audioData);
      setFawaid(fawaidData);
      setCategories(categoriesData);
      setLoading(false);
    }, 600);
  }, []);

  return (
    <HashRouter>
      <div className="app-layout">
        <Sidebar />
        <div className="main-content">
          <Header />
          <div className="page-content">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/books" element={<BooksPage />} />
              <Route path="/books/:id" element={<BookDetailPage />} />
              <Route path="/biographies" element={<BiographiesPage />} />
              <Route path="/biographies/:id" element={<BiographyDetailPage />} />
              <Route path="/audio" element={<AudioPage />} />
              <Route path="/fawaid" element={<FawaidPage />} />
              <Route path="/search" element={<SearchPage />} />
              <Route path="/favorites" element={<FavoritesPage />} />
              <Route path="/history" element={<HistoryPage />} />
              <Route path="/categories" element={<CategoriesPage />} />
              <Route path="/admin" element={<AdminPage />} />
            </Routes>
          </div>
        </div>
        <AudioPlayerWrapper />
        <Toaster
          position="bottom-right"
          toastOptions={{
            style: {
              background: '#112a1a',
              color: '#f0f4f1',
              border: '1px solid rgba(212, 175, 55, 0.3)',
              borderRadius: '12px',
              fontSize: '14px',
            },
          }}
        />
      </div>

      <style>{`
        .app-layout {
          display: flex;
          min-height: 100vh;
          background: var(--color-bg-primary);
        }

        .main-content {
          flex: 1;
          display: flex;
          flex-direction: column;
          min-width: 0;
          margin-left: 260px;
          transition: margin-left 0.3s ease;
        }

        .page-content {
          flex: 1;
          padding: 24px;
          padding-bottom: 24px;
        }

        @media (max-width: 1024px) {
          .main-content {
            margin-left: 0;
          }

          .page-content {
            padding: 16px;
          }
        }
      `}</style>
    </HashRouter>
  );
}
