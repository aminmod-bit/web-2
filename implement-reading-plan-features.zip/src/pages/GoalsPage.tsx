import { useState } from 'react';
import { Target, Plus, Minus, Edit3, TrendingUp, CheckCircle, Trophy, BookOpen, Mic, Star } from 'lucide-react';
import { useLibraryStore } from '../store/useLibraryStore';
import toast from 'react-hot-toast';

export default function GoalsPage() {
  const { weeklyGoal, updateWeeklyGoal, books, lessons, fawaids } = useLibraryStore();
  const [editMode, setEditMode] = useState(false);
  const [targets, setTargets] = useState({
    books: weeklyGoal.books.target,
    lessons: weeklyGoal.lessons.target,
    fawaids: weeklyGoal.fawaids.target,
  });

  const completedBooks = books.filter((b) => b.isCompleted).length;
  const completedLessons = lessons.filter((l) => l.isCompleted).length;
  const totalFawaids = fawaids.length;

  const goals = [
    {
      key: 'books' as const,
      label: 'Книги',
      icon: BookOpen,
      emoji: '📚',
      description: 'Книги прочитаны за неделю',
      color: 'from-emerald-500 to-green-600',
      bgLight: 'bg-emerald-50',
      textColor: 'text-emerald-700',
      borderColor: 'border-emerald-200',
      completed: weeklyGoal.books.completed,
      target: weeklyGoal.books.target,
    },
    {
      key: 'lessons' as const,
      label: 'Уроки',
      icon: Mic,
      emoji: '🎧',
      description: 'Уроков прослушано за неделю',
      color: 'from-blue-500 to-indigo-600',
      bgLight: 'bg-blue-50',
      textColor: 'text-blue-700',
      borderColor: 'border-blue-200',
      completed: weeklyGoal.lessons.completed,
      target: weeklyGoal.lessons.target,
    },
    {
      key: 'fawaids' as const,
      label: 'Фаваиды',
      icon: Star,
      emoji: '✨',
      description: 'Фаваидов записано за неделю',
      color: 'from-amber-500 to-orange-600',
      bgLight: 'bg-amber-50',
      textColor: 'text-amber-700',
      borderColor: 'border-amber-200',
      completed: weeklyGoal.fawaids.completed,
      target: weeklyGoal.fawaids.target,
    },
  ];

  const allDone = goals.every((g) => g.completed >= g.target);
  const totalProgress = goals.reduce((sum, g) => sum + Math.min(g.completed / g.target, 1), 0) / goals.length;

  const handleSaveTargets = () => {
    updateWeeklyGoal({
      books: { ...weeklyGoal.books, target: targets.books },
      lessons: { ...weeklyGoal.lessons, target: targets.lessons },
      fawaids: { ...weeklyGoal.fawaids, target: targets.fawaids },
    });
    setEditMode(false);
    toast.success('Цели обновлены!');
  };

  const handleUpdateCompleted = (key: 'books' | 'lessons' | 'fawaids', val: number) => {
    const current = weeklyGoal[key];
    const newVal = Math.max(0, Math.min(current.target, val));
    updateWeeklyGoal({
      [key]: { ...current, completed: newVal },
    });
  };

  const handleResetWeek = () => {
    updateWeeklyGoal({
      books: { ...weeklyGoal.books, completed: 0 },
      lessons: { ...weeklyGoal.lessons, completed: 0 },
      fawaids: { ...weeklyGoal.fawaids, completed: 0 },
      weekStart: new Date().toISOString().split('T')[0],
    });
    toast.success('Прогресс недели сброшен');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">🎯 Цели</h2>
          <p className="text-gray-500 text-sm mt-0.5">
            Неделя с {weeklyGoal.weekStart}
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setEditMode(!editMode)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm transition-colors ${
              editMode
                ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                : 'bg-[#0d3320] text-white hover:bg-[#1a5e38]'
            }`}
          >
            <Edit3 className="w-4 h-4" />
            {editMode ? 'Отмена' : 'Изменить'}
          </button>
        </div>
      </div>

      {/* All Done Banner */}
      {allDone && (
        <div className="relative overflow-hidden bg-gradient-to-br from-[#0d3320] to-[#1a5e38] rounded-2xl p-5 text-white">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-amber-400 rounded-2xl flex items-center justify-center shrink-0 shadow-lg">
              <Trophy className="w-7 h-7 text-[#0d3320]" />
            </div>
            <div>
              <h3 className="font-bold text-lg">Все цели достигнуты! 🎉</h3>
              <p className="text-green-200/80 text-sm">
                Ма шааллах! Вы выполнили все цели этой недели
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Overall Progress */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-[#0d3320]" />
            <span className="font-bold text-gray-900 text-sm">Общий прогресс недели</span>
          </div>
          <span className="text-2xl font-bold text-[#0d3320]">
            {Math.round(totalProgress * 100)}%
          </span>
        </div>
        <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-[#0d3320] via-emerald-500 to-amber-400 rounded-full transition-all duration-700"
            style={{ width: `${totalProgress * 100}%` }}
          />
        </div>
        <div className="flex justify-between text-xs text-gray-400 mt-1.5">
          <span>Начало недели</span>
          <span>Цель достигнута</span>
        </div>
      </div>

      {/* Goals Cards */}
      <div className="space-y-4">
        {goals.map((goal) => {
          const pct = Math.min(Math.round((goal.completed / goal.target) * 100), 100);
          const isDone = goal.completed >= goal.target;
          const Icon = goal.icon;

          return (
            <div
              key={goal.key}
              className={`bg-white rounded-2xl shadow-sm border transition-all ${
                isDone ? `${goal.borderColor} shadow-sm` : 'border-gray-100'
              }`}
            >
              <div className="p-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-12 h-12 rounded-xl bg-gradient-to-br ${goal.color} flex items-center justify-center shadow-sm`}
                    >
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-gray-900">{goal.label}</h3>
                        {isDone && (
                          <CheckCircle className={`w-4 h-4 ${goal.textColor}`} />
                        )}
                      </div>
                      <p className="text-xs text-gray-500">{goal.description}</p>
                    </div>
                  </div>

                  {/* Counter */}
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleUpdateCompleted(goal.key, goal.completed - 1)}
                      className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"
                    >
                      <Minus className="w-3.5 h-3.5 text-gray-600" />
                    </button>
                    <div className="text-center min-w-[3rem]">
                      <span className="text-2xl font-bold text-gray-900">{goal.completed}</span>
                      <span className="text-gray-400 text-sm">/{goal.target}</span>
                    </div>
                    <button
                      onClick={() => handleUpdateCompleted(goal.key, goal.completed + 1)}
                      className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors bg-gradient-to-br ${goal.color} hover:opacity-90`}
                    >
                      <Plus className="w-3.5 h-3.5 text-white" />
                    </button>
                  </div>
                </div>

                {/* Progress */}
                <div className="mt-4">
                  <div className="flex justify-between text-xs text-gray-500 mb-1.5">
                    <span>
                      {isDone ? '✅ Цель достигнута!' : `Осталось: ${goal.target - goal.completed}`}
                    </span>
                    <span className="font-semibold">{pct}%</span>
                  </div>
                  <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full bg-gradient-to-r ${goal.color} rounded-full transition-all duration-500`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>

                {/* Quick milestones */}
                <div className="mt-3 flex gap-1.5">
                  {[25, 50, 75, 100].map((milestone) => {
                    const reached = pct >= milestone;
                    return (
                      <div
                        key={milestone}
                        className={`flex-1 h-1 rounded-full ${
                          reached ? `bg-gradient-to-r ${goal.color}` : 'bg-gray-100'
                        }`}
                      />
                    );
                  })}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Edit Targets */}
      {editMode && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 space-y-5">
          <h3 className="font-bold text-gray-900 flex items-center gap-2">
            <Target className="w-4 h-4 text-[#0d3320]" />
            Изменить цели на неделю
          </h3>
          {[
            { key: 'books' as const, label: '📚 Книги', emoji: '📚' },
            { key: 'lessons' as const, label: '🎧 Уроки', emoji: '🎧' },
            { key: 'fawaids' as const, label: '✨ Фаваиды', emoji: '✨' },
          ].map(({ key, label }) => (
            <div key={key}>
              <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">
                {label}
              </label>
              <div className="mt-2 flex items-center gap-3">
                <button
                  onClick={() => setTargets({ ...targets, [key]: Math.max(1, targets[key] - 1) })}
                  className="w-10 h-10 rounded-xl bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"
                >
                  <Minus className="w-4 h-4 text-gray-600" />
                </button>
                <input
                  type="number"
                  value={targets[key]}
                  onChange={(e) => setTargets({ ...targets, [key]: Math.max(1, Number(e.target.value)) })}
                  className="w-20 text-center border border-gray-200 rounded-xl px-2 py-2 text-lg font-bold focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320]"
                />
                <button
                  onClick={() => setTargets({ ...targets, [key]: targets[key] + 1 })}
                  className="w-10 h-10 rounded-xl bg-[#0d3320] hover:bg-[#1a5e38] flex items-center justify-center transition-colors"
                >
                  <Plus className="w-4 h-4 text-white" />
                </button>
                <span className="text-sm text-gray-500">
                  {key === 'books' ? 'книг' : key === 'lessons' ? 'уроков' : 'фаваидов'}
                </span>
              </div>
            </div>
          ))}
          <div className="flex gap-3">
            <button
              onClick={() => setEditMode(false)}
              className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-gray-600 bg-gray-100 hover:bg-gray-200 transition-colors"
            >
              Отмена
            </button>
            <button
              onClick={handleSaveTargets}
              className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white bg-[#0d3320] hover:bg-[#1a5e38] transition-colors"
            >
              Сохранить
            </button>
          </div>
        </div>
      )}

      {/* Overall Stats */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
        <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-[#0d3320]" />
          Статистика за всё время
        </h3>
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: 'Книг прочитано', value: completedBooks, icon: '📚', total: books.length },
            { label: 'Уроков пройдено', value: completedLessons, icon: '🎧', total: lessons.length },
            { label: 'Фаваидов', value: totalFawaids, icon: '✨', total: totalFawaids },
          ].map((stat) => (
            <div key={stat.label} className="bg-gray-50 rounded-xl p-3 text-center">
              <div className="text-2xl mb-1">{stat.icon}</div>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-xs text-gray-500 leading-tight mt-0.5">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Reset */}
      <button
        onClick={handleResetWeek}
        className="w-full py-3 rounded-xl text-sm font-semibold text-red-500 border border-red-100 hover:bg-red-50 transition-colors"
      >
        Сбросить прогресс недели
      </button>
    </div>
  );
}
