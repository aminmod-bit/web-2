import { useState } from 'react';
import { Mic, Plus, Trash2, CheckCircle, Search, X, Clock } from 'lucide-react';
import { useLibraryStore } from '../store/useLibraryStore';
import toast from 'react-hot-toast';

const CATEGORIES = ['Все', 'Акыда', 'Хадисы', 'Тафсир', 'Фикх', 'Ахляк', 'Другое'];

export default function LessonsPage() {
  const { lessons, addLesson, completeLesson, deleteLesson } = useLibraryStore();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('Все');
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({
    title: '',
    scholar: '',
    duration: '',
    category: 'Акыда',
  });

  const filtered = lessons.filter((l) => {
    const matchSearch =
      l.title.toLowerCase().includes(search.toLowerCase()) ||
      l.scholar.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'Все' || l.category === filter;
    return matchSearch && matchFilter;
  });

  const completedCount = lessons.filter((l) => l.isCompleted).length;

  const handleAdd = () => {
    if (!form.title.trim() || !form.scholar.trim()) {
      toast.error('Заполните название и учёного');
      return;
    }
    addLesson({ ...form, isCompleted: false });
    toast.success('Урок добавлен!');
    setShowAdd(false);
    setForm({ title: '', scholar: '', duration: '', category: 'Акыда' });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Аудиоуроки</h2>
          <p className="text-gray-500 text-sm mt-0.5">
            {completedCount} из {lessons.length} пройдено
          </p>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-2 bg-[#0d3320] text-white px-4 py-2.5 rounded-xl font-semibold text-sm hover:bg-[#1a5e38] transition-colors shadow-sm"
        >
          <Plus className="w-4 h-4" />
          Добавить
        </button>
      </div>

      {/* Progress bar */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
        <div className="flex justify-between text-sm mb-2">
          <span className="text-gray-600 font-medium">Общий прогресс</span>
          <span className="font-bold text-[#0d3320]">
            {lessons.length > 0 ? Math.round((completedCount / lessons.length) * 100) : 0}%
          </span>
        </div>
        <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-[#0d3320] to-emerald-500 rounded-full transition-all duration-700"
            style={{ width: `${lessons.length > 0 ? (completedCount / lessons.length) * 100 : 0}%` }}
          />
        </div>
      </div>

      {/* Search & Filter */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Поиск уроков..."
            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320]"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`whitespace-nowrap px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                filter === cat
                  ? 'bg-[#0d3320] text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Lessons List */}
      <div className="space-y-3">
        {filtered.map((lesson) => (
          <div
            key={lesson.id}
            className={`bg-white rounded-2xl shadow-sm border transition-all ${
              lesson.isCompleted ? 'border-emerald-100 bg-emerald-50/30' : 'border-gray-100 hover:border-gray-200'
            }`}
          >
            <div className="p-4 flex items-start gap-4">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  lesson.isCompleted ? 'bg-emerald-100' : 'bg-[#0d3320]/10'
                }`}
              >
                {lesson.isCompleted ? (
                  <CheckCircle className="w-5 h-5 text-emerald-600" />
                ) : (
                  <Mic className="w-5 h-5 text-[#0d3320]" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h3
                  className={`font-semibold text-sm leading-tight ${
                    lesson.isCompleted ? 'text-gray-500 line-through' : 'text-gray-900'
                  }`}
                >
                  {lesson.title}
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">{lesson.scholar}</p>
                <div className="flex items-center gap-3 mt-2">
                  {lesson.duration && (
                    <div className="flex items-center gap-1 text-xs text-gray-400">
                      <Clock className="w-3 h-3" />
                      {lesson.duration}
                    </div>
                  )}
                  <span className="text-xs bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full font-medium">
                    {lesson.category}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {!lesson.isCompleted && (
                  <button
                    onClick={() => {
                      completeLesson(lesson.id);
                      toast.success('Урок пройден! ✓');
                    }}
                    className="text-xs bg-[#0d3320] text-white px-3 py-1.5 rounded-lg font-medium hover:bg-[#1a5e38] transition-colors"
                  >
                    Пройдено
                  </button>
                )}
                <button
                  onClick={() => {
                    deleteLesson(lesson.id);
                    toast.success('Урок удалён');
                  }}
                  className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16">
          <Mic className="w-12 h-12 text-gray-200 mx-auto mb-3" />
          <p className="text-gray-400 font-medium">Уроки не найдены</p>
        </div>
      )}

      {/* Add Lesson Modal */}
      {showAdd && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end sm:items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md">
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h3 className="font-bold text-gray-900">Добавить урок</h3>
              <button onClick={() => setShowAdd(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Название урока *</label>
                <input
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  placeholder="Основы акыды..."
                  className="mt-1 w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320]"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Учёный *</label>
                <input
                  value={form.scholar}
                  onChange={(e) => setForm({ ...form, scholar: e.target.value })}
                  placeholder="Шейх Ибн Усаймин"
                  className="mt-1 w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320]"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Длительность</label>
                  <input
                    value={form.duration}
                    onChange={(e) => setForm({ ...form, duration: e.target.value })}
                    placeholder="45 мин"
                    className="mt-1 w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320]"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Категория</label>
                  <select
                    value={form.category}
                    onChange={(e) => setForm({ ...form, category: e.target.value })}
                    className="mt-1 w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320] bg-white"
                  >
                    {CATEGORIES.filter((c) => c !== 'Все').map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
            <div className="p-5 border-t border-gray-100 flex gap-3">
              <button
                onClick={() => setShowAdd(false)}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-gray-600 bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                Отмена
              </button>
              <button
                onClick={handleAdd}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white bg-[#0d3320] hover:bg-[#1a5e38] transition-colors"
              >
                Добавить
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
