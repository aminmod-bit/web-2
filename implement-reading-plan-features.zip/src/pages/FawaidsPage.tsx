import { useState } from 'react';
import { Star, Plus, Trash2, Search, X, Heart } from 'lucide-react';
import { useLibraryStore } from '../store/useLibraryStore';
import toast from 'react-hot-toast';

const CATEGORIES = ['Все', 'Хадисы', 'Акыда', 'Ахляк', 'Тасаввур', 'Фикх', 'Другое'];

export default function FawaidsPage() {
  const { fawaids, addFaida, deleteFaida, toggleFavorite } = useLibraryStore();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('Все');
  const [showFav, setShowFav] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({
    text: '',
    source: '',
    category: 'Хадисы',
    isFavorite: false,
  });

  const filtered = fawaids.filter((f) => {
    const matchSearch =
      f.text.toLowerCase().includes(search.toLowerCase()) ||
      f.source.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'Все' || f.category === filter;
    const matchFav = !showFav || f.isFavorite;
    return matchSearch && matchFilter && matchFav;
  });

  const handleAdd = () => {
    if (!form.text.trim()) {
      toast.error('Введите текст фаиды');
      return;
    }
    addFaida(form);
    toast.success('Фаида добавлена!');
    setShowAdd(false);
    setForm({ text: '', source: '', category: 'Хадисы', isFavorite: false });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Фаваиды</h2>
          <p className="text-gray-500 text-sm mt-0.5">
            {fawaids.length} фаваидов · {fawaids.filter((f) => f.isFavorite).length} в избранном
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setShowFav(!showFav)}
            className={`p-2.5 rounded-xl border transition-all ${
              showFav
                ? 'bg-amber-400 text-white border-amber-400'
                : 'border-gray-200 text-gray-400 hover:text-amber-500'
            }`}
          >
            <Heart className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowAdd(true)}
            className="flex items-center gap-2 bg-[#0d3320] text-white px-4 py-2.5 rounded-xl font-semibold text-sm hover:bg-[#1a5e38] transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Добавить
          </button>
        </div>
      </div>

      {/* Search & Filter */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Поиск фаваидов..."
            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320]"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`whitespace-nowrap px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                filter === cat
                  ? 'bg-[#0d3320] text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Fawaids List */}
      <div className="space-y-4">
        {filtered.map((faida) => (
          <div
            key={faida.id}
            className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow"
          >
            <div className="h-1 bg-gradient-to-r from-amber-400 to-amber-600" />
            <div className="p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-3">
                    <Star className="w-4 h-4 text-amber-500 shrink-0" />
                    <span className="text-xs bg-amber-50 text-amber-700 px-2 py-0.5 rounded-full font-medium">
                      {faida.category}
                    </span>
                    <span className="text-xs text-gray-400">{faida.dateAdded}</span>
                  </div>
                  <p className="text-gray-800 leading-relaxed text-sm">
                    «{faida.text}»
                  </p>
                  {faida.source && (
                    <p className="text-xs text-gray-400 mt-2 font-medium">— {faida.source}</p>
                  )}
                </div>
                <div className="flex flex-col gap-2 shrink-0">
                  <button
                    onClick={() => {
                      toggleFavorite(faida.id);
                      toast.success(faida.isFavorite ? 'Удалено из избранного' : 'Добавлено в избранное!');
                    }}
                    className={`p-1.5 rounded-lg transition-colors ${
                      faida.isFavorite
                        ? 'text-amber-500 bg-amber-50'
                        : 'text-gray-300 hover:text-amber-500 hover:bg-amber-50'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${faida.isFavorite ? 'fill-current' : ''}`} />
                  </button>
                  <button
                    onClick={() => {
                      deleteFaida(faida.id);
                      toast.success('Удалено');
                    }}
                    className="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16">
          <Star className="w-12 h-12 text-gray-200 mx-auto mb-3" />
          <p className="text-gray-400 font-medium">
            {showFav ? 'Нет избранных фаваидов' : 'Фаваиды не найдены'}
          </p>
        </div>
      )}

      {/* Add Faida Modal */}
      {showAdd && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end sm:items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h3 className="font-bold text-gray-900">Добавить фаиду</h3>
              <button onClick={() => setShowAdd(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Текст фаиды *</label>
                <textarea
                  value={form.text}
                  onChange={(e) => setForm({ ...form, text: e.target.value })}
                  rows={4}
                  placeholder="Поистине, дела оцениваются только по намерениям..."
                  className="mt-1 w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320] resize-none"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Источник</label>
                <input
                  value={form.source}
                  onChange={(e) => setForm({ ...form, source: e.target.value })}
                  placeholder="Бухари, Муслим / Ибн аль-Каyyим"
                  className="mt-1 w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320]"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Категория</label>
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="mt-1 w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320] bg-white"
                >
                  {CATEGORIES.filter((c) => c !== 'Все').map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </div>
              <label className="flex items-center gap-3 cursor-pointer">
                <div
                  onClick={() => setForm({ ...form, isFavorite: !form.isFavorite })}
                  className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all ${
                    form.isFavorite ? 'bg-amber-400 border-amber-400' : 'border-gray-300'
                  }`}
                >
                  {form.isFavorite && <span className="text-white text-xs">✓</span>}
                </div>
                <span className="text-sm text-gray-700">Добавить в избранное</span>
              </label>
            </div>
            <div className="p-5 border-t border-gray-100 flex gap-3">
              <button
                onClick={() => setShowAdd(false)}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-gray-600 bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                Отмена
              </button>
              <button
                onClick={handleAdd}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white bg-[#0d3320] hover:bg-[#1a5e38] transition-colors"
              >
                Сохранить
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
