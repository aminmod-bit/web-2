import { useState } from 'react';
import { BookMarked, Clock, ChevronRight, CheckCircle, Edit3, BookOpen, Calendar, ArrowRight } from 'lucide-react';
import { useLibraryStore } from '../store/useLibraryStore';
import toast from 'react-hot-toast';

export default function ReadingPlanPage() {
  const { books, readingPlan, setReadingPlan, setCurrentBookPage, completeBook, setActiveTab } =
    useLibraryStore();

  const [editMode, setEditMode] = useState(false);
  const [pageInput, setPageInput] = useState('');
  const [dailyPagesInput, setDailyPagesInput] = useState(readingPlan.dailyPages.toString());
  const [notesInput, setNotesInput] = useState(readingPlan.notes);
  const [selectBookMode, setSelectBookMode] = useState(false);

  const currentBook = readingPlan.currentBookId
    ? books.find((b) => b.id === readingPlan.currentBookId)
    : null;

  const pagesLeft = currentBook ? currentBook.totalPages - currentBook.currentPage : 0;
  const daysLeft =
    pagesLeft > 0 && readingPlan.dailyPages > 0
      ? Math.ceil(pagesLeft / readingPlan.dailyPages)
      : 0;
  const progress = currentBook
    ? Math.round((currentBook.currentPage / currentBook.totalPages) * 100)
    : 0;

  const unfinishedBooks = books.filter((b) => !b.isCompleted);
  const completedBooks = books.filter((b) => b.isCompleted);

  const handleUpdatePage = () => {
    if (!currentBook) return;
    const page = Number(pageInput);
    if (isNaN(page) || page < 0) {
      toast.error('Введите корректный номер страницы');
      return;
    }
    if (page > currentBook.totalPages) {
      toast.error(`Максимум ${currentBook.totalPages} страниц`);
      return;
    }
    setCurrentBookPage(currentBook.id, page);
    setPageInput('');
    toast.success(`Прогресс обновлён: страница ${page}`);
  };

  const handleSaveSettings = () => {
    const daily = Number(dailyPagesInput);
    if (isNaN(daily) || daily < 1) {
      toast.error('Введите корректное количество страниц');
      return;
    }
    setReadingPlan({ dailyPages: daily, notes: notesInput });
    setEditMode(false);
    toast.success('Настройки сохранены!');
  };

  const handleSelectBook = (bookId: string) => {
    setReadingPlan({ currentBookId: bookId, startDate: new Date().toISOString().split('T')[0] });
    setSelectBookMode(false);
    const book = books.find((b) => b.id === bookId);
    toast.success(`Начинаем читать «${book?.title}»`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">📖 План чтения</h2>
          <p className="text-gray-500 text-sm mt-0.5">Систематическое изучение книг</p>
        </div>
        <button
          onClick={() => setEditMode(!editMode)}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm transition-colors ${
            editMode
              ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              : 'bg-[#0d3320] text-white hover:bg-[#1a5e38]'
          }`}
        >
          <Edit3 className="w-4 h-4" />
          {editMode ? 'Отмена' : 'Настроить'}
        </button>
      </div>

      {/* Current Book Card */}
      {currentBook ? (
        <div className="relative overflow-hidden bg-gradient-to-br from-[#0d3320] to-[#1a5e38] rounded-3xl p-6 text-white shadow-2xl">
          {/* Decorative */}
          <div className="absolute top-0 right-0 w-40 h-40 opacity-5">
            <BookOpen className="w-full h-full" />
          </div>

          <div className="relative z-10 space-y-5">
            <div>
              <p className="text-green-300/70 text-xs font-semibold uppercase tracking-widest mb-1">
                📖 Сегодня читаю
              </p>
              <h3 className="text-2xl font-bold leading-tight">{currentBook.title}</h3>
              <p className="text-green-200/80 text-sm mt-1">{currentBook.author}</p>
            </div>

            {/* Progress Ring */}
            <div className="flex items-center gap-6">
              <div className="relative w-20 h-20">
                <svg className="w-20 h-20 -rotate-90" viewBox="0 0 80 80">
                  <circle cx="40" cy="40" r="34" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="6" />
                  <circle
                    cx="40" cy="40" r="34" fill="none"
                    stroke="#f59e0b"
                    strokeWidth="6"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 34}`}
                    strokeDashoffset={`${2 * Math.PI * 34 * (1 - progress / 100)}`}
                    className="transition-all duration-700"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-lg font-bold text-amber-300">{progress}%</span>
                </div>
              </div>

              <div className="space-y-2">
                <div className="bg-white/10 rounded-xl px-4 py-2.5">
                  <p className="text-xs text-green-200/70">Текущая страница</p>
                  <p className="text-xl font-bold">{currentBook.currentPage} / {currentBook.totalPages}</p>
                </div>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-white/10 rounded-xl p-3 text-center">
                <p className="text-amber-300 text-xl font-bold">{pagesLeft}</p>
                <p className="text-xs text-green-200/70">стр. осталось</p>
              </div>
              <div className="bg-white/10 rounded-xl p-3 text-center">
                <p className="text-amber-300 text-xl font-bold">{readingPlan.dailyPages}</p>
                <p className="text-xs text-green-200/70">стр./день</p>
              </div>
              <div className="bg-white/10 rounded-xl p-3 text-center">
                <p className="text-amber-300 text-xl font-bold">{daysLeft}</p>
                <p className="text-xs text-green-200/70">
                  {daysLeft === 1 ? 'день' : daysLeft < 5 ? 'дня' : 'дней'}
                </p>
              </div>
            </div>

            {/* Update Page Input */}
            <div className="flex gap-2">
              <input
                type="number"
                value={pageInput}
                onChange={(e) => setPageInput(e.target.value)}
                placeholder="Номер страницы..."
                min={0}
                max={currentBook.totalPages}
                className="flex-1 bg-white/10 border border-white/20 text-white placeholder:text-white/40 px-4 py-2.5 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-400/50"
              />
              <button
                onClick={handleUpdatePage}
                className="bg-amber-400 text-[#0d3320] px-4 py-2.5 rounded-xl font-bold text-sm hover:bg-amber-300 transition-colors flex items-center gap-1"
              >
                <ArrowRight className="w-4 h-4" />
                Обновить
              </button>
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <button
                onClick={() => setSelectBookMode(true)}
                className="flex-1 bg-white/10 border border-white/20 text-white py-2.5 rounded-xl text-sm font-semibold hover:bg-white/20 transition-colors"
              >
                Сменить книгу
              </button>
              {!currentBook.isCompleted && (
                <button
                  onClick={() => {
                    completeBook(currentBook.id);
                    toast.success('🎉 Поздравляем! Книга завершена!');
                  }}
                  className="flex-1 bg-amber-400 text-[#0d3320] py-2.5 rounded-xl text-sm font-bold hover:bg-amber-300 transition-colors flex items-center justify-center gap-2"
                >
                  <CheckCircle className="w-4 h-4" />
                  Завершить
                </button>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8 text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <BookOpen className="w-8 h-8 text-gray-300" />
          </div>
          <h3 className="font-bold text-gray-900 text-lg mb-2">Книга не выбрана</h3>
          <p className="text-gray-500 text-sm mb-5">Выберите книгу для систематического чтения</p>
          <button
            onClick={() => setSelectBookMode(true)}
            className="bg-[#0d3320] text-white px-6 py-3 rounded-xl font-semibold hover:bg-[#1a5e38] transition-colors"
          >
            Выбрать книгу
          </button>
        </div>
      )}

      {/* Settings Panel */}
      {editMode && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 space-y-4">
          <h3 className="font-bold text-gray-900 flex items-center gap-2">
            <Edit3 className="w-4 h-4 text-[#0d3320]" />
            Настройки плана
          </h3>
          <div>
            <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">
              Страниц в день
            </label>
            <div className="mt-1 flex gap-3 items-center">
              <input
                type="number"
                value={dailyPagesInput}
                onChange={(e) => setDailyPagesInput(e.target.value)}
                min={1}
                className="w-32 border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320]"
              />
              <div className="flex gap-2">
                {[5, 10, 15, 20, 30].map((n) => (
                  <button
                    key={n}
                    onClick={() => setDailyPagesInput(n.toString())}
                    className={`w-8 h-8 rounded-lg text-xs font-semibold transition-all ${
                      dailyPagesInput === n.toString()
                        ? 'bg-[#0d3320] text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {n}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">
              Заметки к плану
            </label>
            <textarea
              value={notesInput}
              onChange={(e) => setNotesInput(e.target.value)}
              rows={3}
              placeholder="Ваши заметки..."
              className="mt-1 w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320] resize-none"
            />
          </div>
          <button
            onClick={handleSaveSettings}
            className="w-full bg-[#0d3320] text-white py-2.5 rounded-xl font-semibold text-sm hover:bg-[#1a5e38] transition-colors"
          >
            Сохранить настройки
          </button>
        </div>
      )}

      {/* Notes Display */}
      {readingPlan.notes && !editMode && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4">
          <p className="text-xs font-semibold text-amber-700 uppercase tracking-wide mb-1">Заметки</p>
          <p className="text-sm text-amber-800">{readingPlan.notes}</p>
        </div>
      )}

      {/* Reading History */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100">
        <div className="px-5 pt-5 pb-4 border-b border-gray-50">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#0d3320]" />
            <h3 className="font-bold text-gray-900">История чтения</h3>
          </div>
        </div>
        <div className="p-5 space-y-3">
          {completedBooks.length === 0 ? (
            <p className="text-gray-400 text-sm text-center py-4">Нет завершённых книг</p>
          ) : (
            completedBooks.map((book) => (
              <div key={book.id} className="flex items-center gap-3 p-3 bg-emerald-50 rounded-xl">
                <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-gray-900 truncate">{book.title}</p>
                  <p className="text-xs text-gray-500">{book.author} · {book.totalPages} стр.</p>
                </div>
                <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-medium shrink-0">
                  Завершена
                </span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Unfinished Books */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100">
        <div className="px-5 pt-5 pb-4 border-b border-gray-50">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BookMarked className="w-4 h-4 text-[#0d3320]" />
              <h3 className="font-bold text-gray-900">Непрочитанные книги</h3>
            </div>
            <button
              onClick={() => setActiveTab('books')}
              className="text-xs text-[#0d3320] font-medium flex items-center gap-1 hover:underline"
            >
              Все книги <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>
        <div className="p-5 space-y-3">
          {unfinishedBooks.length === 0 ? (
            <p className="text-gray-400 text-sm text-center py-4">Все книги прочитаны!</p>
          ) : (
            unfinishedBooks.map((book) => {
              const prog = Math.round((book.currentPage / book.totalPages) * 100);
              const isCurrent = readingPlan.currentBookId === book.id;
              return (
                <div
                  key={book.id}
                  className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                    isCurrent ? 'bg-[#0d3320]/5 border-[#0d3320]/20' : 'border-gray-100 hover:bg-gray-50'
                  }`}
                >
                  <div
                    className="w-2 h-10 rounded-full shrink-0"
                    style={{ backgroundColor: book.coverColor }}
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-gray-900 truncate">
                      {book.title}
                      {isCurrent && (
                        <span className="ml-2 text-xs bg-[#0d3320] text-white px-2 py-0.5 rounded-full">
                          Текущая
                        </span>
                      )}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <div className="flex-1 h-1 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{ width: `${prog}%`, backgroundColor: book.coverColor }}
                        />
                      </div>
                      <span className="text-xs text-gray-400 shrink-0">{prog}%</span>
                    </div>
                  </div>
                  {!isCurrent && (
                    <button
                      onClick={() => handleSelectBook(book.id)}
                      className="text-xs bg-[#0d3320] text-white px-3 py-1.5 rounded-lg font-medium hover:bg-[#1a5e38] transition-colors flex items-center gap-1 shrink-0"
                    >
                      <Clock className="w-3 h-3" />
                      Начать
                    </button>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Select Book Modal */}
      {selectBookMode && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end sm:items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h3 className="font-bold text-gray-900">Выберите книгу</h3>
              <button onClick={() => setSelectBookMode(false)} className="text-gray-400 hover:text-gray-600">
                ✕
              </button>
            </div>
            <div className="p-3 space-y-2">
              {unfinishedBooks.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-400">Все книги прочитаны!</p>
                  <button
                    onClick={() => { setSelectBookMode(false); setActiveTab('books'); }}
                    className="mt-3 text-sm text-[#0d3320] font-medium hover:underline"
                  >
                    Добавить новую книгу →
                  </button>
                </div>
              ) : (
                unfinishedBooks.map((book) => {
                  const prog = Math.round((book.currentPage / book.totalPages) * 100);
                  const isCurrent = readingPlan.currentBookId === book.id;
                  return (
                    <button
                      key={book.id}
                      onClick={() => handleSelectBook(book.id)}
                      className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all hover:bg-gray-50 ${
                        isCurrent ? 'border-[#0d3320]/30 bg-[#0d3320]/5' : 'border-gray-100'
                      }`}
                    >
                      <div
                        className="w-3 h-12 rounded-full shrink-0"
                        style={{ backgroundColor: book.coverColor }}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm text-gray-900 truncate">{book.title}</p>
                        <p className="text-xs text-gray-500">{book.author}</p>
                        <div className="flex items-center gap-2 mt-1.5">
                          <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div
                              className="h-full rounded-full"
                              style={{ width: `${prog}%`, backgroundColor: book.coverColor }}
                            />
                          </div>
                          <span className="text-xs text-gray-400">{prog}%</span>
                        </div>
                      </div>
                      {isCurrent && (
                        <span className="text-xs bg-[#0d3320] text-white px-2 py-1 rounded-lg shrink-0">
                          Текущая
                        </span>
                      )}
                    </button>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
