import { BookOpen, Star, Mic, Users, BookMarked, Target, TrendingUp, ChevronRight, Clock } from 'lucide-react';
import { useLibraryStore } from '../store/useLibraryStore';

export default function HomePage() {
  const { books, lessons, fawaids, scholars, weeklyGoal, readingPlan, setActiveTab } = useLibraryStore();

  const completedBooks = books.filter((b) => b.isCompleted).length;
  const completedLessons = lessons.filter((l) => l.isCompleted).length;
  const favoriteFawaids = fawaids.filter((f) => f.isFavorite).length;

  const currentBook = readingPlan.currentBookId
    ? books.find((b) => b.id === readingPlan.currentBookId)
    : null;

  const pagesLeft = currentBook
    ? currentBook.totalPages - currentBook.currentPage
    : 0;

  const readingProgress = currentBook
    ? Math.round((currentBook.currentPage / currentBook.totalPages) * 100)
    : 0;

  const stats = [
    {
      label: 'Книг в библиотеке',
      value: books.length,
      sub: `${completedBooks} завершено`,
      icon: BookOpen,
      color: 'from-emerald-500 to-green-600',
      tab: 'books',
    },
    {
      label: 'Уроков пройдено',
      value: completedLessons,
      sub: `из ${lessons.length} всего`,
      icon: Mic,
      color: 'from-blue-500 to-indigo-600',
      tab: 'lessons',
    },
    {
      label: 'Фаваиды',
      value: fawaids.length,
      sub: `${favoriteFawaids} в избранном`,
      icon: Star,
      color: 'from-amber-500 to-orange-600',
      tab: 'fawaids',
    },
    {
      label: 'Биографии учёных',
      value: scholars.length,
      sub: 'Великие имамы',
      icon: Users,
      color: 'from-purple-500 to-violet-600',
      tab: 'scholars',
    },
  ];

  const recentFawaids = fawaids.slice(-3).reverse();

  return (
    <div className="space-y-8">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0d3320] to-[#1a5e38] p-8 text-white shadow-2xl">
        <div className="absolute top-0 right-0 w-64 h-64 opacity-5">
          <div className="text-9xl font-bold" style={{ fontFamily: 'Amiri, serif' }}>
            ب
          </div>
        </div>
        <div className="relative z-10">
          <p
            className="text-amber-300 text-2xl mb-3"
            style={{ fontFamily: 'Amiri, serif' }}
          >
            بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
          </p>
          <h2 className="text-3xl font-bold mb-2">Добро пожаловать</h2>
          <p className="text-green-200/80 text-base leading-relaxed max-w-xl">
            Salaf Library — ваша исламская цифровая библиотека. Книги, уроки, биографии учёных и ценные фаваиды на русском языке.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <button
              onClick={() => setActiveTab('books')}
              className="bg-amber-400 text-[#0d3320] px-5 py-2.5 rounded-xl font-semibold text-sm hover:bg-amber-300 transition-colors flex items-center gap-2"
            >
              <BookOpen className="w-4 h-4" />
              Читать книги
            </button>
            <button
              onClick={() => setActiveTab('plan')}
              className="bg-white/10 text-white px-5 py-2.5 rounded-xl font-semibold text-sm hover:bg-white/20 transition-colors flex items-center gap-2 border border-white/20"
            >
              <BookMarked className="w-4 h-4" />
              План чтения
            </button>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <button
              key={stat.label}
              onClick={() => setActiveTab(stat.tab)}
              className="group bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md hover:border-gray-200 transition-all text-left"
            >
              <div
                className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3 shadow-sm`}
              >
                <Icon className="w-5 h-5 text-white" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-sm font-medium text-gray-700 leading-tight">{stat.label}</p>
              <p className="text-xs text-gray-400 mt-0.5">{stat.sub}</p>
            </button>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Reading Plan Widget */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="flex items-center justify-between px-6 pt-6 pb-4">
            <div className="flex items-center gap-2">
              <BookMarked className="w-5 h-5 text-[#0d3320]" />
              <h3 className="font-bold text-gray-900">📖 План чтения</h3>
            </div>
            <button
              onClick={() => setActiveTab('plan')}
              className="text-sm text-[#0d3320] font-medium flex items-center gap-1 hover:underline"
            >
              Подробнее <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {currentBook ? (
            <div className="px-6 pb-6 space-y-4">
              <div className="bg-gradient-to-r from-[#0d3320]/5 to-emerald-50 rounded-xl p-4">
                <p className="text-xs text-gray-500 font-medium uppercase tracking-wide mb-1">Сегодня читаю</p>
                <p className="text-lg font-bold text-gray-900">{currentBook.title}</p>
                <p className="text-sm text-gray-500">{currentBook.author}</p>
              </div>

              {/* Progress bar */}
              <div>
                <div className="flex justify-between text-xs text-gray-500 mb-1.5">
                  <span>Страница {currentBook.currentPage} из {currentBook.totalPages}</span>
                  <span>{readingProgress}%</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#0d3320] to-emerald-500 rounded-full transition-all duration-500"
                    style={{ width: `${readingProgress}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 bg-amber-50 px-3 py-2 rounded-lg">
                  <Clock className="w-4 h-4 text-amber-600" />
                  <div>
                    <p className="text-xs text-amber-700 font-medium">Осталось</p>
                    <p className="text-sm font-bold text-amber-800">{pagesLeft} стр.</p>
                  </div>
                </div>
                <button
                  onClick={() => setActiveTab('plan')}
                  className="bg-[#0d3320] text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-[#1a5e38] transition-colors flex items-center gap-2"
                >
                  Продолжить →
                </button>
              </div>
            </div>
          ) : (
            <div className="px-6 pb-6 text-center py-8">
              <BookOpen className="w-10 h-10 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500 text-sm">Выберите книгу для чтения</p>
              <button
                onClick={() => setActiveTab('plan')}
                className="mt-3 bg-[#0d3320] text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-[#1a5e38] transition-colors"
              >
                Настроить план
              </button>
            </div>
          )}
        </div>

        {/* Weekly Goals Widget */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="flex items-center justify-between px-6 pt-6 pb-4">
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-[#0d3320]" />
              <h3 className="font-bold text-gray-900">🎯 Цели на неделю</h3>
            </div>
            <button
              onClick={() => setActiveTab('goals')}
              className="text-sm text-[#0d3320] font-medium flex items-center gap-1 hover:underline"
            >
              Подробнее <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="px-6 pb-6 space-y-4">
            {[
              {
                label: 'Книги',
                icon: '📚',
                ...weeklyGoal.books,
                color: 'bg-emerald-500',
              },
              {
                label: 'Уроки',
                icon: '🎧',
                ...weeklyGoal.lessons,
                color: 'bg-blue-500',
              },
              {
                label: 'Фаваиды',
                icon: '✨',
                ...weeklyGoal.fawaids,
                color: 'bg-amber-500',
              },
            ].map((goal) => {
              const pct = Math.min(Math.round((goal.completed / goal.target) * 100), 100);
              const isDone = goal.completed >= goal.target;
              return (
                <div key={goal.label}>
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <span>{goal.icon}</span>
                      <span className="text-sm font-medium text-gray-700">{goal.label}</span>
                      {isDone && (
                        <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-medium">
                          ✔ Выполнено
                        </span>
                      )}
                    </div>
                    <span className="text-sm font-bold text-gray-900">
                      {goal.completed} / {goal.target}
                    </span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${goal.color} rounded-full transition-all duration-500`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}

            <button
              onClick={() => setActiveTab('goals')}
              className="w-full mt-2 flex items-center justify-center gap-2 bg-[#0d3320]/5 hover:bg-[#0d3320]/10 text-[#0d3320] py-2.5 rounded-xl text-sm font-semibold transition-colors"
            >
              <TrendingUp className="w-4 h-4" />
              Управлять целями
            </button>
          </div>
        </div>
      </div>

      {/* Recent Fawaids */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100">
        <div className="flex items-center justify-between px-6 pt-6 pb-4">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-amber-500" />
            <h3 className="font-bold text-gray-900">Последние фаваиды</h3>
          </div>
          <button
            onClick={() => setActiveTab('fawaids')}
            className="text-sm text-[#0d3320] font-medium flex items-center gap-1 hover:underline"
          >
            Все фаваиды <ChevronRight className="w-4 h-4" />
          </button>
        </div>
        <div className="px-6 pb-6 space-y-3">
          {recentFawaids.map((f) => (
            <div
              key={f.id}
              className="border-l-4 border-amber-400 pl-4 py-2 bg-amber-50/50 rounded-r-xl"
            >
              <p className="text-sm text-gray-800 leading-relaxed line-clamp-2">«{f.text}»</p>
              <p className="text-xs text-gray-400 mt-1">— {f.source}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
