import { useState } from 'react';
import { Users, Search, ChevronDown, ChevronUp, BookOpen } from 'lucide-react';
import { useLibraryStore } from '../store/useLibraryStore';

const ERAS = ['Все', 'Сахабы', 'Табиины', 'Табии ат-Табиин', 'Поздние учёные', 'Современные учёные'];

export default function ScholarsPage() {
  const { scholars } = useLibraryStore();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('Все');
  const [expanded, setExpanded] = useState<string | null>(null);

  const filtered = scholars.filter((s) => {
    const matchSearch =
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.nameAr.includes(search);
    const matchFilter = filter === 'Все' || s.era === filter;
    return matchSearch && matchFilter;
  });

  const eraColors: Record<string, string> = {
    'Сахабы': 'bg-amber-100 text-amber-800',
    'Табиины': 'bg-emerald-100 text-emerald-800',
    'Табии ат-Табиин': 'bg-blue-100 text-blue-800',
    'Поздние учёные': 'bg-purple-100 text-purple-800',
    'Современные учёные': 'bg-gray-100 text-gray-700',
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Биографии учёных</h2>
        <p className="text-gray-500 text-sm mt-0.5">{scholars.length} великих имамов</p>
      </div>

      {/* Search & Filter */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Поиск учёных..."
            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320]"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {ERAS.map((era) => (
            <button
              key={era}
              onClick={() => setFilter(era)}
              className={`whitespace-nowrap px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                filter === era
                  ? 'bg-[#0d3320] text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {era}
            </button>
          ))}
        </div>
      </div>

      {/* Scholars List */}
      <div className="space-y-3">
        {filtered.map((scholar) => {
          const isOpen = expanded === scholar.id;
          return (
            <div
              key={scholar.id}
              className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-all"
            >
              <button
                onClick={() => setExpanded(isOpen ? null : scholar.id)}
                className="w-full flex items-center gap-4 p-4 text-left"
              >
                {/* Avatar */}
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0d3320] to-[#1a5e38] flex items-center justify-center shrink-0 shadow-sm">
                  <span
                    className="text-xl text-amber-300"
                    style={{ fontFamily: 'Amiri, serif' }}
                  >
                    {scholar.nameAr.charAt(scholar.nameAr.indexOf(' ') + 1) || scholar.nameAr.charAt(0)}
                  </span>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-bold text-gray-900 text-sm">{scholar.name}</h3>
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        eraColors[scholar.era] || 'bg-gray-100 text-gray-700'
                      }`}
                    >
                      {scholar.era}
                    </span>
                  </div>
                  <p
                    className="text-sm text-amber-700 mt-0.5"
                    style={{ fontFamily: 'Amiri, serif' }}
                  >
                    {scholar.nameAr}
                  </p>
                  <p className="text-xs text-gray-400 mt-0.5">
                    {scholar.birth} — {scholar.death}
                  </p>
                </div>

                <div className="shrink-0 text-gray-400">
                  {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </button>

              {isOpen && (
                <div className="px-4 pb-4 space-y-4 border-t border-gray-50 pt-4">
                  <p className="text-sm text-gray-600 leading-relaxed">{scholar.description}</p>

                  {scholar.books.length > 0 && (
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <BookOpen className="w-4 h-4 text-[#0d3320]" />
                        <span className="text-xs font-semibold text-gray-600 uppercase tracking-wide">
                          Труды
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {scholar.books.map((book) => (
                          <span
                            key={book}
                            className="text-xs bg-[#0d3320]/5 text-[#0d3320] px-3 py-1 rounded-lg font-medium border border-[#0d3320]/10"
                          >
                            {book}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16">
          <Users className="w-12 h-12 text-gray-200 mx-auto mb-3" />
          <p className="text-gray-400 font-medium">Учёные не найдены</p>
        </div>
      )}
    </div>
  );
}
