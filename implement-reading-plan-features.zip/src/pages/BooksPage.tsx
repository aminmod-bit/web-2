import { useState } from 'react';
import { BookOpen, Plus, Trash2, CheckCircle, Search, X } from 'lucide-react';
import { useLibraryStore, Book } from '../store/useLibraryStore';
import toast from 'react-hot-toast';

const CATEGORIES = ['Все', 'Акыда', 'Хадисы', 'Тафсир', 'Фикх', 'Биографии', 'Другое'];

const COVER_COLORS = [
  '#0d3320', '#1a5e38', '#2d5a1b', '#5c3317',
  '#1e3a5f', '#3d1a4f', '#4a1942', '#1a3a4a',
];

interface AddBookForm {
  title: string;
  author: string;
  category: string;
  totalPages: number;
  currentPage: number;
  description: string;
  coverColor: string;
}

export default function BooksPage() {
  const { books, addBook, deleteBook, completeBook, setReadingPlan } = useLibraryStore();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('Все');
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState<AddBookForm>({
    title: '',
    author: '',
    category: 'Акыда',
    totalPages: 100,
    currentPage: 0,
    description: '',
    coverColor: '#0d3320',
  });

  const filtered = books.filter((b) => {
    const matchSearch =
      b.title.toLowerCase().includes(search.toLowerCase()) ||
      b.author.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'Все' || b.category === filter;
    return matchSearch && matchFilter;
  });

  const handleAdd = () => {
    if (!form.title.trim() || !form.author.trim()) {
      toast.error('Заполните название и автора');
      return;
    }
    addBook({ ...form, isCompleted: false });
    toast.success('Книга добавлена!');
    setShowAdd(false);
    setForm({
      title: '',
      author: '',
      category: 'Акыда',
      totalPages: 100,
      currentPage: 0,
      description: '',
      coverColor: '#0d3320',
    });
  };

  const handleSetAsCurrentReading = (book: Book) => {
    setReadingPlan({ currentBookId: book.id });
    toast.success(`«${book.title}» — теперь ваша текущая книга`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Библиотека книг</h2>
          <p className="text-gray-500 text-sm mt-0.5">{books.length} книг в коллекции</p>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-2 bg-[#0d3320] text-white px-4 py-2.5 rounded-xl font-semibold text-sm hover:bg-[#1a5e38] transition-colors shadow-sm"
        >
          <Plus className="w-4 h-4" />
          Добавить
        </button>
      </div>

      {/* Search & Filter */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Поиск книг..."
            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320]"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`whitespace-nowrap px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                filter === cat
                  ? 'bg-[#0d3320] text-white shadow-sm'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Books Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((book) => {
          const progress = Math.round((book.currentPage / book.totalPages) * 100);
          return (
            <div
              key={book.id}
              className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow group"
            >
              {/* Book Cover Strip */}
              <div
                className="h-2"
                style={{ backgroundColor: book.coverColor }}
              />

              <div className="p-4 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-gray-900 text-sm leading-tight truncate">{book.title}</h3>
                    <p className="text-xs text-gray-500 mt-0.5 truncate">{book.author}</p>
                  </div>
                  <span
                    className="shrink-0 text-xs px-2 py-0.5 rounded-full font-medium"
                    style={{ backgroundColor: book.coverColor + '20', color: book.coverColor }}
                  >
                    {book.category}
                  </span>
                </div>

                {book.description && (
                  <p className="text-xs text-gray-500 leading-relaxed line-clamp-2">{book.description}</p>
                )}

                {/* Progress */}
                <div>
                  <div className="flex justify-between text-xs text-gray-500 mb-1">
                    <span>Стр. {book.currentPage}/{book.totalPages}</span>
                    <span>{progress}%</span>
                  </div>
                  <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${progress}%`,
                        backgroundColor: book.isCompleted ? '#10b981' : book.coverColor,
                      }}
                    />
                  </div>
                </div>

                {book.isCompleted && (
                  <div className="flex items-center gap-1.5 text-emerald-600 bg-emerald-50 px-3 py-1.5 rounded-lg">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span className="text-xs font-medium">Прочитана</span>
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-2 pt-1">
                  {!book.isCompleted && (
                    <>
                      <button
                        onClick={() => handleSetAsCurrentReading(book)}
                        className="flex-1 text-xs bg-[#0d3320] text-white py-1.5 rounded-lg font-medium hover:bg-[#1a5e38] transition-colors"
                      >
                        Читать
                      </button>
                      <button
                        onClick={() => {
                          completeBook(book.id);
                          toast.success('Книга отмечена как прочитанная!');
                        }}
                        className="flex-1 text-xs bg-emerald-50 text-emerald-700 py-1.5 rounded-lg font-medium hover:bg-emerald-100 transition-colors"
                      >
                        Завершить
                      </button>
                    </>
                  )}
                  <button
                    onClick={() => {
                      deleteBook(book.id);
                      toast.success('Книга удалена');
                    }}
                    className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16">
          <BookOpen className="w-12 h-12 text-gray-200 mx-auto mb-3" />
          <p className="text-gray-400 font-medium">Книги не найдены</p>
        </div>
      )}

      {/* Add Book Modal */}
      {showAdd && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end sm:items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h3 className="font-bold text-gray-900">Добавить книгу</h3>
              <button onClick={() => setShowAdd(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Название *</label>
                <input
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  placeholder="Китаб ат-Таухид"
                  className="mt-1 w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320]"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Автор *</label>
                <input
                  value={form.author}
                  onChange={(e) => setForm({ ...form, author: e.target.value })}
                  placeholder="Имя автора"
                  className="mt-1 w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320]"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Всего страниц</label>
                  <input
                    type="number"
                    value={form.totalPages}
                    onChange={(e) => setForm({ ...form, totalPages: Number(e.target.value) })}
                    className="mt-1 w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320]"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Текущая страница</label>
                  <input
                    type="number"
                    value={form.currentPage}
                    onChange={(e) => setForm({ ...form, currentPage: Number(e.target.value) })}
                    className="mt-1 w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320]"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Категория</label>
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="mt-1 w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320] bg-white"
                >
                  {CATEGORIES.filter((c) => c !== 'Все').map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Описание</label>
                <textarea
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  rows={3}
                  placeholder="Краткое описание книги..."
                  className="mt-1 w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 focus:border-[#0d3320] resize-none"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Цвет обложки</label>
                <div className="mt-2 flex gap-2 flex-wrap">
                  {COVER_COLORS.map((color) => (
                    <button
                      key={color}
                      onClick={() => setForm({ ...form, coverColor: color })}
                      className="w-8 h-8 rounded-full border-2 transition-all"
                      style={{
                        backgroundColor: color,
                        borderColor: form.coverColor === color ? '#f59e0b' : 'transparent',
                        transform: form.coverColor === color ? 'scale(1.2)' : 'scale(1)',
                      }}
                    />
                  ))}
                </div>
              </div>
            </div>
            <div className="p-5 border-t border-gray-100 flex gap-3">
              <button
                onClick={() => setShowAdd(false)}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-gray-600 bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                Отмена
              </button>
              <button
                onClick={handleAdd}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white bg-[#0d3320] hover:bg-[#1a5e38] transition-colors"
              >
                Добавить
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
