import { BookOpen, Home, Users, Mic, Star, BookMarked, Target } from 'lucide-react';
import { useLibraryStore } from '../store/useLibraryStore';

const tabs = [
  { id: 'home', label: 'Главная', icon: Home },
  { id: 'books', label: 'Книги', icon: BookOpen },
  { id: 'lessons', label: 'Уроки', icon: Mic },
  { id: 'fawaids', label: 'Фаваиды', icon: Star },
  { id: 'scholars', label: 'Учёные', icon: Users },
  { id: 'plan', label: 'Чтение', icon: BookMarked },
  { id: 'goals', label: 'Цели', icon: Target },
];

export default function Navbar() {
  const { activeTab, setActiveTab } = useLibraryStore();

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 min-h-screen bg-[#0d3320] text-white shadow-2xl fixed left-0 top-0 z-40">
        {/* Logo */}
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#1a5e38] flex items-center justify-center shadow-lg">
              <BookOpen className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-tight">Salaf Library</h1>
              <p className="text-xs text-green-300/70">Исламская библиотека</p>
            </div>
          </div>
        </div>

        {/* Arabic calligraphy decoration */}
        <div className="px-6 py-4 border-b border-white/10">
          <p className="font-amiri text-amber-300/80 text-center text-xl leading-relaxed" style={{ fontFamily: 'Amiri, serif' }}>
            بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
          </p>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? 'bg-amber-400 text-[#0d3320] shadow-lg shadow-amber-400/20'
                    : 'text-green-100/70 hover:text-white hover:bg-white/10'
                }`}
              >
                <Icon className="w-5 h-5 shrink-0" />
                {tab.label}
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-white/10">
          <p className="text-xs text-green-300/50 text-center">
            Версия 1.0 · Salaf Library
          </p>
        </div>
      </aside>

      {/* Mobile Bottom Nav */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0d3320] border-t border-white/10 flex">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 flex flex-col items-center gap-0.5 py-2 px-1 text-[10px] font-medium transition-all ${
                isActive ? 'text-amber-400' : 'text-green-300/60 hover:text-white'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-amber-400' : ''}`} />
              <span className="truncate w-full text-center">{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Mobile Top Header */}
      <header className="lg:hidden fixed top-0 left-0 right-0 z-40 bg-[#0d3320] text-white px-4 py-3 flex items-center gap-3 shadow-md">
        <div className="w-8 h-8 rounded-lg bg-[#1a5e38] flex items-center justify-center">
          <BookOpen className="w-4 h-4 text-amber-300" />
        </div>
        <div>
          <h1 className="text-base font-bold">Salaf Library</h1>
          <p className="text-[10px] text-green-300/70">Исламская библиотека</p>
        </div>
        <div className="ml-auto">
          <p className="font-amiri text-amber-300/80 text-lg" style={{ fontFamily: 'Amiri, serif' }}>
            بِسْمِ اللَّهِ
          </p>
        </div>
      </header>
    </>
  );
}
