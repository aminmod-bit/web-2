import { Toaster } from 'react-hot-toast';
import Navbar from './components/Navbar';
import HomePage from './pages/HomePage';
import BooksPage from './pages/BooksPage';
import LessonsPage from './pages/LessonsPage';
import FawaidsPage from './pages/FawaidsPage';
import ScholarsPage from './pages/ScholarsPage';
import ReadingPlanPage from './pages/ReadingPlanPage';
import GoalsPage from './pages/GoalsPage';
import { useLibraryStore } from './store/useLibraryStore';

export default function App() {
  const { activeTab } = useLibraryStore();

  const renderPage = () => {
    switch (activeTab) {
      case 'home':
        return <HomePage />;
      case 'books':
        return <BooksPage />;
      case 'lessons':
        return <LessonsPage />;
      case 'fawaids':
        return <FawaidsPage />;
      case 'scholars':
        return <ScholarsPage />;
      case 'plan':
        return <ReadingPlanPage />;
      case 'goals':
        return <GoalsPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 3000,
          style: {
            borderRadius: '12px',
            background: '#0d3320',
            color: '#fff',
            fontSize: '14px',
            fontWeight: '500',
          },
          success: {
            iconTheme: {
              primary: '#f59e0b',
              secondary: '#0d3320',
            },
          },
        }}
      />

      {/* Sidebar */}
      <Navbar />

      {/* Main Content */}
      <main className="lg:ml-64 pt-16 lg:pt-0 pb-24 lg:pb-0">
        <div className="max-w-4xl mx-auto px-4 py-6 lg:px-8 lg:py-8">
          {renderPage()}
        </div>
      </main>
    </div>
  );
}
