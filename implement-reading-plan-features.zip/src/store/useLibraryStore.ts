import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Book {
  id: string;
  title: string;
  author: string;
  category: string;
  totalPages: number;
  currentPage: number;
  coverColor: string;
  description: string;
  isCompleted: boolean;
  dateAdded: string;
}

export interface Lesson {
  id: string;
  title: string;
  scholar: string;
  duration: string;
  category: string;
  isCompleted: boolean;
  dateAdded: string;
}

export interface Faida {
  id: string;
  text: string;
  source: string;
  category: string;
  dateAdded: string;
  isFavorite: boolean;
}

export interface Scholar {
  id: string;
  name: string;
  nameAr: string;
  birth: string;
  death: string;
  era: string;
  description: string;
  books: string[];
}

export interface WeeklyGoal {
  books: { target: number; completed: number };
  lessons: { target: number; completed: number };
  fawaids: { target: number; completed: number };
  weekStart: string;
}

export interface ReadingPlan {
  currentBookId: string | null;
  dailyPages: number;
  startDate: string;
  notes: string;
}

interface LibraryState {
  books: Book[];
  lessons: Lesson[];
  fawaids: Faida[];
  scholars: Scholar[];
  weeklyGoal: WeeklyGoal;
  readingPlan: ReadingPlan;
  activeTab: string;

  // Actions
  setActiveTab: (tab: string) => void;
  addBook: (book: Omit<Book, 'id' | 'dateAdded'>) => void;
  updateBook: (id: string, updates: Partial<Book>) => void;
  deleteBook: (id: string) => void;
  setCurrentBookPage: (bookId: string, page: number) => void;
  completeBook: (bookId: string) => void;
  addLesson: (lesson: Omit<Lesson, 'id' | 'dateAdded'>) => void;
  completeLesson: (id: string) => void;
  deleteLesson: (id: string) => void;
  addFaida: (faida: Omit<Faida, 'id' | 'dateAdded'>) => void;
  toggleFavorite: (id: string) => void;
  deleteFaida: (id: string) => void;
  setReadingPlan: (plan: Partial<ReadingPlan>) => void;
  updateWeeklyGoal: (goal: Partial<WeeklyGoal>) => void;
  incrementGoal: (type: 'books' | 'lessons' | 'fawaids') => void;
}

const DEFAULT_BOOKS: Book[] = [
  {
    id: '1',
    title: 'Китаб ат-Таухид',
    author: 'Мухаммад ибн Абд аль-Ваххаб',
    category: 'Акыда',
    totalPages: 180,
    currentPage: 68,
    coverColor: '#1a4a2e',
    description: 'Фундаментальный труд по исламскому единобожию. Одна из важнейших книг в исламской библиотеке.',
    isCompleted: false,
    dateAdded: '2025-01-10',
  },
  {
    id: '2',
    title: 'Три основы',
    author: 'Мухаммад ибн Абд аль-Ваххаб',
    category: 'Акыда',
    totalPages: 48,
    currentPage: 48,
    coverColor: '#2d5a1b',
    description: 'Краткое изложение основ исламского вероубеждения — кто твой Господь, какова твоя религия, кто твой пророк.',
    isCompleted: true,
    dateAdded: '2025-01-05',
  },
  {
    id: '3',
    title: 'Рияд ас-Салихин',
    author: 'Имам ан-Навави',
    category: 'Хадисы',
    totalPages: 640,
    currentPage: 210,
    coverColor: '#0d3320',
    description: 'Сборник хадисов Пророка ﷺ, охватывающий все сферы жизни мусульманина.',
    isCompleted: false,
    dateAdded: '2025-01-15',
  },
  {
    id: '4',
    title: 'Мухтасар Сахих аль-Бухари',
    author: 'Аз-Зубайди',
    category: 'Хадисы',
    totalPages: 512,
    currentPage: 0,
    coverColor: '#5c3317',
    description: 'Сокращённая версия самого достоверного сборника хадисов в исламе.',
    isCompleted: false,
    dateAdded: '2025-01-20',
  },
  {
    id: '5',
    title: 'Усуль ас-Сунна',
    author: 'Имам Ахмад ибн Ханбал',
    category: 'Акыда',
    totalPages: 64,
    currentPage: 64,
    coverColor: '#1e3a5f',
    description: 'Основы Сунны от великого имама Ахмада ибн Ханбала — столпа Ахлю-Сунна.',
    isCompleted: true,
    dateAdded: '2025-01-01',
  },
  {
    id: '6',
    title: 'Зад аль-Масир',
    author: 'Ибн аль-Джаузи',
    category: 'Тафсир',
    totalPages: 890,
    currentPage: 120,
    coverColor: '#3d1a4f',
    description: 'Всеобъемлющий тафсир Корана от известного учёного Ибн аль-Джаузи.',
    isCompleted: false,
    dateAdded: '2025-01-18',
  },
];

const DEFAULT_LESSONS: Lesson[] = [
  {
    id: '1',
    title: 'Основы акыды — урок 1',
    scholar: 'Шейх Ибн Усаймин',
    duration: '45 мин',
    category: 'Акыда',
    isCompleted: true,
    dateAdded: '2025-01-10',
  },
  {
    id: '2',
    title: 'Толкование суры аль-Фатиха',
    scholar: 'Шейх аль-Фаузан',
    duration: '32 мин',
    category: 'Тафсир',
    isCompleted: true,
    dateAdded: '2025-01-12',
  },
  {
    id: '3',
    title: 'Хадис о намерении',
    scholar: 'Шейх аль-Альбани',
    duration: '28 мин',
    category: 'Хадисы',
    isCompleted: true,
    dateAdded: '2025-01-14',
  },
  {
    id: '4',
    title: 'Столпы ислама',
    scholar: 'Шейх Ибн Баз',
    duration: '55 мин',
    category: 'Фикх',
    isCompleted: false,
    dateAdded: '2025-01-16',
  },
  {
    id: '5',
    title: 'Условия молитвы',
    scholar: 'Шейх Ибн Усаймин',
    duration: '40 мин',
    category: 'Фикх',
    isCompleted: false,
    dateAdded: '2025-01-18',
  },
];

const DEFAULT_FAWAIDS: Faida[] = [
  {
    id: '1',
    text: 'Поистине, дела оцениваются только по намерениям, и поистине, каждому человеку достанется лишь то, что он намеревался обрести.',
    source: 'Хадис. Бухари, Муслим',
    category: 'Хадисы',
    dateAdded: '2025-01-10',
    isFavorite: true,
  },
  {
    id: '2',
    text: 'Знание — это основа, без которой дела лишены ценности. Ибо Аллах принимает лишь то, что совершается искренне ради Него и в соответствии с Сунной.',
    source: 'Ибн Раджаб аль-Ханбали',
    category: 'Акыда',
    dateAdded: '2025-01-12',
    isFavorite: false,
  },
  {
    id: '3',
    text: 'Терпение бывает трёх видов: терпение при исполнении повелений Аллаха, терпение при воздержании от запрещённого, и терпение при испытаниях, которые Аллах посылает.',
    source: 'Ибн аль-Каyyим',
    category: 'Тасаввур',
    dateAdded: '2025-01-15',
    isFavorite: true,
  },
  {
    id: '4',
    text: 'Мусульманин — это тот, от языка и руки которого в безопасности другие мусульмане.',
    source: 'Хадис. Бухари',
    category: 'Хадисы',
    dateAdded: '2025-01-16',
    isFavorite: false,
  },
  {
    id: '5',
    text: 'Кто встанет на путь поиска знаний — Аллах облегчит ему путь в рай.',
    source: 'Хадис. Муслим',
    category: 'Хадисы',
    dateAdded: '2025-01-20',
    isFavorite: true,
  },
  {
    id: '6',
    text: 'Вся праведность в том, чтобы иметь хороший нрав.',
    source: 'Хадис. Тирмизи',
    category: 'Ахляк',
    dateAdded: '2025-01-22',
    isFavorite: false,
  },
];

const DEFAULT_SCHOLARS: Scholar[] = [
  {
    id: '1',
    name: 'Имам аль-Бухари',
    nameAr: 'الإمام البخاري',
    birth: '194 г.х.',
    death: '256 г.х.',
    era: 'Табии ат-Табиин',
    description: 'Абу Абдуллах Мухаммад ибн Исмаил аль-Бухари — величайший мухаддис исламской уммы, автор самого достоверного сборника хадисов «Сахих аль-Бухари».',
    books: ['Сахих аль-Бухари', 'Аль-Адаб аль-Муфрад', 'Ат-Тарих аль-Кабир'],
  },
  {
    id: '2',
    name: 'Имам ан-Навави',
    nameAr: 'الإمام النووي',
    birth: '631 г.х.',
    death: '676 г.х.',
    era: 'Поздние учёные',
    description: 'Яхья ибн Шараф ан-Навави — великий учёный-шафиит, автор «Рияд ас-Салихин», «Арбаин ан-Навави» и многих других трудов.',
    books: ['Рияд ас-Салихин', 'Арбаин ан-Навави', 'Минхадж ат-Талибин'],
  },
  {
    id: '3',
    name: 'Ибн Таймийя',
    nameAr: 'ابن تيمية',
    birth: '661 г.х.',
    death: '728 г.х.',
    era: 'Поздние учёные',
    description: 'Таки ад-Дин Ахмад ибн Таймийя — великий учёный Ахлю-Сунна, муджаддид своего времени, автор сотен трудов по акыде, фикху и тафсиру.',
    books: ['Маджму аль-Фатава', 'Минхадж ас-Сунна', 'Аль-Акыда аль-Васитийя'],
  },
  {
    id: '4',
    name: 'Ибн аль-Каyyим',
    nameAr: 'ابن القيم',
    birth: '691 г.х.',
    death: '751 г.х.',
    era: 'Поздние учёные',
    description: 'Мухаммад ибн Абу Бакр ибн аль-Каyyим аль-Джаузийя — выдающийся ученик Ибн Таймийи, автор глубоких трудов по акыде, тафсиру и исправлению сердец.',
    books: ['Зад аль-Маад', 'Мадаридж ас-Саликин', 'Аль-Фаваид'],
  },
  {
    id: '5',
    name: 'Шейх Ибн Баз',
    nameAr: 'الشيخ ابن باز',
    birth: '1330 г.х.',
    death: '1420 г.х.',
    era: 'Современные учёные',
    description: 'Абд аль-Азиз ибн Абдуллах ибн Баз — Верховный муфтий Саудовской Аравии, один из крупнейших учёных XX века, учёный-энциклопедист.',
    books: ['Маджму аль-Фатава', 'Ат-Тахкик ва аль-Идах', 'Нур аля ад-Дарб'],
  },
  {
    id: '6',
    name: 'Шейх Ибн Усаймин',
    nameAr: 'الشيخ ابن عثيمين',
    birth: '1347 г.х.',
    death: '1421 г.х.',
    era: 'Современные учёные',
    description: 'Мухаммад ибн Салих аль-Усаймин — великий учёный-факих и мухаддис, известный своими подробными объяснениями классических текстов.',
    books: ['Шарх аль-Акыда аль-Васитийя', 'Усуль аль-Фикх', 'Рияд ас-Салихин (шарх)'],
  },
];

const getWeekStart = () => {
  const now = new Date();
  const day = now.getDay();
  const diff = now.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(now.setDate(diff)).toISOString().split('T')[0];
};

export const useLibraryStore = create<LibraryState>()(
  persist(
    (set, _get) => ({
      books: DEFAULT_BOOKS,
      lessons: DEFAULT_LESSONS,
      fawaids: DEFAULT_FAWAIDS,
      scholars: DEFAULT_SCHOLARS,
      weeklyGoal: {
        books: { target: 4, completed: 2 },
        lessons: { target: 18, completed: 10 },
        fawaids: { target: 56, completed: 28 },
        weekStart: getWeekStart(),
      },
      readingPlan: {
        currentBookId: '1',
        dailyPages: 15,
        startDate: new Date().toISOString().split('T')[0],
        notes: '',
      },
      activeTab: 'home',

      setActiveTab: (tab) => set({ activeTab: tab }),

      addBook: (book) =>
        set((state) => ({
          books: [
            ...state.books,
            {
              ...book,
              id: Date.now().toString(),
              dateAdded: new Date().toISOString().split('T')[0],
            },
          ],
        })),

      updateBook: (id, updates) =>
        set((state) => ({
          books: state.books.map((b) => (b.id === id ? { ...b, ...updates } : b)),
        })),

      deleteBook: (id) =>
        set((state) => ({
          books: state.books.filter((b) => b.id !== id),
          readingPlan:
            state.readingPlan.currentBookId === id
              ? { ...state.readingPlan, currentBookId: null }
              : state.readingPlan,
        })),

      setCurrentBookPage: (bookId, page) =>
        set((state) => ({
          books: state.books.map((b) =>
            b.id === bookId
              ? { ...b, currentPage: Math.min(page, b.totalPages) }
              : b
          ),
        })),

      completeBook: (bookId) =>
        set((state) => ({
          books: state.books.map((b) =>
            b.id === bookId
              ? { ...b, isCompleted: true, currentPage: b.totalPages }
              : b
          ),
          weeklyGoal: {
            ...state.weeklyGoal,
            books: {
              ...state.weeklyGoal.books,
              completed: Math.min(
                state.weeklyGoal.books.completed + 1,
                state.weeklyGoal.books.target
              ),
            },
          },
        })),

      addLesson: (lesson) =>
        set((state) => ({
          lessons: [
            ...state.lessons,
            {
              ...lesson,
              id: Date.now().toString(),
              dateAdded: new Date().toISOString().split('T')[0],
            },
          ],
        })),

      completeLesson: (id) =>
        set((state) => {
          const lesson = state.lessons.find((l) => l.id === id);
          if (!lesson || lesson.isCompleted) return state;
          return {
            lessons: state.lessons.map((l) =>
              l.id === id ? { ...l, isCompleted: true } : l
            ),
            weeklyGoal: {
              ...state.weeklyGoal,
              lessons: {
                ...state.weeklyGoal.lessons,
                completed: Math.min(
                  state.weeklyGoal.lessons.completed + 1,
                  state.weeklyGoal.lessons.target
                ),
              },
            },
          };
        }),

      deleteLesson: (id) =>
        set((state) => ({
          lessons: state.lessons.filter((l) => l.id !== id),
        })),

      addFaida: (faida) =>
        set((state) => ({
          fawaids: [
            ...state.fawaids,
            {
              ...faida,
              id: Date.now().toString(),
              dateAdded: new Date().toISOString().split('T')[0],
            },
          ],
          weeklyGoal: {
            ...state.weeklyGoal,
            fawaids: {
              ...state.weeklyGoal.fawaids,
              completed: Math.min(
                state.weeklyGoal.fawaids.completed + 1,
                state.weeklyGoal.fawaids.target
              ),
            },
          },
        })),

      toggleFavorite: (id) =>
        set((state) => ({
          fawaids: state.fawaids.map((f) =>
            f.id === id ? { ...f, isFavorite: !f.isFavorite } : f
          ),
        })),

      deleteFaida: (id) =>
        set((state) => ({
          fawaids: state.fawaids.filter((f) => f.id !== id),
        })),

      setReadingPlan: (plan) =>
        set((state) => ({
          readingPlan: { ...state.readingPlan, ...plan },
        })),

      updateWeeklyGoal: (goal) =>
        set((state) => ({
          weeklyGoal: { ...state.weeklyGoal, ...goal },
        })),

      incrementGoal: (type) =>
        set((state) => ({
          weeklyGoal: {
            ...state.weeklyGoal,
            [type]: {
              ...state.weeklyGoal[type],
              completed: Math.min(
                state.weeklyGoal[type].completed + 1,
                state.weeklyGoal[type].target
              ),
            },
          },
        })),
    }),
    {
      name: 'salaf-library-storage',
    }
  )
);
