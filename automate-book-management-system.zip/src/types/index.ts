export type SupportedLang = 'ru' | 'ar' | 'en';

export interface Book {
  id: string;
  title: string;
  titleAr?: string;
  titleEn?: string;
  author: string;
  authorId: string;
  category: string;
  categoryId: string;
  language: SupportedLang;
  pages: number;
  fileSize: string;
  fileSizeBytes: number;
  pdfUrl: string;
  coverUrl?: string;
  thumbUrl?: string;
  description?: string;
  descriptionAr?: string;
  descriptionEn?: string;
  tags?: string[];
  addedDate: string;
  importedAt: string;
  views: number;
  downloads: number;
  // Future e-commerce fields (not active yet)
  paperAvailable?: boolean;
  buyUrl?: string;
  price?: number;
  currency?: string;
  stock?: number;
  publisher?: string;
  isbn?: string;
}

export interface Author {
  id: string;
  name: string;
  nameAr?: string;
  nameEn?: string;
  biography?: string;
  biographyAr?: string;
  biographyEn?: string;
  biographyStatus: 'complete' | 'pending' | 'empty';
  born?: string;
  died?: string;
  era?: string;
  nationality?: string;
  nationalityAr?: string;
  avatar?: string;
  bookIds: string[];
  bookCount: number;
  addedDate: string;
}

export interface Category {
  id: string;
  slug: string;
  name: string;
  nameAr?: string;
  nameEn?: string;
  description?: string;
  icon?: string;
  color?: string;
  bookIds: string[];
  bookCount: number;
  parentId?: string;
  order: number;
}

export interface AudioItem {
  id: string;
  title: string;
  titleAr?: string;
  titleEn?: string;
  speaker: string;
  speakerId?: string;
  category: string;
  categoryId?: string;
  duration: string; // HH:MM:SS
  durationSeconds: number;
  audioUrl: string;
  coverUrl?: string;
  language: SupportedLang;
  description?: string;
  tags?: string[];
  addedDate: string;
  plays: number;
  downloads: number;
  lessonNumber?: number;
  seriesId?: string;
}

export interface Faid {
  id: string;
  text: string;
  textAr?: string;
  textEn?: string;
  source?: string;
  sourceAr?: string;
  author?: string;
  authorId?: string;
  topic?: string;
  topicId?: string;
  language: SupportedLang;
  addedDate: string;
  likes: number;
  tags?: string[];
}

export interface SearchIndexItem {
  id: string;
  type: 'book' | 'author' | 'audio' | 'faid';
  title: string;
  subtitle?: string;
  description?: string;
  language: SupportedLang;
  category?: string;
  tags?: string[];
  url: string;
  coverUrl?: string;
  addedDate: string;
}

export interface ImportLog {
  id: string;
  timestamp: string;
  fileName: string;
  status: 'success' | 'error' | 'duplicate' | 'processing';
  steps: ImportStep[];
  bookId?: string;
  error?: string;
}

export interface ImportStep {
  name: string;
  status: 'pending' | 'processing' | 'success' | 'error' | 'skipped';
  detail?: string;
}

export interface LibraryStats {
  totalBooks: number;
  totalAuthors: number;
  totalCategories: number;
  totalAudio: number;
  totalFavaids: number;
  booksRu: number;
  booksAr: number;
  booksEn: number;
  lastUpdated: string;
}

export interface ReadingPlan {
  id: string;
  name: string;
  bookIds: string[];
  books: ReadingPlanBook[];
  createdAt: string;
  updatedAt: string;
  targetDate?: string;
}

export interface ReadingPlanBook {
  bookId: string;
  currentPage: number;
  totalPages: number;
  status: 'not_started' | 'in_progress' | 'completed';
  startedAt?: string;
  completedAt?: string;
  notes?: string;
}

export type SortOption = 'newest' | 'oldest' | 'az' | 'za' | 'mostRead';
export type ContentType = 'book' | 'author' | 'audio' | 'faid' | 'all';
