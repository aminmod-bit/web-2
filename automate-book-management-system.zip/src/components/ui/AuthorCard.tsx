import { Link } from 'react-router-dom';
import { BookOpen, User, AlertCircle } from 'lucide-react';
import { Author } from '../../types';
import { cn } from '../../utils/cn';

interface AuthorCardProps {
  author: Author;
  className?: string;
}

export default function AuthorCard({ author, className }: AuthorCardProps) {
  return (
    <Link
      to={`/authors/${author.id}`}
      className={cn(
        'group flex flex-col bg-white rounded-2xl border border-slate-100 hover:border-emerald-200 hover:shadow-lg transition-all duration-200 overflow-hidden p-5',
        className
      )}
    >
      {/* Avatar */}
      <div className="flex items-start gap-4 mb-3">
        <div className="shrink-0 w-14 h-14 rounded-xl bg-gradient-to-br from-emerald-100 to-emerald-200 flex items-center justify-center overflow-hidden">
          {author.avatar ? (
            <img src={author.avatar} alt={author.name} className="w-full h-full object-cover" />
          ) : (
            <User size={24} className="text-emerald-600" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-bold text-slate-800 text-sm leading-snug group-hover:text-emerald-700 transition-colors line-clamp-2">
            {author.name}
          </h3>
          {author.nameAr && (
            <p className="text-xs text-slate-400 mt-0.5 font-arabic" dir="rtl">{author.nameAr}</p>
          )}
        </div>
      </div>

      {/* Biography status */}
      {author.biographyStatus === 'pending' && (
        <div className="flex items-center gap-1.5 mb-2 text-xs text-amber-600 bg-amber-50 px-2.5 py-1 rounded-lg">
          <AlertCircle size={12} />
          Биография требует заполнения
        </div>
      )}

      {/* Stats */}
      <div className="flex items-center justify-between mt-auto">
        <div className="flex items-center gap-1.5 text-xs text-slate-500">
          <BookOpen size={13} />
          <span>{author.bookCount} {author.bookCount === 1 ? 'книга' : author.bookCount < 5 ? 'книги' : 'книг'}</span>
        </div>
        {(author.born || author.died) && (
          <span className="text-xs text-slate-400">
            {author.born && `${author.born}`}
            {author.born && author.died && ' – '}
            {author.died && `${author.died}`}
          </span>
        )}
      </div>
    </Link>
  );
}
