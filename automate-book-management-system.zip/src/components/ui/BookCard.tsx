import { Link } from 'react-router-dom';
import { BookOpen, Download, Eye, FileText } from 'lucide-react';
import { Book } from '../../types';
import { cn } from '../../utils/cn';

interface BookCardProps {
  book: Book;
  variant?: 'grid' | 'list';
  className?: string;
}

const LANG_COLORS = {
  ru: 'bg-blue-100 text-blue-700',
  ar: 'bg-emerald-100 text-emerald-700',
  en: 'bg-purple-100 text-purple-700',
};

const LANG_LABELS = {
  ru: 'РУС',
  ar: 'عر',
  en: 'EN',
};

export default function BookCard({ book, variant = 'grid', className }: BookCardProps) {

  if (variant === 'list') {
    return (
      <Link
        to={`/books/${book.id}`}
        className={cn(
          'flex items-center gap-4 p-4 bg-white rounded-xl border border-slate-100 hover:border-emerald-200 hover:shadow-md transition-all group',
          className
        )}
      >
        {/* Cover thumbnail */}
        <div className="shrink-0 w-12 h-16 rounded-lg bg-gradient-to-br from-emerald-50 to-emerald-100 flex items-center justify-center border border-emerald-100 overflow-hidden">
          {book.coverUrl ? (
            <img src={book.coverUrl} alt={book.title} className="w-full h-full object-cover" />
          ) : (
            <BookOpen size={20} className="text-emerald-400" />
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-semibold text-slate-800 text-sm leading-snug line-clamp-1 group-hover:text-emerald-700 transition-colors">
              {book.title}
            </h3>
            <span className={cn('text-xs px-1.5 py-0.5 rounded font-medium shrink-0', LANG_COLORS[book.language])}>
              {LANG_LABELS[book.language]}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">{book.author}</p>
          <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-400">
            <span className="flex items-center gap-1">
              <FileText size={11} /> {book.pages} стр.
            </span>
            <span>{book.fileSize}</span>
            <span className="flex items-center gap-1">
              <Eye size={11} /> {book.views}
            </span>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link
      to={`/books/${book.id}`}
      className={cn(
        'group flex flex-col bg-white rounded-2xl border border-slate-100 hover:border-emerald-200 hover:shadow-lg transition-all duration-200 overflow-hidden',
        className
      )}
    >
      {/* Cover */}
      <div className="relative aspect-[3/4] bg-gradient-to-br from-emerald-50 to-slate-100 overflow-hidden">
        {book.coverUrl ? (
          <img
            src={book.coverUrl}
            alt={book.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-4">
            <div className="w-14 h-14 rounded-xl bg-white/80 flex items-center justify-center shadow-sm mb-3">
              <BookOpen size={24} className="text-emerald-500" />
            </div>
            <p className="text-center text-xs text-emerald-600 font-medium leading-tight line-clamp-3 px-2">
              {book.titleAr || book.title}
            </p>
          </div>
        )}

        {/* Language badge */}
        <div className="absolute top-2 left-2">
          <span className={cn('text-[10px] px-1.5 py-0.5 rounded font-bold uppercase', LANG_COLORS[book.language])}>
            {LANG_LABELS[book.language]}
          </span>
        </div>

        {/* Category badge */}
        <div className="absolute bottom-2 right-2">
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/30 text-white backdrop-blur-sm line-clamp-1 max-w-[80px]">
            {book.category}
          </span>
        </div>
      </div>

      {/* Info */}
      <div className="p-3 flex flex-col flex-1">
        <h3 className="font-semibold text-slate-800 text-sm leading-snug line-clamp-2 group-hover:text-emerald-700 transition-colors mb-1">
          {book.title}
        </h3>
        <p className="text-xs text-slate-500 line-clamp-1 mb-2">{book.author}</p>

        <div className="mt-auto flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1">
            <FileText size={11} />
            {book.pages} стр.
          </span>
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1">
              <Eye size={11} /> {book.views}
            </span>
            <span className="flex items-center gap-1">
              <Download size={11} /> {book.downloads}
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}
