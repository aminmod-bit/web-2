import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  BookOpen, Search, Menu, X, Globe,
  Home, Users, Tag, Headphones, Star, Settings, BookMarked
} from 'lucide-react';
import { useLibraryStore } from '../../store/libraryStore';
import { SupportedLang } from '../../types';

const LANGUAGES: { code: SupportedLang; label: string; flag: string; dir: 'ltr' | 'rtl' }[] = [
  { code: 'ru', label: 'Русский', flag: '🇷🇺', dir: 'ltr' },
  { code: 'ar', label: 'العربية', flag: '🇸🇦', dir: 'rtl' },
  { code: 'en', label: 'English', flag: '🇬🇧', dir: 'ltr' },
];

export default function Header() {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const { sidebarOpen, setSidebarOpen, setSearchQuery } = useLibraryStore();
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [localSearch, setLocalSearch] = useState('');

  const currentLang = i18n.language as SupportedLang;
  const currentLangInfo = LANGUAGES.find(l => l.code === currentLang) || LANGUAGES[0];

  const switchLanguage = (lang: SupportedLang) => {
    i18n.changeLanguage(lang);
    const dir = LANGUAGES.find(l => l.code === lang)?.dir || 'ltr';
    document.documentElement.dir = dir;
    document.documentElement.lang = lang;
    setLangMenuOpen(false);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (localSearch.trim()) {
      setSearchQuery(localSearch);
      navigate(`/search?q=${encodeURIComponent(localSearch)}`);
    }
  };

  const navItems = [
    { path: '/', icon: Home, label: t('nav.home') },
    { path: '/books', icon: BookOpen, label: t('nav.books') },
    { path: '/authors', icon: Users, label: t('nav.authors') },
    { path: '/categories', icon: Tag, label: t('nav.categories') },
    { path: '/audio', icon: Headphones, label: t('nav.audio') },
    { path: '/favaids', icon: Star, label: t('nav.favaids') },
    { path: '/reading-plans', icon: BookMarked, label: t('nav.readingPlans') },
    { path: '/admin', icon: Settings, label: t('nav.admin') },
  ];

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-emerald-100 shadow-sm">
        <div className="flex items-center h-16 px-4 gap-3 max-w-screen-2xl mx-auto">
          {/* Mobile menu button */}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="lg:hidden p-2 rounded-lg text-emerald-700 hover:bg-emerald-50 transition-colors"
            aria-label="Menu"
          >
            {sidebarOpen ? <X size={22} /> : <Menu size={22} />}
          </button>

          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 shrink-0">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-600 to-emerald-800 flex items-center justify-center shadow-sm">
              <BookOpen size={18} className="text-white" />
            </div>
            <div className="hidden sm:block">
              <div className="text-lg font-bold text-emerald-800 leading-tight">Salaf Library</div>
              <div className="text-[10px] text-emerald-500 leading-tight tracking-wide">المكتبة الإسلامية</div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-1 mx-4 flex-1">
            {navItems.slice(0, 6).map(({ path, icon: Icon, label }) => (
              <Link
                key={path}
                to={path}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  isActive(path)
                    ? 'bg-emerald-50 text-emerald-700 shadow-sm'
                    : 'text-slate-600 hover:text-emerald-700 hover:bg-emerald-50/60'
                }`}
              >
                <Icon size={15} />
                {label}
              </Link>
            ))}
          </nav>

          {/* Search bar */}
          <form onSubmit={handleSearch} className="flex-1 max-w-md hidden md:block">
            <div className="relative">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={localSearch}
                onChange={e => setLocalSearch(e.target.value)}
                placeholder={t('common.searchPlaceholder')}
                className="w-full pl-9 pr-4 py-2 text-sm rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-100 transition-all"
              />
            </div>
          </form>

          <div className="flex items-center gap-2 ml-auto">
            {/* Language switcher */}
            <div className="relative">
              <button
                onClick={() => setLangMenuOpen(!langMenuOpen)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 transition-all border border-slate-200"
              >
                <span className="text-base">{currentLangInfo.flag}</span>
                <span className="hidden sm:inline text-xs">{currentLangInfo.label}</span>
                <Globe size={13} className="text-slate-400" />
              </button>

              {langMenuOpen && (
                <div className="absolute right-0 top-full mt-1 bg-white rounded-xl shadow-lg border border-slate-100 overflow-hidden z-50 min-w-[140px]">
                  {LANGUAGES.map(lang => (
                    <button
                      key={lang.code}
                      onClick={() => switchLanguage(lang.code)}
                      className={`w-full flex items-center gap-2.5 px-4 py-2.5 text-sm hover:bg-emerald-50 transition-colors ${
                        currentLang === lang.code ? 'bg-emerald-50 text-emerald-700 font-medium' : 'text-slate-700'
                      }`}
                    >
                      <span className="text-base">{lang.flag}</span>
                      <span>{lang.label}</span>
                      {lang.dir === 'rtl' && <span className="text-xs text-slate-400 ml-auto">RTL</span>}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Admin link */}
            <Link
              to="/admin"
              className={`hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                isActive('/admin')
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 border border-slate-200'
              }`}
            >
              <Settings size={15} />
              <span className="hidden lg:inline">{t('nav.admin')}</span>
            </Link>
          </div>
        </div>

        {/* Mobile search */}
        <div className="md:hidden px-4 pb-3">
          <form onSubmit={handleSearch}>
            <div className="relative">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={localSearch}
                onChange={e => setLocalSearch(e.target.value)}
                placeholder={t('common.searchPlaceholder')}
                className="w-full pl-9 pr-4 py-2.5 text-sm rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-100"
              />
            </div>
          </form>
        </div>
      </header>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Mobile sidebar */}
      <aside className={`fixed left-0 top-0 bottom-0 z-50 w-72 bg-white shadow-2xl transform transition-transform duration-300 lg:hidden ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <div className="flex items-center justify-between p-4 border-b border-slate-100">
          <Link to="/" onClick={() => setSidebarOpen(false)} className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-600 to-emerald-800 flex items-center justify-center">
              <BookOpen size={16} className="text-white" />
            </div>
            <span className="font-bold text-emerald-800">Salaf Library</span>
          </Link>
          <button onClick={() => setSidebarOpen(false)} className="p-1.5 rounded-lg hover:bg-slate-100">
            <X size={20} className="text-slate-500" />
          </button>
        </div>
        <nav className="p-3 space-y-1">
          {navItems.map(({ path, icon: Icon, label }) => (
            <Link
              key={path}
              to={path}
              onClick={() => setSidebarOpen(false)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                isActive(path)
                  ? 'bg-emerald-50 text-emerald-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-emerald-700'
              }`}
            >
              <Icon size={18} />
              {label}
            </Link>
          ))}
        </nav>
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-slate-100">
          <div className="text-xs text-slate-400 text-center">
            © 2024 Salaf Library. All rights reserved.
          </div>
        </div>
      </aside>
    </>
  );
}
