import { ReactNode } from 'react';
import Header from './Header';

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      <main className="pt-16 md:pt-20 min-h-screen">
        {children}
      </main>
      <footer className="bg-emerald-900 text-white mt-16">
        <div className="max-w-screen-xl mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-9 h-9 rounded-xl bg-emerald-700 flex items-center justify-center">
                  <span className="text-white text-lg">📚</span>
                </div>
                <div>
                  <div className="font-bold text-lg">Salaf Library</div>
                  <div className="text-emerald-300 text-xs">المكتبة الإسلامية الرقمية</div>
                </div>
              </div>
              <p className="text-emerald-200 text-sm leading-relaxed max-w-sm">
                Исламская цифровая библиотека — тысячи книг, биографий, аудио и фаваидов
                саляфов на русском, арабском и английском языках.
              </p>
              <div className="flex gap-3 mt-4">
                <span className="text-2xl">🇷🇺</span>
                <span className="text-2xl">🇸🇦</span>
                <span className="text-2xl">🇬🇧</span>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-emerald-300 mb-3 text-sm uppercase tracking-wide">Библиотека</h4>
              <ul className="space-y-2 text-sm text-emerald-200">
                <li><a href="/books" className="hover:text-white transition-colors">Книги</a></li>
                <li><a href="/authors" className="hover:text-white transition-colors">Авторы</a></li>
                <li><a href="/categories" className="hover:text-white transition-colors">Категории</a></li>
                <li><a href="/audio" className="hover:text-white transition-colors">Аудио</a></li>
                <li><a href="/favaids" className="hover:text-white transition-colors">Фаваиды</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-emerald-300 mb-3 text-sm uppercase tracking-wide">Информация</h4>
              <ul className="space-y-2 text-sm text-emerald-200">
                <li><a href="/reading-plans" className="hover:text-white transition-colors">Планы чтения</a></li>
                <li><a href="/admin" className="hover:text-white transition-colors">Администрация</a></li>
                <li><a href="/search" className="hover:text-white transition-colors">Поиск</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-emerald-800 mt-10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-emerald-400 text-sm">
              © 2024 Salaf Library. Свободный доступ к исламским знаниям.
            </p>
            <p className="text-emerald-400 text-sm text-center" dir="rtl">
              مكتبة السلف — للعلم والدعوة
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
