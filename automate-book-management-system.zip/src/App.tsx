import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Suspense, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import './i18n';

import Layout from './components/layout/Layout';
import HomePage from './pages/HomePage';
import BooksPage from './pages/BooksPage';
import BookDetailPage from './pages/BookDetailPage';
import AuthorsPage from './pages/AuthorsPage';
import AuthorDetailPage from './pages/AuthorDetailPage';
import CategoriesPage from './pages/CategoriesPage';
import CategoryDetailPage from './pages/CategoryDetailPage';
import AudioPage from './pages/AudioPage';
import FavaidsPage from './pages/FavaidsPage';
import SearchPage from './pages/SearchPage';
import ReadingPlansPage from './pages/ReadingPlansPage';
import AdminPage from './pages/admin/AdminPage';
import AdminImportPage from './pages/admin/AdminImportPage';
import AdminBooksPage from './pages/admin/AdminBooksPage';
import AdminAuthorsPage from './pages/admin/AdminAuthorsPage';
import AdminCategoriesPage from './pages/admin/AdminCategoriesPage';
import AdminStatsPage from './pages/admin/AdminStatsPage';
import AdminSettingsPage from './pages/admin/AdminSettingsPage';

function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-slate-50">
      <div className="flex flex-col items-center gap-4">
        <div className="w-12 h-12 border-4 border-emerald-200 border-t-emerald-600 rounded-full animate-spin" />
        <p className="text-emerald-700 font-medium text-sm">Загрузка Salaf Library...</p>
      </div>
    </div>
  );
}

function AppContent() {
  const { i18n } = useTranslation();

  useEffect(() => {
    // Apply RTL for Arabic
    const dir = i18n.language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.dir = dir;
    document.documentElement.lang = i18n.language;
  }, [i18n.language]);

  return (
    <Layout>
      <Routes>
        <Route path="/" element={<HomePage />} />

        {/* Books */}
        <Route path="/books" element={<BooksPage />} />
        <Route path="/books/:id" element={<BookDetailPage />} />

        {/* Authors */}
        <Route path="/authors" element={<AuthorsPage />} />
        <Route path="/authors/:id" element={<AuthorDetailPage />} />

        {/* Categories */}
        <Route path="/categories" element={<CategoriesPage />} />
        <Route path="/categories/:slug" element={<CategoryDetailPage />} />

        {/* Audio */}
        <Route path="/audio" element={<AudioPage />} />

        {/* Favaids */}
        <Route path="/favaids" element={<FavaidsPage />} />

        {/* Search */}
        <Route path="/search" element={<SearchPage />} />

        {/* Reading Plans */}
        <Route path="/reading-plans" element={<ReadingPlansPage />} />

        {/* Admin */}
        <Route path="/admin" element={<AdminPage />}>
          <Route path="import" element={<AdminImportPage />} />
          <Route path="books" element={<AdminBooksPage />} />
          <Route path="authors" element={<AdminAuthorsPage />} />
          <Route path="categories" element={<AdminCategoriesPage />} />
          <Route path="stats" element={<AdminStatsPage />} />
          <Route path="settings" element={<AdminSettingsPage />} />
        </Route>

        {/* 404 */}
        <Route path="*" element={
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
            <div className="text-6xl mb-4">🔍</div>
            <h1 className="text-3xl font-bold text-slate-800 mb-2">404 — Страница не найдена</h1>
            <p className="text-slate-400 mb-6 max-w-sm">
              Запрошенная страница не существует. Возможно, она была удалена или перемещена.
            </p>
            <a
              href="/"
              className="inline-flex items-center gap-2 bg-emerald-600 text-white px-6 py-3 rounded-xl font-semibold text-sm hover:bg-emerald-700 transition-colors"
            >
              На главную
            </a>
          </div>
        } />
      </Routes>
    </Layout>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<LoadingSpinner />}>
        <AppContent />
      </Suspense>
    </BrowserRouter>
  );
}
