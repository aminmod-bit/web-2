import { create } from 'zustand';
import { Book, Author, Category, AudioItem, Faid, ImportLog, LibraryStats, ReadingPlan, SupportedLang } from '../types';
import { sampleBooks, sampleAuthors, sampleCategories, sampleAudio, sampleFavaids } from '../data/sampleData';

interface LibraryState {
  // Data
  books: Book[];
  authors: Author[];
  categories: Category[];
  audio: AudioItem[];
  favaids: Faid[];
  readingPlans: ReadingPlan[];
  importLogs: ImportLog[];

  // UI State
  isImporting: boolean;
  importProgress: number;
  currentImportFile: string;
  sidebarOpen: boolean;
  searchQuery: string;
  activeLanguageFilter: SupportedLang | 'all';
  activeCategoryFilter: string;
  activeSortOption: 'newest' | 'oldest' | 'az' | 'za' | 'mostRead';

  // Computed Stats
  stats: LibraryStats;

  // Actions
  setBooks: (books: Book[]) => void;
  addBook: (book: Book) => void;
  updateBook: (id: string, updates: Partial<Book>) => void;
  deleteBook: (id: string) => void;

  setAuthors: (authors: Author[]) => void;
  addAuthor: (author: Author) => void;
  updateAuthor: (id: string, updates: Partial<Author>) => void;
  deleteAuthor: (id: string) => void;

  setCategories: (categories: Category[]) => void;
  addCategory: (category: Category) => void;
  updateCategory: (id: string, updates: Partial<Category>) => void;

  addAudio: (audio: AudioItem) => void;
  addFaid: (faid: Faid) => void;

  setSidebarOpen: (open: boolean) => void;
  setSearchQuery: (query: string) => void;
  setLanguageFilter: (lang: SupportedLang | 'all') => void;
  setCategoryFilter: (categoryId: string) => void;
  setSortOption: (sort: 'newest' | 'oldest' | 'az' | 'za' | 'mostRead') => void;

  setImporting: (importing: boolean) => void;
  setImportProgress: (progress: number) => void;
  setCurrentImportFile: (file: string) => void;
  addImportLog: (log: ImportLog) => void;
  updateImportLog: (id: string, updates: Partial<ImportLog>) => void;

  addReadingPlan: (plan: ReadingPlan) => void;
  updateReadingPlan: (id: string, updates: Partial<ReadingPlan>) => void;
  deleteReadingPlan: (id: string) => void;

  incrementViews: (bookId: string) => void;
  incrementDownloads: (bookId: string) => void;

  computeStats: () => void;
}

const computeStatsFromState = (state: Partial<LibraryState>): LibraryStats => {
  const books = state.books || [];
  const authors = state.authors || [];
  const categories = state.categories || [];
  const audio = state.audio || [];
  const favaids = state.favaids || [];

  return {
    totalBooks: books.length,
    totalAuthors: authors.length,
    totalCategories: categories.length,
    totalAudio: audio.length,
    totalFavaids: favaids.length,
    booksRu: books.filter(b => b.language === 'ru').length,
    booksAr: books.filter(b => b.language === 'ar').length,
    booksEn: books.filter(b => b.language === 'en').length,
    lastUpdated: new Date().toISOString(),
  };
};

export const useLibraryStore = create<LibraryState>((set, get) => ({
  books: sampleBooks,
  authors: sampleAuthors,
  categories: sampleCategories,
  audio: sampleAudio,
  favaids: sampleFavaids,
  readingPlans: [],
  importLogs: [],

  isImporting: false,
  importProgress: 0,
  currentImportFile: '',
  sidebarOpen: false,
  searchQuery: '',
  activeLanguageFilter: 'all',
  activeCategoryFilter: '',
  activeSortOption: 'newest',

  stats: computeStatsFromState({
    books: sampleBooks,
    authors: sampleAuthors,
    categories: sampleCategories,
    audio: sampleAudio,
    favaids: sampleFavaids,
  }),

  setBooks: (books) => set((state) => ({
    books,
    stats: computeStatsFromState({ ...state, books }),
  })),

  addBook: (book) => set((state) => {
    const newBooks = [book, ...state.books];
    return {
      books: newBooks,
      stats: computeStatsFromState({ ...state, books: newBooks }),
    };
  }),

  updateBook: (id, updates) => set((state) => ({
    books: state.books.map(b => b.id === id ? { ...b, ...updates } : b),
  })),

  deleteBook: (id) => set((state) => {
    const newBooks = state.books.filter(b => b.id !== id);
    return {
      books: newBooks,
      stats: computeStatsFromState({ ...state, books: newBooks }),
    };
  }),

  setAuthors: (authors) => set((state) => ({
    authors,
    stats: computeStatsFromState({ ...state, authors }),
  })),

  addAuthor: (author) => set((state) => {
    const newAuthors = [author, ...state.authors];
    return {
      authors: newAuthors,
      stats: computeStatsFromState({ ...state, authors: newAuthors }),
    };
  }),

  updateAuthor: (id, updates) => set((state) => ({
    authors: state.authors.map(a => a.id === id ? { ...a, ...updates } : a),
  })),

  deleteAuthor: (id) => set((state) => {
    const newAuthors = state.authors.filter(a => a.id !== id);
    return {
      authors: newAuthors,
      stats: computeStatsFromState({ ...state, authors: newAuthors }),
    };
  }),

  setCategories: (categories) => set((state) => ({
    categories,
    stats: computeStatsFromState({ ...state, categories }),
  })),

  addCategory: (category) => set((state) => {
    const newCategories = [...state.categories, category];
    return {
      categories: newCategories,
      stats: computeStatsFromState({ ...state, categories: newCategories }),
    };
  }),

  updateCategory: (id, updates) => set((state) => ({
    categories: state.categories.map(c => c.id === id ? { ...c, ...updates } : c),
  })),

  addAudio: (audio) => set((state) => {
    const newAudio = [audio, ...state.audio];
    return {
      audio: newAudio,
      stats: computeStatsFromState({ ...state, audio: newAudio }),
    };
  }),

  addFaid: (faid) => set((state) => {
    const newFavaids = [faid, ...state.favaids];
    return {
      favaids: newFavaids,
      stats: computeStatsFromState({ ...state, favaids: newFavaids }),
    };
  }),

  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setSearchQuery: (query) => set({ searchQuery: query }),
  setLanguageFilter: (lang) => set({ activeLanguageFilter: lang }),
  setCategoryFilter: (categoryId) => set({ activeCategoryFilter: categoryId }),
  setSortOption: (sort) => set({ activeSortOption: sort }),

  setImporting: (importing) => set({ isImporting: importing }),
  setImportProgress: (progress) => set({ importProgress: progress }),
  setCurrentImportFile: (file) => set({ currentImportFile: file }),

  addImportLog: (log) => set((state) => ({
    importLogs: [log, ...state.importLogs].slice(0, 100),
  })),

  updateImportLog: (id, updates) => set((state) => ({
    importLogs: state.importLogs.map(l => l.id === id ? { ...l, ...updates } : l),
  })),

  addReadingPlan: (plan) => set((state) => ({
    readingPlans: [plan, ...state.readingPlans],
  })),

  updateReadingPlan: (id, updates) => set((state) => ({
    readingPlans: state.readingPlans.map(p => p.id === id ? { ...p, ...updates } : p),
  })),

  deleteReadingPlan: (id) => set((state) => ({
    readingPlans: state.readingPlans.filter(p => p.id !== id),
  })),

  incrementViews: (bookId) => set((state) => ({
    books: state.books.map(b => b.id === bookId ? { ...b, views: b.views + 1 } : b),
  })),

  incrementDownloads: (bookId) => set((state) => ({
    books: state.books.map(b => b.id === bookId ? { ...b, downloads: b.downloads + 1 } : b),
  })),

  computeStats: () => set((state) => ({
    stats: computeStatsFromState(state),
  })),
}));
