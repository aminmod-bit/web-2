import { Book, Author, Category, ImportLog, ImportStep, SupportedLang } from '../types';

// Language detection based on character sets and common words
export function detectLanguage(text: string): SupportedLang {
  if (!text) return 'ru';

  const arabicChars = (text.match(/[\u0600-\u06FF]/g) || []).length;
  const cyrillicChars = (text.match(/[а-яёА-ЯЁ]/g) || []).length;
  const latinChars = (text.match(/[a-zA-Z]/g) || []).length;

  const total = arabicChars + cyrillicChars + latinChars;
  if (total === 0) return 'ru';

  if (arabicChars / total > 0.3) return 'ar';
  if (cyrillicChars / total > 0.3) return 'ru';
  return 'en';
}

// Detect language from filename
export function detectLanguageFromFilename(filename: string): SupportedLang {
  const lower = filename.toLowerCase();
  const arabicKeywords = ['arab', 'kitab', 'al-', 'ibn', 'abu', 'قرآن', 'حديث'];
  const russianKeywords = ['ru_', '_ru', 'rus', 'перевод', 'исламский'];

  for (const kw of arabicKeywords) {
    if (lower.includes(kw)) return 'ar';
  }
  for (const kw of russianKeywords) {
    if (lower.includes(kw)) return 'ru';
  }

  // Check for Arabic Unicode characters in filename
  if (/[\u0600-\u06FF]/.test(filename)) return 'ar';
  if (/[а-яёА-ЯЁ]/.test(filename)) return 'ru';

  return 'ru';
}

// Extract title from filename
export function extractTitleFromFilename(filename: string): string {
  return filename
    .replace(/\.pdf$/i, '')
    .replace(/[-_]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

// Determine category from title and keywords
export function detectCategory(title: string, existingCategories: Category[]): string {
  const text = title.toLowerCase();

  const categoryKeywords: Record<string, string[]> = {
    'cat-aqeedah': ['акыда', 'таухид', 'единобожие', 'вера', 'aqeedah', 'tawhid', 'العقيدة', 'التوحيد', 'إيمان'],
    'cat-fiqh': ['фикх', 'намаз', 'пост', 'закят', 'fiqh', 'salat', 'الفقه', 'صلاة', 'زكاة'],
    'cat-hadith': ['хадис', 'сунна', 'hadith', 'sunnah', 'الحديث', 'السنة', 'بخاري', 'مسلم', 'бухари'],
    'cat-tafsir': ['тафсир', 'коран', 'tafsir', 'quran', 'التفسير', 'القرآن'],
    'cat-seerah': ['сира', 'жизнеописание', 'пророк', 'seerah', 'prophet', 'السيرة', 'النبي'],
    'cat-manhaj': ['манхадж', 'методология', 'manhaj', 'المنهج', 'منهاج'],
    'cat-history': ['история', 'исторический', 'history', 'التاريخ', 'تاريخ'],
    'cat-arabic': ['арабский', 'язык', 'arabic', 'grammar', 'اللغة', 'نحو', 'صرف'],
    'cat-ethics': ['нравственность', 'этика', 'адаб', 'ethics', 'adab', 'الأخلاق', 'الآداب'],
    'cat-dawah': ['даава', 'призыв', 'dawah', 'الدعوة'],
  };

  for (const [catId, keywords] of Object.entries(categoryKeywords)) {
    for (const kw of keywords) {
      if (text.includes(kw)) {
        const cat = existingCategories.find(c => c.id === catId);
        if (cat) return catId;
      }
    }
  }

  return 'cat-aqeedah'; // Default category
}

// Simulate PDF metadata extraction
export async function extractPDFMetadata(file: File): Promise<{
  title: string;
  author: string;
  pages: number;
  language: SupportedLang;
  fileSize: string;
  fileSizeBytes: number;
}> {
  return new Promise((resolve) => {
    const fileSizeBytes = file.size;
    const fileSizeMB = (fileSizeBytes / 1024 / 1024).toFixed(1);

    // Simulate async processing
    setTimeout(() => {
      const language = detectLanguageFromFilename(file.name);
      const title = extractTitleFromFilename(file.name);

      // Estimate pages from file size (rough estimate: ~50KB per page)
      const estimatedPages = Math.max(10, Math.round(fileSizeBytes / 51200));

      resolve({
        title,
        author: '',
        pages: estimatedPages,
        language,
        fileSize: `${fileSizeMB} МБ`,
        fileSizeBytes,
      });
    }, 500);
  });
}

// Generate a unique ID
export function generateId(prefix: string): string {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 8);
  return `${prefix}-${timestamp}-${random}`;
}

// Check if book already exists
export function checkDuplicate(title: string, existingBooks: Book[]): boolean {
  const normalizedTitle = title.toLowerCase().trim();
  return existingBooks.some(book =>
    book.title.toLowerCase().trim() === normalizedTitle ||
    (book.titleAr && book.titleAr.toLowerCase().trim() === normalizedTitle) ||
    (book.titleEn && book.titleEn.toLowerCase().trim() === normalizedTitle)
  );
}

// Find or create author
export function findOrCreateAuthor(
  authorName: string,
  existingAuthors: Author[]
): { author: Author; isNew: boolean } {
  if (!authorName || authorName.trim() === '') {
    const unknownAuthor = existingAuthors.find(a => a.id === 'author-unknown');
    if (unknownAuthor) {
      return { author: unknownAuthor, isNew: false };
    }
    const newUnknown: Author = {
      id: 'author-unknown',
      name: 'Автор не определён',
      nameAr: 'مؤلف غير محدد',
      nameEn: 'Unknown Author',
      biographyStatus: 'empty',
      bookIds: [],
      bookCount: 0,
      addedDate: new Date().toISOString().split('T')[0],
    };
    return { author: newUnknown, isNew: true };
  }

  const normalized = authorName.toLowerCase().trim();
  const existing = existingAuthors.find(a =>
    a.name.toLowerCase().trim() === normalized ||
    (a.nameAr && a.nameAr.toLowerCase().trim() === normalized) ||
    (a.nameEn && a.nameEn.toLowerCase().trim() === normalized)
  );

  if (existing) {
    return { author: existing, isNew: false };
  }

  const newAuthor: Author = {
    id: generateId('author'),
    name: authorName,
    biographyStatus: 'pending',
    bookIds: [],
    bookCount: 0,
    addedDate: new Date().toISOString().split('T')[0],
  };

  return { author: newAuthor, isNew: true };
}

// Format file size
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} Б`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} КБ`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} МБ`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(1)} ГБ`;
}

// Simulate cover generation
export async function generateCoverFromPDF(
  file: File,
  title: string,
  language: SupportedLang
): Promise<string> {
  // In a real implementation, this would use PDF.js to render the first page
  // and create a canvas-based cover image
  return new Promise((resolve) => {
    setTimeout(() => {
      // Return a placeholder cover URL (canvas-based cover would go here)
      resolve('');
    }, 800);
  });
}

// Main smart import function
export async function performSmartImport(
  file: File,
  existingBooks: Book[],
  existingAuthors: Author[],
  existingCategories: Category[],
  callbacks: {
    onStepUpdate: (stepName: string, status: ImportStep['status'], detail?: string) => void;
    onProgress: (progress: number) => void;
  }
): Promise<{
  book?: Book;
  author?: Author;
  isNewAuthor?: boolean;
  isDuplicate?: boolean;
  error?: string;
}> {
  const steps = [
    'detectingLanguage',
    'extractingMetadata',
    'checkingDuplicate',
    'findingAuthor',
    'detectingCategory',
    'generatingCover',
    'updatingIndex',
  ];

  let progress = 0;
  const progressStep = 100 / steps.length;

  try {
    // Step 1: Detect language
    callbacks.onStepUpdate('detectingLanguage', 'processing');
    await delay(600);
    const language = detectLanguageFromFilename(file.name);
    callbacks.onStepUpdate('detectingLanguage', 'success', languageLabel(language));
    progress += progressStep;
    callbacks.onProgress(progress);

    // Step 2: Extract metadata
    callbacks.onStepUpdate('extractingMetadata', 'processing');
    const metadata = await extractPDFMetadata(file);
    callbacks.onStepUpdate('extractingMetadata', 'success', `"${metadata.title}", ${metadata.pages} страниц`);
    progress += progressStep;
    callbacks.onProgress(progress);

    // Step 3: Check duplicate
    callbacks.onStepUpdate('checkingDuplicate', 'processing');
    await delay(400);
    const isDuplicate = checkDuplicate(metadata.title, existingBooks);
    if (isDuplicate) {
      callbacks.onStepUpdate('checkingDuplicate', 'error', 'Книга уже существует в библиотеке');
      return { isDuplicate: true };
    }
    callbacks.onStepUpdate('checkingDuplicate', 'success', 'Книга новая');
    progress += progressStep;
    callbacks.onProgress(progress);

    // Step 4: Find or create author
    callbacks.onStepUpdate('findingAuthor', 'processing');
    await delay(500);
    const { author, isNew: isNewAuthor } = findOrCreateAuthor(metadata.author, existingAuthors);
    callbacks.onStepUpdate(
      'findingAuthor',
      'success',
      isNewAuthor ? `Создан новый автор: ${author.name}` : `Найден автор: ${author.name}`
    );
    progress += progressStep;
    callbacks.onProgress(progress);

    // Step 5: Detect category
    callbacks.onStepUpdate('detectingCategory', 'processing');
    await delay(400);
    const categoryId = detectCategory(metadata.title, existingCategories);
    const category = existingCategories.find(c => c.id === categoryId);
    callbacks.onStepUpdate('detectingCategory', 'success', category?.name || 'Акыда');
    progress += progressStep;
    callbacks.onProgress(progress);

    // Step 6: Generate cover
    callbacks.onStepUpdate('generatingCover', 'processing');
    const coverUrl = await generateCoverFromPDF(file, metadata.title, language);
    callbacks.onStepUpdate('generatingCover', 'success', coverUrl ? 'Обложка создана' : 'Обложка будет сгенерирована позже');
    progress += progressStep;
    callbacks.onProgress(progress);

    // Step 7: Update index
    callbacks.onStepUpdate('updatingIndex', 'processing');
    await delay(400);

    // Create the book object
    const bookId = generateId('book');
    const now = new Date();
    const newBook: Book = {
      id: bookId,
      title: metadata.title,
      author: author.name,
      authorId: author.id,
      category: category?.name || 'Акыда',
      categoryId,
      language,
      pages: metadata.pages,
      fileSize: metadata.fileSize,
      fileSizeBytes: metadata.fileSizeBytes,
      pdfUrl: `/books/${file.name}`,
      coverUrl: coverUrl || undefined,
      addedDate: now.toISOString().split('T')[0],
      importedAt: now.toISOString(),
      views: 0,
      downloads: 0,
    };

    callbacks.onStepUpdate('updatingIndex', 'success', 'Книга добавлена в индекс поиска');
    progress = 100;
    callbacks.onProgress(progress);

    return { book: newBook, author, isNewAuthor };

  } catch (err) {
    return { error: err instanceof Error ? err.message : 'Неизвестная ошибка' };
  }
}

function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function languageLabel(lang: SupportedLang): string {
  const labels = { ru: 'Русский', ar: 'Арабский', en: 'Английский' };
  return labels[lang];
}

// Generate books.json content
export function generateBooksJSON(books: Book[]): string {
  return JSON.stringify({
    generated: new Date().toISOString(),
    total: books.length,
    books: books.map(b => ({
      id: b.id,
      title: b.title,
      titleAr: b.titleAr,
      titleEn: b.titleEn,
      author: b.author,
      authorId: b.authorId,
      category: b.category,
      categoryId: b.categoryId,
      language: b.language,
      pages: b.pages,
      fileSize: b.fileSize,
      pdfUrl: b.pdfUrl,
      coverUrl: b.coverUrl,
      addedDate: b.addedDate,
    })),
  }, null, 2);
}

// Generate authors.json content
export function generateAuthorsJSON(authors: Author[]): string {
  return JSON.stringify({
    generated: new Date().toISOString(),
    total: authors.length,
    authors,
  }, null, 2);
}

// Generate categories.json content
export function generateCategoriesJSON(categories: Category[]): string {
  return JSON.stringify({
    generated: new Date().toISOString(),
    total: categories.length,
    categories,
  }, null, 2);
}

// Generate search index
export function generateSearchIndex(books: Book[], authors: Author[]): string {
  const index = [
    ...books.map(b => ({
      id: b.id,
      type: 'book',
      title: b.title,
      titleAr: b.titleAr,
      titleEn: b.titleEn,
      author: b.author,
      category: b.category,
      language: b.language,
      url: `/books/${b.id}`,
      coverUrl: b.coverUrl,
      addedDate: b.addedDate,
    })),
    ...authors.map(a => ({
      id: a.id,
      type: 'author',
      title: a.name,
      titleAr: a.nameAr,
      titleEn: a.nameEn,
      url: `/authors/${a.id}`,
      avatar: a.avatar,
      addedDate: a.addedDate,
    })),
  ];

  return JSON.stringify({
    generated: new Date().toISOString(),
    total: index.length,
    index,
  }, null, 2);
}

// Generate sitemap.xml
export function generateSitemap(books: Book[], authors: Author[], baseUrl: string = 'https://salaf-library.com'): string {
  const now = new Date().toISOString().split('T')[0];

  const urls = [
    `<url><loc>${baseUrl}/</loc><changefreq>daily</changefreq><priority>1.0</priority></url>`,
    `<url><loc>${baseUrl}/books</loc><changefreq>daily</changefreq><priority>0.9</priority></url>`,
    `<url><loc>${baseUrl}/authors</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>`,
    `<url><loc>${baseUrl}/categories</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>`,
    `<url><loc>${baseUrl}/audio</loc><changefreq>daily</changefreq><priority>0.8</priority></url>`,
    `<url><loc>${baseUrl}/favaids</loc><changefreq>daily</changefreq><priority>0.7</priority></url>`,
    ...books.map(b => `<url><loc>${baseUrl}/books/${b.id}</loc><lastmod>${b.addedDate}</lastmod><changefreq>monthly</changefreq><priority>0.7</priority></url>`),
    ...authors.map(a => `<url><loc>${baseUrl}/authors/${a.id}</loc><lastmod>${a.addedDate}</lastmod><changefreq>monthly</changefreq><priority>0.6</priority></url>`),
  ];

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <!-- Generated: ${now} -->
${urls.join('\n')}
</urlset>`;
}

// Generate RSS feed
export function generateRSS(books: Book[], baseUrl: string = 'https://salaf-library.com'): string {
  const now = new Date().toUTCString();
  const recentBooks = [...books]
    .sort((a, b) => new Date(b.importedAt).getTime() - new Date(a.importedAt).getTime())
    .slice(0, 20);

  const items = recentBooks.map(b => `
    <item>
      <title><![CDATA[${b.title}]]></title>
      <link>${baseUrl}/books/${b.id}</link>
      <guid isPermaLink="true">${baseUrl}/books/${b.id}</guid>
      <description><![CDATA[${b.description || `Книга "${b.title}" автора ${b.author}`}]]></description>
      <pubDate>${new Date(b.importedAt).toUTCString()}</pubDate>
      <category><![CDATA[${b.category}]]></category>
      <author>${b.author}</author>
    </item>`).join('');

  return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>Salaf Library — Новые книги</title>
    <link>${baseUrl}</link>
    <description>Новые книги в исламской цифровой библиотеке Salaf Library</description>
    <language>ru</language>
    <lastBuildDate>${now}</lastBuildDate>
    <atom:link href="${baseUrl}/rss.xml" rel="self" type="application/rss+xml"/>
    ${items}
  </channel>
</rss>`;
}
