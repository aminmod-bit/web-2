import { Link, Outlet, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Upload, BookOpen, Users, Tag, BarChart3, Settings, Database,
  ChevronRight
} from 'lucide-react';
import { useLibraryStore } from '../../store/libraryStore';

export default function AdminPage() {
  const { t } = useTranslation();
  const { stats } = useLibraryStore();
  const location = useLocation();

  const isRoot = location.pathname === '/admin';

  const menuItems = [
    { path: '/admin/import', icon: Upload, label: t('admin.importBooks'), desc: 'Smart Import PDF' },
    { path: '/admin/books', icon: BookOpen, label: t('admin.manageBooks'), desc: `${stats.totalBooks} книг` },
    { path: '/admin/authors', icon: Users, label: t('admin.manageAuthors'), desc: `${stats.totalAuthors} авторов` },
    { path: '/admin/categories', icon: Tag, label: t('admin.manageCategories'), desc: `${stats.totalCategories} категорий` },
    { path: '/admin/stats', icon: BarChart3, label: t('admin.statistics'), desc: 'Аналитика' },
    { path: '/admin/settings', icon: Settings, label: t('admin.settings'), desc: 'Конфигурация' },
  ];

  const isActive = (path: string) => location.pathname === path || location.pathname.startsWith(path + '/');

  return (
    <div className="max-w-screen-xl mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-slate-800">{t('admin.title')}</h1>
        <p className="text-slate-500 mt-1">{t('admin.subtitle')}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          {/* Stats cards */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            {[
              { label: 'Книги', value: stats.totalBooks, color: 'emerald' },
              { label: 'Авторы', value: stats.totalAuthors, color: 'blue' },
              { label: 'Категории', value: stats.totalCategories, color: 'purple' },
              { label: 'Аудио', value: stats.totalAudio, color: 'orange' },
            ].map(({ label, value, color }) => (
              <div key={label} className={`bg-${color}-50 border border-${color}-100 rounded-xl p-3`}>
                <div className={`text-xl font-black text-${color}-700`}>{value}</div>
                <div className="text-xs text-slate-500">{label}</div>
              </div>
            ))}
          </div>

          {/* Navigation */}
          <nav className="bg-white border border-slate-100 rounded-2xl overflow-hidden shadow-sm">
            {menuItems.map(({ path, icon: Icon, label, desc }) => (
              <Link
                key={path}
                to={path}
                className={`flex items-center gap-3 px-4 py-3.5 border-b border-slate-50 last:border-0 transition-all ${
                  isActive(path)
                    ? 'bg-emerald-50 text-emerald-700'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-emerald-700'
                }`}
              >
                <Icon size={17} className="shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm">{label}</div>
                  <div className="text-xs text-slate-400">{desc}</div>
                </div>
                <ChevronRight size={14} className="shrink-0 opacity-40" />
              </Link>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="lg:col-span-3">
          {isRoot ? (
            <div>
              {/* Quick actions */}
              <div className="bg-gradient-to-br from-emerald-800 to-emerald-900 rounded-2xl p-6 text-white mb-6">
                <h2 className="text-lg font-bold mb-1">Быстрые действия</h2>
                <p className="text-emerald-200 text-sm mb-4">Наиболее используемые функции</p>
                <div className="flex flex-wrap gap-3">
                  <Link
                    to="/admin/import"
                    className="flex items-center gap-2 bg-white/20 hover:bg-white/30 px-4 py-2.5 rounded-xl text-sm font-medium transition-colors"
                  >
                    <Upload size={15} />
                    Импортировать книги
                  </Link>
                  <Link
                    to="/admin/authors"
                    className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2.5 rounded-xl text-sm font-medium transition-colors"
                  >
                    <Users size={15} />
                    Управление авторами
                  </Link>
                  <Link
                    to="/admin/stats"
                    className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2.5 rounded-xl text-sm font-medium transition-colors"
                  >
                    <BarChart3 size={15} />
                    Статистика
                  </Link>
                </div>
              </div>

              {/* Menu cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {menuItems.map(({ path, icon: Icon, label, desc }) => (
                  <Link
                    key={path}
                    to={path}
                    className="group flex items-center gap-4 bg-white border border-slate-100 hover:border-emerald-200 rounded-2xl p-5 transition-all hover:shadow-md"
                  >
                    <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center shrink-0 group-hover:bg-emerald-200 transition-colors">
                      <Icon size={22} className="text-emerald-700" />
                    </div>
                    <div className="flex-1">
                      <div className="font-bold text-slate-800 group-hover:text-emerald-700 transition-colors">{label}</div>
                      <div className="text-sm text-slate-400 mt-0.5">{desc}</div>
                    </div>
                    <ChevronRight size={18} className="text-slate-300 group-hover:text-emerald-500 transition-colors" />
                  </Link>
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm">
              <Outlet />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
