import { useState } from 'react';
import { Search, CheckCircle, AlertCircle, User, X } from 'lucide-react';
import { useLibraryStore } from '../../store/libraryStore';

export default function AdminAuthorsPage() {
  const { authors, updateAuthor } = useLibraryStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<{ biography: string; biographyAr: string; born: string; died: string; nationality: string }>({
    biography: '',
    biographyAr: '',
    born: '',
    died: '',
    nationality: '',
  });

  const filteredAuthors = authors.filter(a =>
    !searchQuery ||
    a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (a.nameAr && a.nameAr.includes(searchQuery))
  );

  const startEdit = (authorId: string) => {
    const author = authors.find(a => a.id === authorId);
    if (!author) return;
    setEditingId(authorId);
    setEditForm({
      biography: author.biography || '',
      biographyAr: author.biographyAr || '',
      born: author.born || '',
      died: author.died || '',
      nationality: author.nationality || '',
    });
  };

  const saveEdit = () => {
    if (!editingId) return;
    updateAuthor(editingId, {
      biography: editForm.biography || undefined,
      biographyAr: editForm.biographyAr || undefined,
      born: editForm.born || undefined,
      died: editForm.died || undefined,
      nationality: editForm.nationality || undefined,
      biographyStatus: editForm.biography ? 'complete' : 'pending',
    });
    setEditingId(null);
  };

  const pendingCount = authors.filter(a => a.biographyStatus === 'pending').length;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Управление авторами</h2>
          <p className="text-sm text-slate-400 mt-0.5">
            {authors.length} авторов
            {pendingCount > 0 && (
              <span className="ml-2 text-amber-600">· {pendingCount} требуют биографии</span>
            )}
          </p>
        </div>
      </div>

      {pendingCount > 0 && (
        <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-100 rounded-xl mb-4 text-sm text-amber-700">
          <AlertCircle size={15} className="shrink-0" />
          {pendingCount} авторов ожидают заполнения биографии
        </div>
      )}

      <div className="relative mb-4">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          placeholder="Поиск авторов..."
          className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-emerald-400 focus:outline-none text-sm"
        />
        {searchQuery && (
          <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2">
            <X size={14} className="text-slate-400" />
          </button>
        )}
      </div>

      <div className="space-y-3">
        {filteredAuthors.map(author => (
          <div key={author.id} className="bg-slate-50 hover:bg-white border border-transparent hover:border-slate-200 rounded-xl transition-all">
            {editingId === author.id ? (
              <div className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-slate-800">{author.name}</h3>
                  <button onClick={() => setEditingId(null)} className="p-1 hover:bg-slate-200 rounded-lg">
                    <X size={15} className="text-slate-500" />
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Год рождения</label>
                    <input
                      type="text"
                      value={editForm.born}
                      onChange={e => setEditForm(f => ({ ...f, born: e.target.value }))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-sm focus:border-emerald-400 focus:outline-none"
                      placeholder="например, 1234 / н.э."
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Год смерти</label>
                    <input
                      type="text"
                      value={editForm.died}
                      onChange={e => setEditForm(f => ({ ...f, died: e.target.value }))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-sm focus:border-emerald-400 focus:outline-none"
                      placeholder="например, 1321"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-xs font-medium text-slate-500 mb-1">Происхождение</label>
                    <input
                      type="text"
                      value={editForm.nationality}
                      onChange={e => setEditForm(f => ({ ...f, nationality: e.target.value }))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-sm focus:border-emerald-400 focus:outline-none"
                      placeholder="Страна / регион"
                    />
                  </div>
                </div>
                <div className="mb-3">
                  <label className="block text-xs font-medium text-slate-500 mb-1">Биография (русский)</label>
                  <textarea
                    value={editForm.biography}
                    onChange={e => setEditForm(f => ({ ...f, biography: e.target.value }))}
                    rows={4}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-sm focus:border-emerald-400 focus:outline-none resize-none"
                    placeholder="Введите биографию на русском языке..."
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-xs font-medium text-slate-500 mb-1">Биография (арабский)</label>
                  <textarea
                    value={editForm.biographyAr}
                    onChange={e => setEditForm(f => ({ ...f, biographyAr: e.target.value }))}
                    rows={4}
                    dir="rtl"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-sm focus:border-emerald-400 focus:outline-none resize-none font-arabic"
                    placeholder="أدخل السيرة الذاتية باللغة العربية..."
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={saveEdit}
                    className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-emerald-700 transition-colors"
                  >
                    <CheckCircle size={14} />
                    Сохранить
                  </button>
                  <button
                    onClick={() => setEditingId(null)}
                    className="px-4 py-2 rounded-lg text-sm border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors"
                  >
                    Отмена
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3 p-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center shrink-0">
                  <User size={18} className="text-emerald-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm text-slate-800">{author.name}</div>
                  {author.nameAr && (
                    <div className="text-xs text-slate-400 font-arabic" dir="rtl">{author.nameAr}</div>
                  )}
                  <div className="text-xs text-slate-400 mt-0.5">{author.bookCount} книг</div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {author.biographyStatus === 'complete' && (
                    <span className="flex items-center gap-1 text-xs text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                      <CheckCircle size={11} /> Готово
                    </span>
                  )}
                  {author.biographyStatus === 'pending' && (
                    <span className="flex items-center gap-1 text-xs text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">
                      <AlertCircle size={11} /> Требует заполнения
                    </span>
                  )}
                  <button
                    onClick={() => startEdit(author.id)}
                    className="px-3 py-1.5 rounded-lg text-xs border border-slate-200 text-slate-600 hover:border-emerald-200 hover:bg-emerald-50 hover:text-emerald-700 transition-all"
                  >
                    Редактировать
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
