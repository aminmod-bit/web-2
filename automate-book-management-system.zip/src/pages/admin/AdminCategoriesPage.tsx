import { useLibraryStore } from '../../store/libraryStore';
import { BookOpen, Tag } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function AdminCategoriesPage() {
  const { categories, books } = useLibraryStore();

  const categoriesWithCount = categories.map(cat => ({
    ...cat,
    actualBookCount: books.filter(b => b.categoryId === cat.id).length,
  })).sort((a, b) => a.order - b.order);

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-xl font-bold text-slate-800">Управление категориями</h2>
        <p className="text-sm text-slate-400 mt-0.5">{categories.length} категорий</p>
      </div>

      <div className="space-y-2">
        {categoriesWithCount.map(cat => (
          <div
            key={cat.id}
            className="flex items-center gap-3 p-3 bg-slate-50 hover:bg-white border border-transparent hover:border-slate-200 rounded-xl transition-all"
          >
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0"
              style={{ backgroundColor: `${cat.color}20` }}
            >
              {cat.icon || '📚'}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-sm text-slate-800">{cat.name}</div>
              <div className="text-xs text-slate-400 mt-0.5">
                {cat.nameAr && <span dir="rtl" className="mr-2">{cat.nameAr}</span>}
                · {cat.nameEn}
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <div
                className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-full font-medium"
                style={{ backgroundColor: `${cat.color}20`, color: cat.color }}
              >
                <BookOpen size={11} />
                {cat.actualBookCount} книг
              </div>
              <Link
                to={`/categories/${cat.slug}`}
                className="px-3 py-1.5 rounded-lg text-xs border border-slate-200 text-slate-500 hover:border-emerald-200 hover:bg-emerald-50 hover:text-emerald-700 transition-all"
              >
                Просмотр
              </Link>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-blue-50 border border-blue-100 rounded-xl text-sm text-blue-700">
        <div className="flex items-center gap-2 font-medium mb-1">
          <Tag size={14} />
          Автоматическое управление категориями
        </div>
        <p className="text-blue-500 text-xs">
          Категории автоматически обновляются при импорте новых книг. 
          Система самостоятельно определяет категорию по ключевым словам в названии.
        </p>
      </div>
    </div>
  );
}
