import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Edit, Trash2, ExternalLink, X } from 'lucide-react';
import { useLibraryStore } from '../../store/libraryStore';

export default function AdminBooksPage() {
  const { books, deleteBook, categories } = useLibraryStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const filteredBooks = books.filter(b =>
    !searchQuery ||
    b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    b.author.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDelete = (id: string) => {
    deleteBook(id);
    setDeleteConfirm(null);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Управление книгами</h2>
          <p className="text-sm text-slate-400 mt-0.5">{books.length} книг в библиотеке</p>
        </div>
        <Link
          to="/admin/import"
          className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-emerald-700 transition-colors"
        >
          Добавить книги
        </Link>
      </div>

      <div className="relative mb-4">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          placeholder="Поиск книг..."
          className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-emerald-400 focus:outline-none text-sm"
        />
        {searchQuery && (
          <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2">
            <X size={14} className="text-slate-400" />
          </button>
        )}
      </div>

      <div className="space-y-2">
        {filteredBooks.map(book => (
          <div
            key={book.id}
            className="flex items-center gap-3 p-3 bg-slate-50 hover:bg-white rounded-xl border border-transparent hover:border-slate-200 transition-all"
          >
            {/* Lang badge */}
            <span className={`shrink-0 text-xs px-1.5 py-0.5 rounded font-bold uppercase ${
              book.language === 'ar' ? 'bg-emerald-100 text-emerald-700' :
              book.language === 'ru' ? 'bg-blue-100 text-blue-700' :
              'bg-purple-100 text-purple-700'
            }`}>
              {book.language}
            </span>

            <div className="flex-1 min-w-0">
              <div className="font-medium text-sm text-slate-800 line-clamp-1">{book.title}</div>
              <div className="text-xs text-slate-400 mt-0.5">{book.author} · {book.category} · {book.pages} стр.</div>
            </div>

            <div className="flex items-center gap-1 shrink-0">
              <Link
                to={`/books/${book.id}`}
                className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                title="Просмотр"
              >
                <ExternalLink size={14} />
              </Link>
              {deleteConfirm === book.id ? (
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleDelete(book.id)}
                    className="px-2 py-1 text-xs bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                  >
                    Удалить
                  </button>
                  <button
                    onClick={() => setDeleteConfirm(null)}
                    className="px-2 py-1 text-xs bg-slate-200 text-slate-600 rounded-lg hover:bg-slate-300 transition-colors"
                  >
                    Отмена
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setDeleteConfirm(book.id)}
                  className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  title="Удалить"
                >
                  <Trash2 size={14} />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {filteredBooks.length === 0 && (
        <div className="text-center py-12 text-slate-400">
          <p>Книги не найдены</p>
        </div>
      )}
    </div>
  );
}
