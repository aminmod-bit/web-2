import { useState, useRef, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Upload, FileText, CheckCircle, AlertCircle, XCircle, Loader2,
  BookOpen, User, Tag, Image, Database, Rss, Globe, RefreshCw, Download
} from 'lucide-react';
import { useLibraryStore } from '../../store/libraryStore';
import { performSmartImport, generateBooksJSON, generateAuthorsJSON, generateCategoriesJSON, generateSearchIndex, generateSitemap, generateRSS } from '../../services/smartImport';
import { ImportLog, ImportStep } from '../../types';

const STEP_ICONS: Record<string, React.ReactNode> = {
  detectingLanguage: <Globe size={14} />,
  extractingMetadata: <FileText size={14} />,
  checkingDuplicate: <Database size={14} />,
  findingAuthor: <User size={14} />,
  detectingCategory: <Tag size={14} />,
  generatingCover: <Image size={14} />,
  updatingIndex: <Database size={14} />,
};

const STEP_LABELS: Record<string, string> = {
  detectingLanguage: 'Определение языка',
  extractingMetadata: 'Извлечение метаданных',
  checkingDuplicate: 'Проверка дублирования',
  findingAuthor: 'Поиск автора',
  detectingCategory: 'Определение категории',
  generatingCover: 'Генерация обложки',
  updatingIndex: 'Обновление индекса',
};

interface ActiveImport {
  fileName: string;
  steps: Record<string, ImportStep>;
  progress: number;
  status: 'processing' | 'success' | 'error' | 'duplicate';
}

export default function AdminImportPage() {
  const { t } = useTranslation();
  const { books, authors, categories, addBook, addAuthor, updateAuthor, importLogs, addImportLog } = useLibraryStore();
  const [isDragging, setIsDragging] = useState(false);
  const [activeImports, setActiveImports] = useState<Record<string, ActiveImport>>({});
  const [completedImports, setCompletedImports] = useState<ImportLog[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFile = async (file: File) => {
    if (!file.name.endsWith('.pdf')) return;

    const importId = `import-${Date.now()}-${file.name}`;
    const initialSteps: Record<string, ImportStep> = {
      detectingLanguage: { name: 'detectingLanguage', status: 'pending' },
      extractingMetadata: { name: 'extractingMetadata', status: 'pending' },
      checkingDuplicate: { name: 'checkingDuplicate', status: 'pending' },
      findingAuthor: { name: 'findingAuthor', status: 'pending' },
      detectingCategory: { name: 'detectingCategory', status: 'pending' },
      generatingCover: { name: 'generatingCover', status: 'pending' },
      updatingIndex: { name: 'updatingIndex', status: 'pending' },
    };

    setActiveImports(prev => ({
      ...prev,
      [importId]: {
        fileName: file.name,
        steps: initialSteps,
        progress: 0,
        status: 'processing',
      },
    }));

    const result = await performSmartImport(
      file,
      books,
      authors,
      categories,
      {
        onStepUpdate: (stepName, status, detail) => {
          setActiveImports(prev => ({
            ...prev,
            [importId]: {
              ...prev[importId],
              steps: {
                ...prev[importId]?.steps,
                [stepName]: { name: stepName, status, detail },
              },
            },
          }));
        },
        onProgress: (progress) => {
          setActiveImports(prev => ({
            ...prev,
            [importId]: {
              ...prev[importId],
              progress,
            },
          }));
        },
      }
    );

    if (result.isDuplicate) {
      setActiveImports(prev => ({
        ...prev,
        [importId]: { ...prev[importId], status: 'duplicate' },
      }));
    } else if (result.book) {
      // Add book to store
      addBook(result.book);

      // Handle author
      if (result.author && result.isNewAuthor) {
        addAuthor(result.author);
      } else if (result.author && !result.isNewAuthor) {
        // Update existing author's book list
        const existingAuthor = authors.find(a => a.id === result.author!.id);
        if (existingAuthor) {
          updateAuthor(existingAuthor.id, {
            bookIds: [...existingAuthor.bookIds, result.book.id],
            bookCount: existingAuthor.bookCount + 1,
          });
        }
      }

      setActiveImports(prev => ({
        ...prev,
        [importId]: { ...prev[importId], status: 'success' },
      }));
    } else {
      setActiveImports(prev => ({
        ...prev,
        [importId]: { ...prev[importId], status: 'error' },
      }));
    }
  };

  const handleFileSelect = (files: FileList | null) => {
    if (!files) return;
    Array.from(files).forEach(file => processFile(file));
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileSelect(e.dataTransfer.files);
  }, [books, authors, categories]);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => setIsDragging(false);

  const downloadJSON = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadXML = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'application/xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const activeImportsList = Object.entries(activeImports);

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-800">{t('admin.smartImport')}</h1>
        <p className="text-slate-500 mt-1">{t('admin.importDescription')}</p>
      </div>

      {/* Drop zone */}
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={() => fileInputRef.current?.click()}
        className={`border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all mb-8 ${
          isDragging
            ? 'border-emerald-400 bg-emerald-50'
            : 'border-slate-200 bg-slate-50 hover:border-emerald-300 hover:bg-emerald-50/50'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf"
          multiple
          className="hidden"
          onChange={e => handleFileSelect(e.target.files)}
        />
        <div className={`w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center transition-colors ${
          isDragging ? 'bg-emerald-200' : 'bg-emerald-100'
        }`}>
          <Upload size={28} className="text-emerald-600" />
        </div>
        <h3 className="text-lg font-bold text-slate-700 mb-2">{t('admin.uploadPDF')}</h3>
        <p className="text-slate-400 text-sm">{t('admin.dragDrop')}</p>
        <p className="text-xs text-slate-300 mt-2">Поддерживается: PDF · Несколько файлов одновременно</p>
      </div>

      {/* Active imports */}
      {activeImportsList.length > 0 && (
        <div className="mb-8 space-y-4">
          <h2 className="text-lg font-bold text-slate-800">{t('admin.processing')}</h2>
          {activeImportsList.map(([id, imp]) => (
            <div key={id} className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                {imp.status === 'processing' && <Loader2 size={18} className="text-emerald-500 animate-spin" />}
                {imp.status === 'success' && <CheckCircle size={18} className="text-emerald-500" />}
                {imp.status === 'error' && <XCircle size={18} className="text-red-500" />}
                {imp.status === 'duplicate' && <AlertCircle size={18} className="text-amber-500" />}

                <div className="flex-1">
                  <div className="font-semibold text-slate-800 text-sm">{imp.fileName}</div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    {imp.status === 'processing' && `${t('admin.importing')} ${Math.round(imp.progress)}%`}
                    {imp.status === 'success' && t('admin.newBookAdded')}
                    {imp.status === 'duplicate' && t('admin.bookAlreadyExists')}
                    {imp.status === 'error' && t('admin.importError')}
                  </div>
                </div>

                <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                  imp.status === 'processing' ? 'bg-blue-100 text-blue-700' :
                  imp.status === 'success' ? 'bg-emerald-100 text-emerald-700' :
                  imp.status === 'duplicate' ? 'bg-amber-100 text-amber-700' :
                  'bg-red-100 text-red-700'
                }`}>
                  {imp.status === 'processing' ? 'Обработка' :
                   imp.status === 'success' ? 'Успешно' :
                   imp.status === 'duplicate' ? 'Дублят' : 'Ошибка'}
                </span>
              </div>

              {/* Progress bar */}
              {imp.status === 'processing' && (
                <div className="mb-4">
                  <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                      style={{ width: `${imp.progress}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Steps */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                {Object.entries(imp.steps).map(([stepName, step]) => (
                  <div
                    key={stepName}
                    className={`flex items-center gap-2 p-2.5 rounded-xl text-xs ${
                      step.status === 'pending' ? 'bg-slate-50 text-slate-400' :
                      step.status === 'processing' ? 'bg-blue-50 text-blue-700' :
                      step.status === 'success' ? 'bg-emerald-50 text-emerald-700' :
                      step.status === 'error' ? 'bg-red-50 text-red-700' :
                      'bg-slate-50 text-slate-400'
                    }`}
                  >
                    <span className="shrink-0">
                      {step.status === 'processing' && <Loader2 size={12} className="animate-spin" />}
                      {step.status === 'success' && <CheckCircle size={12} />}
                      {step.status === 'error' && <XCircle size={12} />}
                      {step.status === 'pending' && STEP_ICONS[stepName]}
                    </span>
                    <div className="min-w-0">
                      <div className="font-medium leading-tight">{STEP_LABELS[stepName]}</div>
                      {step.detail && (
                        <div className="text-[10px] opacity-70 mt-0.5 line-clamp-1">{step.detail}</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Generate files section */}
      <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm">
        <h2 className="text-lg font-bold text-slate-800 mb-1">Генерация файлов данных</h2>
        <p className="text-sm text-slate-400 mb-6">Автоматически создать JSON, XML и RSS файлы на основе текущих данных</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            {
              icon: BookOpen,
              label: 'books.json',
              desc: `${books.length} книг`,
              color: 'emerald',
              onClick: () => downloadJSON(generateBooksJSON(books), 'books.json'),
            },
            {
              icon: User,
              label: 'authors.json',
              desc: `${authors.length} авторов`,
              color: 'blue',
              onClick: () => downloadJSON(generateAuthorsJSON(authors), 'authors.json'),
            },
            {
              icon: Tag,
              label: 'categories.json',
              desc: `${categories.length} категорий`,
              color: 'purple',
              onClick: () => downloadJSON(generateCategoriesJSON(categories), 'categories.json'),
            },
            {
              icon: Database,
              label: 'search-index.json',
              desc: `${books.length + authors.length} записей`,
              color: 'orange',
              onClick: () => downloadJSON(generateSearchIndex(books, authors), 'search-index.json'),
            },
            {
              icon: Globe,
              label: 'sitemap.xml',
              desc: `${2 + books.length + authors.length} URL`,
              color: 'teal',
              onClick: () => downloadXML(generateSitemap(books, authors), 'sitemap.xml'),
            },
            {
              icon: Rss,
              label: 'rss.xml',
              desc: 'Последние 20 книг',
              color: 'rose',
              onClick: () => downloadXML(generateRSS(books), 'rss.xml'),
            },
          ].map(({ icon: Icon, label, desc, color, onClick }) => (
            <button
              key={label}
              onClick={onClick}
              className={`group flex items-center gap-3 p-4 rounded-xl border border-slate-100 hover:border-${color}-200 hover:bg-${color}-50/30 transition-all text-left`}
            >
              <div className={`w-10 h-10 rounded-xl bg-${color}-100 flex items-center justify-center shrink-0 group-hover:bg-${color}-200 transition-colors`}>
                <Icon size={18} className={`text-${color}-600`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm text-slate-800">{label}</div>
                <div className="text-xs text-slate-400">{desc}</div>
              </div>
              <Download size={15} className="text-slate-300 group-hover:text-slate-500 transition-colors shrink-0" />
            </button>
          ))}
        </div>
      </div>

      {/* Recent imports log */}
      {completedImports.length > 0 && (
        <div className="mt-8">
          <h2 className="text-lg font-bold text-slate-800 mb-4">{t('admin.recentImports')}</h2>
          <div className="space-y-2">
            {completedImports.slice(0, 10).map(log => (
              <div key={log.id} className="flex items-center gap-3 p-3 bg-white border border-slate-100 rounded-xl text-sm">
                {log.status === 'success' && <CheckCircle size={15} className="text-emerald-500 shrink-0" />}
                {log.status === 'duplicate' && <AlertCircle size={15} className="text-amber-500 shrink-0" />}
                {log.status === 'error' && <XCircle size={15} className="text-red-500 shrink-0" />}
                <span className="font-medium text-slate-700 flex-1 line-clamp-1">{log.fileName}</span>
                <span className="text-slate-400 text-xs shrink-0">
                  {new Date(log.timestamp).toLocaleString('ru-RU')}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
