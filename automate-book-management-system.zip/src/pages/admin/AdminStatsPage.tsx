import { useLibraryStore } from '../../store/libraryStore';
import { BookOpen, Users, Tag, Headphones, Star, TrendingUp, Globe } from 'lucide-react';

export default function AdminStatsPage() {
  const { stats, books, authors, audio, favaids } = useLibraryStore();

  const topBooks = [...books].sort((a, b) => b.views - a.views).slice(0, 5);
  const topAuthors = [...authors].sort((a, b) => b.bookCount - a.bookCount).slice(0, 5);

  const statCards = [
    { icon: BookOpen, label: 'Всего книг', value: stats.totalBooks, sub: `${stats.booksRu} рус · ${stats.booksAr} ар · ${stats.booksEn} eng`, color: 'emerald' },
    { icon: Users, label: 'Авторов', value: stats.totalAuthors, sub: `${authors.filter(a => a.biographyStatus === 'complete').length} с биографией`, color: 'blue' },
    { icon: Tag, label: 'Категорий', value: stats.totalCategories, sub: 'Разделов библиотеки', color: 'purple' },
    { icon: Headphones, label: 'Аудио', value: stats.totalAudio, sub: 'Лекций и уроков', color: 'orange' },
    { icon: Star, label: 'Фаваиды', value: stats.totalFavaids, sub: 'Полезных цитат', color: 'rose' },
    {
      icon: Globe,
      label: 'Языков',
      value: 3,
      sub: '🇷🇺 Русский · 🇸🇦 Арабский · 🇬🇧 English',
      color: 'teal'
    },
  ];

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-xl font-bold text-slate-800">Статистика библиотеки</h2>
        <p className="text-sm text-slate-400 mt-0.5">
          Обновлено: {new Date(stats.lastUpdated).toLocaleString('ru-RU')}
        </p>
      </div>

      {/* Main stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
        {statCards.map(({ icon: Icon, label, value, sub, color }) => (
          <div key={label} className={`bg-${color}-50 border border-${color}-100 rounded-2xl p-4`}>
            <div className="flex items-center gap-2 mb-2">
              <div className={`w-8 h-8 rounded-lg bg-${color}-100 flex items-center justify-center`}>
                <Icon size={16} className={`text-${color}-600`} />
              </div>
              <span className="text-xs text-slate-500 font-medium">{label}</span>
            </div>
            <div className={`text-2xl font-black text-${color}-700 mb-1`}>{value.toLocaleString()}</div>
            <div className="text-xs text-slate-400">{sub}</div>
          </div>
        ))}
      </div>

      {/* Language distribution */}
      <div className="bg-white border border-slate-100 rounded-2xl p-5 mb-6">
        <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
          <Globe size={16} className="text-emerald-500" />
          Распределение по языкам
        </h3>
        <div className="space-y-3">
          {[
            { lang: '🇷🇺 Русский', count: stats.booksRu, color: 'bg-blue-500' },
            { lang: '🇸🇦 Арабский', count: stats.booksAr, color: 'bg-emerald-500' },
            { lang: '🇬🇧 English', count: stats.booksEn, color: 'bg-purple-500' },
          ].map(({ lang, count, color }) => (
            <div key={lang} className="flex items-center gap-3">
              <span className="text-sm text-slate-600 w-28 shrink-0">{lang}</span>
              <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className={`h-full ${color} rounded-full transition-all`}
                  style={{ width: `${stats.totalBooks > 0 ? (count / stats.totalBooks) * 100 : 0}%` }}
                />
              </div>
              <span className="text-sm font-semibold text-slate-700 w-8 text-right">{count}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Top books */}
        <div className="bg-white border border-slate-100 rounded-2xl p-5">
          <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
            <TrendingUp size={16} className="text-emerald-500" />
            Популярные книги
          </h3>
          <div className="space-y-2">
            {topBooks.map((book, idx) => (
              <div key={book.id} className="flex items-center gap-3 py-1.5">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 text-xs font-bold flex items-center justify-center shrink-0">
                  {idx + 1}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-slate-700 line-clamp-1">{book.title}</div>
                  <div className="text-xs text-slate-400">{book.views.toLocaleString()} просмотров</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top authors */}
        <div className="bg-white border border-slate-100 rounded-2xl p-5">
          <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
            <Users size={16} className="text-emerald-500" />
            Авторы по книгам
          </h3>
          <div className="space-y-2">
            {topAuthors.map((author, idx) => (
              <div key={author.id} className="flex items-center gap-3 py-1.5">
                <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 text-xs font-bold flex items-center justify-center shrink-0">
                  {idx + 1}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-slate-700 line-clamp-1">{author.name}</div>
                  <div className="text-xs text-slate-400">{author.bookCount} книг</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
