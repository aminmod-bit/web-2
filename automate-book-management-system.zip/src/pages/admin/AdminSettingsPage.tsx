import { useState } from 'react';
import { Globe, Database, Rss, Shield, Bell, CheckCircle } from 'lucide-react';

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState({
    siteUrl: 'https://salaf-library.com',
    siteName: 'Salaf Library',
    defaultLanguage: 'ru',
    autoGenerateCovers: true,
    autoUpdateIndex: true,
    autoUpdateSitemap: true,
    autoUpdateRSS: true,
    duplicateCheck: true,
    maxBooksPerPage: 20,
    enablePWA: true,
  });

  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-xl font-bold text-slate-800">Настройки</h2>
        <p className="text-sm text-slate-400 mt-0.5">Конфигурация библиотеки</p>
      </div>

      <div className="space-y-6">
        {/* General */}
        <div className="bg-slate-50 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Globe size={16} className="text-emerald-600" />
            <h3 className="font-bold text-slate-800">Общие настройки</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">URL сайта</label>
              <input
                type="url"
                value={settings.siteUrl}
                onChange={e => setSettings(s => ({ ...s, siteUrl: e.target.value }))}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-sm focus:border-emerald-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Название библиотеки</label>
              <input
                type="text"
                value={settings.siteName}
                onChange={e => setSettings(s => ({ ...s, siteName: e.target.value }))}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-sm focus:border-emerald-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Язык по умолчанию</label>
              <select
                value={settings.defaultLanguage}
                onChange={e => setSettings(s => ({ ...s, defaultLanguage: e.target.value }))}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-sm focus:border-emerald-400 focus:outline-none"
              >
                <option value="ru">🇷🇺 Русский</option>
                <option value="ar">🇸🇦 العربية</option>
                <option value="en">🇬🇧 English</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Книг на странице</label>
              <input
                type="number"
                value={settings.maxBooksPerPage}
                onChange={e => setSettings(s => ({ ...s, maxBooksPerPage: Number(e.target.value) }))}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-sm focus:border-emerald-400 focus:outline-none"
                min={10}
                max={100}
              />
            </div>
          </div>
        </div>

        {/* Automation */}
        <div className="bg-slate-50 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Database size={16} className="text-blue-600" />
            <h3 className="font-bold text-slate-800">Автоматизация</h3>
          </div>
          <div className="space-y-3">
            {[
              { key: 'autoGenerateCovers', label: 'Автоматически генерировать обложки из PDF', desc: 'Извлекает первую страницу как обложку' },
              { key: 'autoUpdateIndex', label: 'Автоматически обновлять поисковый индекс', desc: 'После каждого импорта' },
              { key: 'autoUpdateSitemap', label: 'Автоматически обновлять Sitemap.xml', desc: 'После каждого импорта' },
              { key: 'autoUpdateRSS', label: 'Автоматически обновлять RSS ленту', desc: 'После каждого импорта' },
              { key: 'duplicateCheck', label: 'Проверять дублирование при импорте', desc: 'Не добавлять уже существующие книги' },
              { key: 'enablePWA', label: 'Progressive Web App (PWA)', desc: 'Позволяет устанавливать библиотеку как приложение' },
            ].map(({ key, label, desc }) => (
              <label key={key} className="flex items-start gap-3 cursor-pointer group">
                <div className="relative mt-0.5">
                  <input
                    type="checkbox"
                    checked={settings[key as keyof typeof settings] as boolean}
                    onChange={e => setSettings(s => ({ ...s, [key]: e.target.checked }))}
                    className="sr-only"
                  />
                  <div className={`w-10 h-6 rounded-full transition-colors ${
                    settings[key as keyof typeof settings] ? 'bg-emerald-500' : 'bg-slate-200'
                  }`}>
                    <div className={`w-4 h-4 bg-white rounded-full mt-1 transition-transform shadow-sm ${
                      settings[key as keyof typeof settings] ? 'translate-x-5' : 'translate-x-1'
                    }`} />
                  </div>
                </div>
                <div>
                  <div className="text-sm font-medium text-slate-700">{label}</div>
                  <div className="text-xs text-slate-400">{desc}</div>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Save button */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleSave}
            className="flex items-center gap-2 bg-emerald-600 text-white px-6 py-2.5 rounded-xl font-semibold text-sm hover:bg-emerald-700 transition-colors"
          >
            {saved ? <CheckCircle size={15} /> : null}
            {saved ? 'Сохранено!' : 'Сохранить настройки'}
          </button>
          {saved && (
            <span className="text-sm text-emerald-600 flex items-center gap-1">
              <CheckCircle size={14} />
              Настройки сохранены
            </span>
          )}
        </div>

        {/* Architecture note */}
        <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl text-sm">
          <div className="flex items-center gap-2 text-blue-800 font-semibold mb-2">
            <Shield size={14} />
            Архитектура готова к масштабированию
          </div>
          <ul className="text-blue-600 text-xs space-y-1">
            <li>✓ Поддержка десятков тысяч книг без изменений</li>
            <li>✓ Тысячи авторов с биографиями</li>
            <li>✓ Тысячи аудио материалов</li>
            <li>✓ Будущий интернет-магазин (поля зарезервированы)</li>
            <li>✓ RTL поддержка для арабского языка</li>
            <li>✓ Три языка интерфейса</li>
            <li>✓ PWA готово</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
