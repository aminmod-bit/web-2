import { useState, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Search, X } from 'lucide-react';
import { useLibraryStore } from '../store/libraryStore';
import AuthorCard from '../components/ui/AuthorCard';

export default function AuthorsPage() {
  const { t } = useTranslation();
  const { authors } = useLibraryStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'az' | 'za' | 'newest' | 'mostBooks'>('az');

  const filteredAuthors = useMemo(() => {
    let result = [...authors];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(a =>
        a.name.toLowerCase().includes(q) ||
        (a.nameAr && a.nameAr.includes(q)) ||
        (a.nameEn && a.nameEn.toLowerCase().includes(q)) ||
        (a.biography && a.biography.toLowerCase().includes(q))
      );
    }

    switch (sortBy) {
      case 'az': result.sort((a, b) => a.name.localeCompare(b.name)); break;
      case 'za': result.sort((a, b) => b.name.localeCompare(a.name)); break;
      case 'newest': result.sort((a, b) => new Date(b.addedDate).getTime() - new Date(a.addedDate).getTime()); break;
      case 'mostBooks': result.sort((a, b) => b.bookCount - a.bookCount); break;
    }

    return result;
  }, [authors, searchQuery, sortBy]);

  return (
    <div className="max-w-screen-xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800">{t('authors.title')}</h1>
        <p className="text-slate-500 mt-1">{t('authors.subtitle')} — {filteredAuthors.length} авторов</p>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap items-center gap-3 mb-6">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={t('authors.searchAuthors')}
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-100 text-sm"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2">
              <X size={14} className="text-slate-400" />
            </button>
          )}
        </div>

        <select
          value={sortBy}
          onChange={e => setSortBy(e.target.value as typeof sortBy)}
          className="px-3 py-2.5 rounded-xl border border-slate-200 bg-white text-sm text-slate-700 focus:border-emerald-400 focus:outline-none"
        >
          <option value="az">А-Я</option>
          <option value="za">Я-А</option>
          <option value="newest">Новые</option>
          <option value="mostBooks">По книгам</option>
        </select>
      </div>

      {filteredAuthors.length === 0 ? (
        <div className="text-center py-20">
          <div className="text-6xl mb-4">👤</div>
          <h3 className="text-xl font-semibold text-slate-700 mb-2">{t('authors.noAuthors')}</h3>
          <p className="text-slate-400 text-sm">Попробуйте изменить параметры поиска</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {filteredAuthors.map(author => (
            <AuthorCard key={author.id} author={author} />
          ))}
        </div>
      )}
    </div>
  );
}
