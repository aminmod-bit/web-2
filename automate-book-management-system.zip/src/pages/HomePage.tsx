import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Search, BookOpen, Users, Tag, Headphones, ArrowRight, Star, TrendingUp, Clock } from 'lucide-react';
import { useLibraryStore } from '../store/libraryStore';
import BookCard from '../components/ui/BookCard';
import AuthorCard from '../components/ui/AuthorCard';

export default function HomePage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { books, authors, categories, audio, stats } = useLibraryStore();
  const [searchQuery, setSearchQuery] = useState('');

  const recentBooks = [...books]
    .sort((a, b) => new Date(b.importedAt).getTime() - new Date(a.importedAt).getTime())
    .slice(0, 8);

  const popularBooks = [...books]
    .sort((a, b) => b.views - a.views)
    .slice(0, 4);

  const featuredAuthors = authors.slice(0, 6);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const categoryColors = [
    'from-emerald-500 to-emerald-700',
    'from-blue-500 to-blue-700',
    'from-amber-500 to-amber-700',
    'from-purple-500 to-purple-700',
    'from-rose-500 to-rose-700',
    'from-teal-500 to-teal-700',
    'from-indigo-500 to-indigo-700',
    'from-orange-500 to-orange-700',
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-emerald-900 via-emerald-800 to-emerald-950 text-white overflow-hidden">
        {/* Decorative pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 text-9xl font-arabic" dir="rtl">بسم الله</div>
          <div className="absolute bottom-10 right-10 text-8xl font-arabic opacity-50" dir="rtl">الحمد لله</div>
        </div>
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 20% 50%, rgba(16, 185, 129, 0.15) 0%, transparent 50%), 
                           radial-gradient(circle at 80% 20%, rgba(5, 150, 105, 0.2) 0%, transparent 40%)`
        }} />

        <div className="relative max-w-screen-xl mx-auto px-4 py-20 md:py-28 text-center">
          {/* Arabic bismillah */}
          <div className="text-3xl md:text-4xl font-arabic text-emerald-300 mb-6 opacity-80" dir="rtl">
            بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
          </div>

          <h1 className="text-4xl md:text-6xl font-black mb-3 tracking-tight">
            Salaf Library
          </h1>
          <p className="text-xl md:text-2xl text-emerald-200 font-light mb-2">
            {t('home.heroSubtitle')}
          </p>
          <p className="text-emerald-300 text-sm md:text-base max-w-lg mx-auto mb-10 opacity-80">
            {t('home.heroDescription')}
          </p>

          {/* Search bar */}
          <form onSubmit={handleSearch} className="max-w-xl mx-auto mb-8">
            <div className="relative flex items-center">
              <Search size={18} className="absolute left-4 text-slate-400 z-10" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder={t('common.searchPlaceholder')}
                className="w-full pl-12 pr-32 py-4 rounded-2xl bg-white text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-4 focus:ring-emerald-500/30 shadow-xl text-sm"
              />
              <button
                type="submit"
                className="absolute right-2 bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition-colors"
              >
                {t('home.searchButton')}
              </button>
            </div>
          </form>

          {/* Stats */}
          <div className="flex flex-wrap justify-center gap-6 md:gap-10">
            {[
              { value: stats.totalBooks, label: t('home.totalBooks'), icon: BookOpen },
              { value: stats.totalAuthors, label: t('home.totalAuthors'), icon: Users },
              { value: stats.totalCategories, label: t('home.totalCategories'), icon: Tag },
              { value: stats.totalAudio, label: t('home.totalAudio'), icon: Headphones },
            ].map(({ value, label, icon: Icon }) => (
              <div key={label} className="text-center">
                <div className="flex items-center justify-center gap-1.5 mb-0.5">
                  <Icon size={16} className="text-emerald-300" />
                  <span className="text-2xl md:text-3xl font-black">{value.toLocaleString()}</span>
                </div>
                <p className="text-xs text-emerald-300 opacity-80">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="max-w-screen-xl mx-auto px-4">
        {/* Language distribution */}
        <div className="py-8">
          <div className="grid grid-cols-3 gap-4">
            {[
              { flag: '🇷🇺', lang: 'Русский', count: stats.booksRu, color: 'border-blue-200 bg-blue-50' },
              { flag: '🇸🇦', lang: 'العربية', count: stats.booksAr, color: 'border-emerald-200 bg-emerald-50', dir: 'rtl' },
              { flag: '🇬🇧', lang: 'English', count: stats.booksEn, color: 'border-purple-200 bg-purple-50' },
            ].map(item => (
              <div key={item.lang} className={`flex items-center gap-3 p-4 rounded-2xl border ${item.color}`}>
                <span className="text-3xl">{item.flag}</span>
                <div>
                  <div className="font-bold text-slate-800" dir={item.dir}>{item.lang}</div>
                  <div className="text-sm text-slate-500">{item.count} книг</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Categories */}
        <section className="py-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">{t('categories.title')}</h2>
              <p className="text-slate-500 text-sm mt-0.5">{t('categories.subtitle')}</p>
            </div>
            <Link to="/categories" className="flex items-center gap-1.5 text-sm text-emerald-600 hover:text-emerald-700 font-medium">
              {t('common.viewAll')} <ArrowRight size={15} />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {categories.slice(0, 10).map((cat, idx) => (
              <Link
                key={cat.id}
                to={`/categories/${cat.slug}`}
                className="group relative overflow-hidden rounded-2xl p-4 text-white transition-transform hover:scale-105"
                style={{ background: `linear-gradient(135deg, ${cat.color}cc, ${cat.color})` }}
              >
                <div className="text-2xl mb-2">{cat.icon}</div>
                <div className="font-semibold text-sm leading-tight">{cat.name}</div>
                {cat.nameAr && (
                  <div className="text-xs opacity-70 mt-0.5" dir="rtl">{cat.nameAr}</div>
                )}
                <div className="text-xs opacity-60 mt-1">{cat.bookCount} книг</div>
              </Link>
            ))}
          </div>
        </section>

        {/* Recent Books */}
        <section className="py-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Clock size={20} className="text-emerald-600" />
              <div>
                <h2 className="text-2xl font-bold text-slate-800">{t('home.recentBooks')}</h2>
                <p className="text-slate-500 text-sm mt-0.5">Последние добавленные книги</p>
              </div>
            </div>
            <Link to="/books" className="flex items-center gap-1.5 text-sm text-emerald-600 hover:text-emerald-700 font-medium">
              {t('common.viewAll')} <ArrowRight size={15} />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-8 gap-4">
            {recentBooks.map(book => (
              <BookCard key={book.id} book={book} variant="grid" />
            ))}
          </div>
        </section>

        {/* Popular Books */}
        <section className="py-8 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-3xl px-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <TrendingUp size={20} className="text-emerald-600" />
              <div>
                <h2 className="text-2xl font-bold text-slate-800">{t('home.popularBooks')}</h2>
                <p className="text-slate-500 text-sm mt-0.5">Самые читаемые книги библиотеки</p>
              </div>
            </div>
            <Link to="/books?sort=mostRead" className="flex items-center gap-1.5 text-sm text-emerald-600 hover:text-emerald-700 font-medium">
              {t('common.viewAll')} <ArrowRight size={15} />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {popularBooks.map((book, idx) => (
              <Link
                key={book.id}
                to={`/books/${book.id}`}
                className="group flex items-center gap-3 bg-white p-4 rounded-2xl border border-white hover:border-emerald-200 hover:shadow-md transition-all"
              >
                <div className="shrink-0 w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-black text-sm">
                  #{idx + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-sm text-slate-800 line-clamp-2 group-hover:text-emerald-700 transition-colors">
                    {book.title}
                  </h4>
                  <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">{book.author}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Featured Authors */}
        <section className="py-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Star size={20} className="text-emerald-600" />
              <div>
                <h2 className="text-2xl font-bold text-slate-800">{t('home.featuredAuthors')}</h2>
                <p className="text-slate-500 text-sm mt-0.5">Учёные ислама</p>
              </div>
            </div>
            <Link to="/authors" className="flex items-center gap-1.5 text-sm text-emerald-600 hover:text-emerald-700 font-medium">
              {t('common.viewAll')} <ArrowRight size={15} />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {featuredAuthors.map(author => (
              <AuthorCard key={author.id} author={author} />
            ))}
          </div>
        </section>

        {/* Call to action */}
        <section className="py-8 mb-8">
          <div className="bg-gradient-to-br from-emerald-800 to-emerald-900 rounded-3xl p-8 md:p-12 text-white text-center relative overflow-hidden">
            <div className="absolute top-4 right-4 text-6xl opacity-10" dir="rtl">اقرأ</div>
            <div className="absolute bottom-4 left-4 text-5xl opacity-10">📚</div>
            <h2 className="text-2xl md:text-3xl font-bold mb-3">
              Исламские знания для всего мира
            </h2>
            <p className="text-emerald-200 text-sm md:text-base max-w-md mx-auto mb-6">
              Библиотека полностью бесплатна. Читайте, скачивайте и делитесь знаниями.
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              <Link
                to="/books"
                className="inline-flex items-center gap-2 bg-white text-emerald-800 px-6 py-3 rounded-xl font-semibold text-sm hover:bg-emerald-50 transition-colors"
              >
                <BookOpen size={16} />
                Смотреть книги
              </Link>
              <Link
                to="/admin/import"
                className="inline-flex items-center gap-2 border border-emerald-400 text-emerald-100 px-6 py-3 rounded-xl font-semibold text-sm hover:bg-emerald-700 transition-colors"
              >
                Импортировать книги
              </Link>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
