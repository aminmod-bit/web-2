import { useState, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Search, Play, Headphones, Clock, Download, X } from 'lucide-react';
import { useLibraryStore } from '../store/libraryStore';

export default function AudioPage() {
  const { t } = useTranslation();
  const { audio, categories } = useLibraryStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');

  const filteredAudio = useMemo(() => {
    let result = [...audio];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(a =>
        a.title.toLowerCase().includes(q) ||
        a.speaker.toLowerCase().includes(q) ||
        a.category.toLowerCase().includes(q)
      );
    }

    if (categoryFilter) {
      result = result.filter(a => a.categoryId === categoryFilter);
    }

    return result.sort((a, b) => new Date(b.addedDate).getTime() - new Date(a.addedDate).getTime());
  }, [audio, searchQuery, categoryFilter]);

  return (
    <div className="max-w-screen-xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800">{t('audio.title')}</h1>
        <p className="text-slate-500 mt-1">{t('audio.subtitle')} — {filteredAudio.length} материалов</p>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap items-center gap-3 mb-6">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={t('audio.searchAudio')}
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-100 text-sm"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2">
              <X size={14} className="text-slate-400" />
            </button>
          )}
        </div>

        <select
          value={categoryFilter}
          onChange={e => setCategoryFilter(e.target.value)}
          className="px-3 py-2.5 rounded-xl border border-slate-200 bg-white text-sm text-slate-700 focus:border-emerald-400 focus:outline-none"
        >
          <option value="">Все категории</option>
          {categories.map(cat => (
            <option key={cat.id} value={cat.id}>{cat.name}</option>
          ))}
        </select>
      </div>

      {filteredAudio.length === 0 ? (
        <div className="text-center py-20">
          <div className="text-6xl mb-4">🎧</div>
          <h3 className="text-xl font-semibold text-slate-700 mb-2">{t('audio.noAudio')}</h3>
          <p className="text-slate-400 text-sm">Аудиоматериалы появятся после добавления</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredAudio.map(item => (
            <div
              key={item.id}
              className="bg-white border border-slate-100 hover:border-emerald-200 rounded-2xl p-4 transition-all group"
            >
              <div className="flex items-center gap-4">
                {/* Play button */}
                <button className="shrink-0 w-12 h-12 rounded-xl bg-emerald-600 hover:bg-emerald-700 flex items-center justify-center text-white transition-colors shadow-sm">
                  <Play size={18} className="ml-0.5" fill="currentColor" />
                </button>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-slate-800 text-sm group-hover:text-emerald-700 transition-colors line-clamp-1">
                    {item.title}
                  </h3>
                  {item.titleAr && (
                    <p className="text-xs text-slate-400 mt-0.5 font-arabic" dir="rtl">{item.titleAr}</p>
                  )}
                  <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-400">
                    <span>{item.speaker}</span>
                    <span>·</span>
                    <span className="flex items-center gap-1">
                      <Clock size={11} /> {item.duration}
                    </span>
                    <span>·</span>
                    <span>{item.category}</span>
                    {item.lessonNumber && (
                      <>
                        <span>·</span>
                        <span>Урок {item.lessonNumber}</span>
                      </>
                    )}
                  </div>
                </div>

                {/* Stats */}
                <div className="hidden sm:flex items-center gap-4 shrink-0">
                  <div className="text-center">
                    <div className="text-xs font-semibold text-slate-700">{item.plays.toLocaleString()}</div>
                    <div className="text-[10px] text-slate-400">прослушиваний</div>
                  </div>

                  {/* Language badge */}
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    item.language === 'ar' ? 'bg-emerald-100 text-emerald-700' :
                    item.language === 'ru' ? 'bg-blue-100 text-blue-700' :
                    'bg-purple-100 text-purple-700'
                  }`}>
                    {item.language.toUpperCase()}
                  </span>

                  {/* Download */}
                  <a
                    href={item.audioUrl}
                    download
                    className="p-2 rounded-lg border border-slate-200 hover:border-emerald-200 hover:bg-emerald-50 transition-all text-slate-400 hover:text-emerald-600"
                  >
                    <Download size={15} />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Coming soon note */}
      <div className="mt-8 p-4 bg-emerald-50 border border-emerald-100 rounded-2xl text-center">
        <Headphones size={24} className="text-emerald-500 mx-auto mb-2" />
        <p className="text-sm text-emerald-700 font-medium">Аудиотека постоянно пополняется</p>
        <p className="text-xs text-emerald-500 mt-0.5">
          Новые лекции и уроки добавляются регулярно
        </p>
      </div>
    </div>
  );
}
