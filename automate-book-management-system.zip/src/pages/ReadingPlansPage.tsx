import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Plus, BookMarked, CheckCircle, Clock, BookOpen, Trash2, X } from 'lucide-react';
import { useLibraryStore } from '../store/libraryStore';
import { ReadingPlan } from '../types';
import { Link } from 'react-router-dom';

export default function ReadingPlansPage() {
  const { t } = useTranslation();
  const { readingPlans, books, addReadingPlan, updateReadingPlan, deleteReadingPlan } = useLibraryStore();
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newPlanName, setNewPlanName] = useState('');

  const createPlan = () => {
    if (!newPlanName.trim()) return;
    const plan: ReadingPlan = {
      id: `plan-${Date.now()}`,
      name: newPlanName.trim(),
      bookIds: [],
      books: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    addReadingPlan(plan);
    setNewPlanName('');
    setShowCreateForm(false);
  };

  const getProgressPercent = (plan: ReadingPlan) => {
    if (plan.books.length === 0) return 0;
    const completed = plan.books.filter(b => b.status === 'completed').length;
    return Math.round((completed / plan.books.length) * 100);
  };

  return (
    <div className="max-w-screen-xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">{t('readingPlans.title')}</h1>
          <p className="text-slate-500 mt-1">{t('readingPlans.subtitle')}</p>
        </div>
        <button
          onClick={() => setShowCreateForm(true)}
          className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2.5 rounded-xl font-semibold text-sm hover:bg-emerald-700 transition-colors shadow-sm"
        >
          <Plus size={16} />
          {t('readingPlans.createPlan')}
        </button>
      </div>

      {/* Create form */}
      {showCreateForm && (
        <div className="bg-white border border-emerald-200 rounded-2xl p-5 mb-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-slate-800">Новый план чтения</h3>
            <button onClick={() => setShowCreateForm(false)}>
              <X size={18} className="text-slate-400" />
            </button>
          </div>
          <div className="flex gap-3">
            <input
              type="text"
              value={newPlanName}
              onChange={e => setNewPlanName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && createPlan()}
              placeholder="Название плана..."
              className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-emerald-400 focus:outline-none text-sm"
              autoFocus
            />
            <button
              onClick={createPlan}
              className="bg-emerald-600 text-white px-4 py-2.5 rounded-xl text-sm font-medium hover:bg-emerald-700 transition-colors"
            >
              Создать
            </button>
          </div>
        </div>
      )}

      {readingPlans.length === 0 ? (
        <div className="text-center py-20">
          <div className="w-20 h-20 rounded-2xl bg-emerald-100 flex items-center justify-center mx-auto mb-4">
            <BookMarked size={32} className="text-emerald-500" />
          </div>
          <h3 className="text-xl font-semibold text-slate-700 mb-2">{t('readingPlans.noPlan')}</h3>
          <p className="text-slate-400 text-sm mb-6">
            Создайте план чтения, чтобы организовать своё изучение исламских книг
          </p>
          <button
            onClick={() => setShowCreateForm(true)}
            className="inline-flex items-center gap-2 bg-emerald-600 text-white px-5 py-3 rounded-xl font-semibold text-sm hover:bg-emerald-700 transition-colors"
          >
            <Plus size={16} />
            Создать первый план
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {readingPlans.map(plan => {
            const progress = getProgressPercent(plan);
            const completed = plan.books.filter(b => b.status === 'completed').length;
            const inProgress = plan.books.filter(b => b.status === 'in_progress').length;

            return (
              <div key={plan.id} className="bg-white border border-slate-100 hover:border-emerald-200 rounded-2xl p-5 shadow-sm transition-all">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-bold text-slate-800">{plan.name}</h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Создан {new Date(plan.createdAt).toLocaleDateString('ru-RU')}
                    </p>
                  </div>
                  <button
                    onClick={() => deleteReadingPlan(plan.id)}
                    className="p-1.5 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>

                {/* Progress bar */}
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs text-slate-500">{t('readingPlans.progress')}</span>
                    <span className="text-xs font-bold text-emerald-600">{progress}%</span>
                  </div>
                  <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>

                {/* Stats */}
                <div className="flex items-center gap-3 mb-4 text-xs">
                  <div className="flex items-center gap-1 text-slate-500">
                    <BookOpen size={11} />
                    {plan.books.length} книг
                  </div>
                  {completed > 0 && (
                    <div className="flex items-center gap-1 text-emerald-600">
                      <CheckCircle size={11} />
                      {completed} завершено
                    </div>
                  )}
                  {inProgress > 0 && (
                    <div className="flex items-center gap-1 text-blue-600">
                      <Clock size={11} />
                      {inProgress} читается
                    </div>
                  )}
                </div>

                {/* Book list preview */}
                {plan.books.length > 0 ? (
                  <div className="space-y-1.5 mb-4">
                    {plan.books.slice(0, 3).map(planBook => {
                      const book = books.find(b => b.id === planBook.bookId);
                      return book ? (
                        <div key={planBook.bookId} className="flex items-center gap-2 text-xs">
                          <div className={`w-2 h-2 rounded-full shrink-0 ${
                            planBook.status === 'completed' ? 'bg-emerald-500' :
                            planBook.status === 'in_progress' ? 'bg-blue-500' :
                            'bg-slate-200'
                          }`} />
                          <span className={`line-clamp-1 ${
                            planBook.status === 'completed' ? 'line-through text-slate-400' : 'text-slate-600'
                          }`}>{book.title}</span>
                        </div>
                      ) : null;
                    })}
                    {plan.books.length > 3 && (
                      <div className="text-xs text-slate-400">+{plan.books.length - 3} ещё...</div>
                    )}
                  </div>
                ) : (
                  <div className="text-xs text-slate-300 italic mb-4">Книги не добавлены</div>
                )}

                {/* Add book button */}
                <Link
                  to="/books"
                  className="flex items-center justify-center gap-2 w-full border border-emerald-200 text-emerald-700 hover:bg-emerald-50 px-3 py-2 rounded-xl text-xs font-medium transition-colors"
                >
                  <Plus size={12} />
                  {t('readingPlans.addBook')}
                </Link>
              </div>
            );
          })}
        </div>
      )}

      {/* Info */}
      <div className="mt-8 p-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm text-slate-500 text-center">
        <BookMarked size={16} className="inline mr-2 text-emerald-400" />
        Планы чтения помогут вам систематически изучать исламские книги
      </div>
    </div>
  );
}
