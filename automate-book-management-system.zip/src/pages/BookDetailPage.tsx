import { useParams, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, Download, BookOpen, FileText, Globe, Calendar, Eye, Tag, User, Share2, BookMarked } from 'lucide-react';
import { useLibraryStore } from '../store/libraryStore';
import BookCard from '../components/ui/BookCard';

const LANG_LABELS: Record<string, string> = {
  ru: '🇷🇺 Русский',
  ar: '🇸🇦 Арабский',
  en: '🇬🇧 English',
};

export default function BookDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const { books, authors, categories, incrementViews, incrementDownloads } = useLibraryStore();

  const book = books.find(b => b.id === id);
  const author = book ? authors.find(a => a.id === book.authorId) : null;
  const category = book ? categories.find(c => c.id === book.categoryId) : null;
  const relatedBooks = book
    ? books.filter(b => b.id !== book.id && b.categoryId === book.categoryId).slice(0, 4)
    : [];

  if (!book) {
    return (
      <div className="max-w-screen-xl mx-auto px-4 py-20 text-center">
        <div className="text-6xl mb-4">📚</div>
        <h2 className="text-2xl font-bold text-slate-700 mb-2">Книга не найдена</h2>
        <p className="text-slate-400 mb-6">Запрошенная книга не существует в библиотеке</p>
        <Link to="/books" className="inline-flex items-center gap-2 text-emerald-600 hover:underline">
          <ArrowLeft size={16} /> Вернуться к библиотеке
        </Link>
      </div>
    );
  }

  const handleDownload = () => {
    incrementDownloads(book.id);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: book.title,
        text: `${book.title} — ${book.author}`,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
    }
  };

  return (
    <div className="max-w-screen-xl mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-slate-400 mb-6">
        <Link to="/" className="hover:text-emerald-600 transition-colors">Главная</Link>
        <span>/</span>
        <Link to="/books" className="hover:text-emerald-600 transition-colors">Книги</Link>
        <span>/</span>
        <span className="text-slate-600 line-clamp-1">{book.title}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: Cover + Actions */}
        <div className="lg:col-span-1">
          {/* Cover */}
          <div className="aspect-[3/4] bg-gradient-to-br from-emerald-50 to-slate-100 rounded-2xl flex items-center justify-center overflow-hidden shadow-lg mb-6 max-w-xs mx-auto lg:mx-0">
            {book.coverUrl ? (
              <img src={book.coverUrl} alt={book.title} className="w-full h-full object-cover" />
            ) : (
              <div className="flex flex-col items-center justify-center p-6 text-center">
                <div className="w-20 h-20 rounded-2xl bg-white/80 flex items-center justify-center shadow-sm mb-4">
                  <BookOpen size={36} className="text-emerald-500" />
                </div>
                <p className="text-emerald-600 font-medium text-sm leading-tight">
                  {book.titleAr || book.title}
                </p>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="space-y-3 max-w-xs mx-auto lg:mx-0">
            <a
              href={book.pdfUrl}
              download
              onClick={handleDownload}
              className="flex items-center justify-center gap-2 w-full bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-xl font-semibold text-sm transition-colors shadow-sm"
            >
              <Download size={16} />
              {t('books.downloadPDF')}
            </a>
            <a
              href={book.pdfUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full border border-emerald-200 text-emerald-700 hover:bg-emerald-50 px-6 py-3 rounded-xl font-semibold text-sm transition-colors"
            >
              <BookOpen size={16} />
              {t('books.readOnline')}
            </a>
            <button
              onClick={handleShare}
              className="flex items-center justify-center gap-2 w-full border border-slate-200 text-slate-600 hover:bg-slate-50 px-6 py-3 rounded-xl font-semibold text-sm transition-colors"
            >
              <Share2 size={16} />
              {t('common.share')}
            </button>
            <Link
              to="/reading-plans"
              className="flex items-center justify-center gap-2 w-full border border-slate-200 text-slate-600 hover:bg-slate-50 px-6 py-3 rounded-xl font-semibold text-sm transition-colors"
            >
              <BookMarked size={16} />
              В план чтения
            </Link>
          </div>
        </div>

        {/* Right: Info */}
        <div className="lg:col-span-2">
          <div className="mb-2">
            <span className="inline-block text-xs px-2.5 py-1 bg-emerald-100 text-emerald-700 rounded-full font-medium mb-2">
              {category?.name || book.category}
            </span>
          </div>

          <h1 className="text-2xl md:text-3xl font-black text-slate-900 mb-2">{book.title}</h1>
          {book.titleAr && (
            <h2 className="text-xl text-slate-500 font-arabic mb-1" dir="rtl">{book.titleAr}</h2>
          )}
          {book.titleEn && (
            <h2 className="text-base text-slate-400 italic mb-4">{book.titleEn}</h2>
          )}

          {/* Author link */}
          {author ? (
            <Link
              to={`/authors/${author.id}`}
              className="inline-flex items-center gap-2 text-emerald-600 hover:text-emerald-700 font-semibold mb-6 group"
            >
              <User size={15} />
              <span className="group-hover:underline">{book.author}</span>
            </Link>
          ) : (
            <p className="flex items-center gap-2 text-slate-600 font-semibold mb-6">
              <User size={15} />
              {book.author}
            </p>
          )}

          {/* Metadata grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
            {[
              { icon: Globe, label: t('books.language_label') || 'Язык', value: LANG_LABELS[book.language] || book.language },
              { icon: FileText, label: t('books.pageCount'), value: `${book.pages} страниц` },
              { icon: Download, label: t('books.fileSize'), value: book.fileSize },
              { icon: Tag, label: t('common.category'), value: category?.name || book.category },
              { icon: Calendar, label: t('books.importedDate'), value: new Date(book.addedDate).toLocaleDateString('ru-RU') },
              { icon: Eye, label: 'Просмотры', value: book.views.toLocaleString() },
            ].map(({ icon: Icon, label, value }) => (
              <div key={label} className="bg-slate-50 rounded-xl p-3">
                <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
                  <Icon size={12} />
                  {label}
                </div>
                <div className="text-sm font-semibold text-slate-700">{value}</div>
              </div>
            ))}
          </div>

          {/* Description */}
          {book.description && (
            <div className="mb-8">
              <h3 className="text-lg font-bold text-slate-800 mb-3">{t('books.description')}</h3>
              <p className="text-slate-600 leading-relaxed text-sm">{book.description}</p>
            </div>
          )}

          {/* Arabic description */}
          {book.descriptionAr && (
            <div className="mb-8 p-4 bg-emerald-50 rounded-xl border border-emerald-100" dir="rtl">
              <p className="text-slate-700 leading-relaxed text-sm font-arabic">{book.descriptionAr}</p>
            </div>
          )}

          {/* Tags */}
          {book.tags && book.tags.length > 0 && (
            <div className="mb-8">
              <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-2">Теги</h3>
              <div className="flex flex-wrap gap-2">
                {book.tags.map(tag => (
                  <Link
                    key={tag}
                    to={`/search?q=${encodeURIComponent(tag)}`}
                    className="text-xs px-3 py-1.5 bg-slate-100 text-slate-600 rounded-full hover:bg-emerald-100 hover:text-emerald-700 transition-colors"
                  >
                    #{tag}
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Related Books */}
      {relatedBooks.length > 0 && (
        <div className="mt-12">
          <h3 className="text-xl font-bold text-slate-800 mb-6">{t('books.relatedBooks')}</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {relatedBooks.map(b => (
              <BookCard key={b.id} book={b} variant="grid" />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
