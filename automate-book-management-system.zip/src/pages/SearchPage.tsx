import { useState, useMemo, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Search, X, BookOpen, User, Headphones } from 'lucide-react';
import { useLibraryStore } from '../store/libraryStore';
import BookCard from '../components/ui/BookCard';
import AuthorCard from '../components/ui/AuthorCard';

type SearchType = 'all' | 'books' | 'authors' | 'audio';

export default function SearchPage() {
  const { t } = useTranslation();
  const [searchParams, setSearchParams] = useSearchParams();
  const { books, authors, audio } = useLibraryStore();
  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [activeType, setActiveType] = useState<SearchType>('all');

  useEffect(() => {
    const q = searchParams.get('q') || '';
    setQuery(q);
  }, [searchParams]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      setSearchParams({ q: query });
    }
  };

  const searchResults = useMemo(() => {
    const q = (searchParams.get('q') || '').toLowerCase();
    if (!q) return { books: [], authors: [], audio: [], total: 0 };

    const matchedBooks = books.filter(b =>
      b.title.toLowerCase().includes(q) ||
      (b.titleAr && b.titleAr.toLowerCase().includes(q)) ||
      (b.titleEn && b.titleEn.toLowerCase().includes(q)) ||
      b.author.toLowerCase().includes(q) ||
      b.category.toLowerCase().includes(q) ||
      (b.description && b.description.toLowerCase().includes(q)) ||
      (b.tags && b.tags.some(tag => tag.toLowerCase().includes(q)))
    );

    const matchedAuthors = authors.filter(a =>
      a.name.toLowerCase().includes(q) ||
      (a.nameAr && a.nameAr.toLowerCase().includes(q)) ||
      (a.nameEn && a.nameEn.toLowerCase().includes(q)) ||
      (a.biography && a.biography.toLowerCase().includes(q))
    );

    const matchedAudio = audio.filter(a =>
      a.title.toLowerCase().includes(q) ||
      a.speaker.toLowerCase().includes(q) ||
      a.category.toLowerCase().includes(q)
    );

    return {
      books: matchedBooks,
      authors: matchedAuthors,
      audio: matchedAudio,
      total: matchedBooks.length + matchedAuthors.length + matchedAudio.length,
    };
  }, [books, authors, audio, searchParams]);

  const currentQuery = searchParams.get('q') || '';

  return (
    <div className="max-w-screen-xl mx-auto px-4 py-8">
      {/* Search bar */}
      <div className="mb-8">
        <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
          <div className="relative">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder={t('search.placeholder')}
              className="w-full pl-12 pr-32 py-4 rounded-2xl border border-slate-200 bg-white focus:border-emerald-400 focus:outline-none focus:ring-4 focus:ring-emerald-100 text-sm shadow-sm"
              autoFocus
            />
            {query && (
              <button
                type="button"
                onClick={() => { setQuery(''); setSearchParams({}); }}
                className="absolute right-20 top-1/2 -translate-y-1/2 p-1"
              >
                <X size={16} className="text-slate-400" />
              </button>
            )}
            <button
              type="submit"
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-emerald-600 text-white px-4 py-2.5 rounded-xl text-sm font-semibold hover:bg-emerald-700 transition-colors"
            >
              Найти
            </button>
          </div>
        </form>
      </div>

      {!currentQuery ? (
        <div className="text-center py-16">
          <div className="text-6xl mb-4">🔍</div>
          <h2 className="text-2xl font-semibold text-slate-600 mb-2">{t('search.title')}</h2>
          <p className="text-slate-400">{t('search.subtitle')}</p>
        </div>
      ) : (
        <>
          {/* Results header */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-xl font-bold text-slate-800">
                {searchResults.total > 0
                  ? `${t('search.showing')} ${searchResults.total} ${t('search.items')} по запросу "${currentQuery}"`
                  : `${t('search.noResults')} "${currentQuery}"`
                }
              </h1>
            </div>
          </div>

          {/* Type tabs */}
          <div className="flex gap-2 mb-6 flex-wrap">
            {([
              { id: 'all', label: t('search.allTypes'), count: searchResults.total, icon: Search },
              { id: 'books', label: t('search.booksOnly'), count: searchResults.books.length, icon: BookOpen },
              { id: 'authors', label: t('search.authorsOnly'), count: searchResults.authors.length, icon: User },
              { id: 'audio', label: t('search.audioOnly'), count: searchResults.audio.length, icon: Headphones },
            ] as const).map(({ id, label, count, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveType(id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                  activeType === id
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-white border border-slate-200 text-slate-600 hover:border-emerald-200'
                }`}
              >
                <Icon size={14} />
                {label}
                <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                  activeType === id ? 'bg-white/20' : 'bg-slate-100 text-slate-500'
                }`}>{count}</span>
              </button>
            ))}
          </div>

          {searchResults.total === 0 ? (
            <div className="text-center py-16 bg-slate-50 rounded-2xl">
              <div className="text-6xl mb-4">😔</div>
              <h3 className="text-xl font-semibold text-slate-700 mb-2">{t('common.noResults')}</h3>
              <p className="text-slate-400 text-sm">Попробуйте другой запрос или измените фильтры</p>
            </div>
          ) : (
            <div className="space-y-10">
              {/* Books */}
              {(activeType === 'all' || activeType === 'books') && searchResults.books.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <BookOpen size={18} className="text-emerald-600" />
                    <h2 className="text-lg font-bold text-slate-800">Книги ({searchResults.books.length})</h2>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                    {searchResults.books.map(book => (
                      <BookCard key={book.id} book={book} variant="grid" />
                    ))}
                  </div>
                </div>
              )}

              {/* Authors */}
              {(activeType === 'all' || activeType === 'authors') && searchResults.authors.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <User size={18} className="text-emerald-600" />
                    <h2 className="text-lg font-bold text-slate-800">Авторы ({searchResults.authors.length})</h2>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {searchResults.authors.map(author => (
                      <AuthorCard key={author.id} author={author} />
                    ))}
                  </div>
                </div>
              )}

              {/* Audio */}
              {(activeType === 'all' || activeType === 'audio') && searchResults.audio.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <Headphones size={18} className="text-emerald-600" />
                    <h2 className="text-lg font-bold text-slate-800">Аудио ({searchResults.audio.length})</h2>
                  </div>
                  <div className="space-y-2">
                    {searchResults.audio.map(item => (
                      <Link
                        key={item.id}
                        to={`/audio/${item.id}`}
                        className="flex items-center gap-4 bg-white border border-slate-100 hover:border-emerald-200 rounded-xl p-4 transition-all group"
                      >
                        <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center shrink-0">
                          <Headphones size={18} className="text-emerald-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-sm text-slate-800 group-hover:text-emerald-700 line-clamp-1">
                            {item.title}
                          </h4>
                          <p className="text-xs text-slate-400 mt-0.5">{item.speaker} · {item.duration}</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}
