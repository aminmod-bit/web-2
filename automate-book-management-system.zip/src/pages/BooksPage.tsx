import { useState, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Search, Grid, List, SlidersHorizontal, X } from 'lucide-react';
import { useLibraryStore } from '../store/libraryStore';
import BookCard from '../components/ui/BookCard';
import { SupportedLang } from '../types';

type ViewMode = 'grid' | 'list';

export default function BooksPage() {
  const { t } = useTranslation();
  const { books, categories } = useLibraryStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [langFilter, setLangFilter] = useState<SupportedLang | 'all'>('all');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'az' | 'za' | 'mostRead'>('newest');
  const [filtersOpen, setFiltersOpen] = useState(false);

  const filteredBooks = useMemo(() => {
    let result = [...books];

    // Filter by search
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(b =>
        b.title.toLowerCase().includes(q) ||
        (b.titleAr && b.titleAr.toLowerCase().includes(q)) ||
        (b.titleEn && b.titleEn.toLowerCase().includes(q)) ||
        b.author.toLowerCase().includes(q) ||
        b.category.toLowerCase().includes(q) ||
        (b.tags && b.tags.some(tag => tag.toLowerCase().includes(q)))
      );
    }

    // Filter by language
    if (langFilter !== 'all') {
      result = result.filter(b => b.language === langFilter);
    }

    // Filter by category
    if (categoryFilter) {
      result = result.filter(b => b.categoryId === categoryFilter);
    }

    // Sort
    switch (sortBy) {
      case 'newest':
        result.sort((a, b) => new Date(b.importedAt).getTime() - new Date(a.importedAt).getTime());
        break;
      case 'oldest':
        result.sort((a, b) => new Date(a.importedAt).getTime() - new Date(b.importedAt).getTime());
        break;
      case 'az':
        result.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case 'za':
        result.sort((a, b) => b.title.localeCompare(a.title));
        break;
      case 'mostRead':
        result.sort((a, b) => b.views - a.views);
        break;
    }

    return result;
  }, [books, searchQuery, langFilter, categoryFilter, sortBy]);

  const clearFilters = () => {
    setSearchQuery('');
    setLangFilter('all');
    setCategoryFilter('');
    setSortBy('newest');
  };

  const hasFilters = searchQuery || langFilter !== 'all' || categoryFilter || sortBy !== 'newest';

  return (
    <div className="max-w-screen-xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800">{t('books.title')}</h1>
        <p className="text-slate-500 mt-1">{filteredBooks.length} книг в библиотеке</p>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap items-center gap-3 mb-6">
        {/* Search */}
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={t('books.searchBooks')}
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-100 text-sm"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2">
              <X size={14} className="text-slate-400" />
            </button>
          )}
        </div>

        {/* Language filter */}
        <div className="flex rounded-xl border border-slate-200 overflow-hidden bg-white">
          {([['all', 'Все'], ['ru', '🇷🇺 РУС'], ['ar', '🇸🇦 عر'], ['en', '🇬🇧 EN']] as const).map(([code, label]) => (
            <button
              key={code}
              onClick={() => setLangFilter(code as SupportedLang | 'all')}
              className={`px-3 py-2 text-xs font-medium transition-colors ${
                langFilter === code ? 'bg-emerald-600 text-white' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Category filter */}
        <select
          value={categoryFilter}
          onChange={e => setCategoryFilter(e.target.value)}
          className="px-3 py-2.5 rounded-xl border border-slate-200 bg-white text-sm text-slate-700 focus:border-emerald-400 focus:outline-none"
        >
          <option value="">Все категории</option>
          {categories.map(cat => (
            <option key={cat.id} value={cat.id}>{cat.name}</option>
          ))}
        </select>

        {/* Sort */}
        <select
          value={sortBy}
          onChange={e => setSortBy(e.target.value as typeof sortBy)}
          className="px-3 py-2.5 rounded-xl border border-slate-200 bg-white text-sm text-slate-700 focus:border-emerald-400 focus:outline-none"
        >
          <option value="newest">Новые</option>
          <option value="oldest">Старые</option>
          <option value="az">А-Я</option>
          <option value="za">Я-А</option>
          <option value="mostRead">Популярные</option>
        </select>

        {/* Clear filters */}
        {hasFilters && (
          <button
            onClick={clearFilters}
            className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl text-sm text-red-600 hover:bg-red-50 border border-red-200 transition-colors"
          >
            <X size={13} />
            Очистить
          </button>
        )}

        {/* View mode */}
        <div className="flex rounded-xl border border-slate-200 overflow-hidden bg-white ml-auto">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2.5 transition-colors ${viewMode === 'grid' ? 'bg-emerald-600 text-white' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <Grid size={15} />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`p-2.5 transition-colors ${viewMode === 'list' ? 'bg-emerald-600 text-white' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <List size={15} />
          </button>
        </div>
      </div>

      {/* Active filters display */}
      {hasFilters && (
        <div className="flex flex-wrap gap-2 mb-4">
          {searchQuery && (
            <span className="flex items-center gap-1 text-xs px-2.5 py-1 bg-emerald-100 text-emerald-700 rounded-full">
              Поиск: "{searchQuery}"
              <button onClick={() => setSearchQuery('')}><X size={11} /></button>
            </span>
          )}
          {langFilter !== 'all' && (
            <span className="flex items-center gap-1 text-xs px-2.5 py-1 bg-blue-100 text-blue-700 rounded-full">
              Язык: {langFilter.toUpperCase()}
              <button onClick={() => setLangFilter('all')}><X size={11} /></button>
            </span>
          )}
          {categoryFilter && (
            <span className="flex items-center gap-1 text-xs px-2.5 py-1 bg-purple-100 text-purple-700 rounded-full">
              {categories.find(c => c.id === categoryFilter)?.name}
              <button onClick={() => setCategoryFilter('')}><X size={11} /></button>
            </span>
          )}
        </div>
      )}

      {/* Results */}
      {filteredBooks.length === 0 ? (
        <div className="text-center py-20">
          <div className="text-6xl mb-4">📚</div>
          <h3 className="text-xl font-semibold text-slate-700 mb-2">{t('books.noBooks')}</h3>
          <p className="text-slate-400 text-sm">Попробуйте изменить параметры поиска</p>
          {hasFilters && (
            <button onClick={clearFilters} className="mt-4 text-sm text-emerald-600 hover:underline">
              Сбросить все фильтры
            </button>
          )}
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {filteredBooks.map(book => (
            <BookCard key={book.id} book={book} variant="grid" />
          ))}
        </div>
      ) : (
        <div className="space-y-2">
          {filteredBooks.map(book => (
            <BookCard key={book.id} book={book} variant="list" />
          ))}
        </div>
      )}
    </div>
  );
}
