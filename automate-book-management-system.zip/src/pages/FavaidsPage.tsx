import { useState, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Search, Heart, Quote, X, Link as LinkIcon } from 'lucide-react';
import { useLibraryStore } from '../store/libraryStore';

export default function FavaidsPage() {
  const { t } = useTranslation();
  const { favaids } = useLibraryStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [langFilter, setLangFilter] = useState<'all' | 'ru' | 'ar' | 'en'>('all');

  const filteredFavaids = useMemo(() => {
    let result = [...favaids];

    if (langFilter !== 'all') {
      result = result.filter(f => f.language === langFilter);
    }

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(f =>
        f.text.toLowerCase().includes(q) ||
        (f.textAr && f.textAr.toLowerCase().includes(q)) ||
        (f.author && f.author.toLowerCase().includes(q)) ||
        (f.source && f.source.toLowerCase().includes(q)) ||
        (f.topic && f.topic.toLowerCase().includes(q))
      );
    }

    return result.sort((a, b) => b.likes - a.likes);
  }, [favaids, searchQuery, langFilter]);

  return (
    <div className="max-w-screen-xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800">{t('favaids.title')}</h1>
        <p className="text-slate-500 mt-1">{t('favaids.subtitle')} — {filteredFavaids.length} фаваидов</p>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap items-center gap-3 mb-6">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={t('favaids.searchFavaids')}
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-100 text-sm"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2">
              <X size={14} className="text-slate-400" />
            </button>
          )}
        </div>

        <div className="flex rounded-xl border border-slate-200 overflow-hidden bg-white">
          {([['all', 'Все'], ['ru', '🇷🇺'], ['ar', '🇸🇦'], ['en', '🇬🇧']] as const).map(([code, label]) => (
            <button
              key={code}
              onClick={() => setLangFilter(code)}
              className={`px-3 py-2 text-sm transition-colors ${
                langFilter === code ? 'bg-emerald-600 text-white' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {filteredFavaids.length === 0 ? (
        <div className="text-center py-20">
          <div className="text-6xl mb-4">💎</div>
          <h3 className="text-xl font-semibold text-slate-700 mb-2">{t('favaids.noFavaids')}</h3>
          <p className="text-slate-400 text-sm">Фаваиды появятся после добавления</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredFavaids.map(faid => (
            <div
              key={faid.id}
              className={`bg-white rounded-2xl border border-slate-100 hover:border-emerald-200 hover:shadow-md transition-all p-6 ${
                faid.language === 'ar' ? 'rtl-card' : ''
              }`}
            >
              {/* Quote mark */}
              <div className="flex items-start gap-3 mb-4">
                <div className="shrink-0 w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <Quote size={14} className="text-emerald-600" />
                </div>
                <div className="flex-1">
                  {/* Main text */}
                  <p
                    className={`text-slate-700 leading-relaxed text-sm ${
                      faid.language === 'ar' ? 'font-arabic text-base' : ''
                    }`}
                    dir={faid.language === 'ar' ? 'rtl' : 'ltr'}
                  >
                    {faid.text}
                  </p>

                  {/* Arabic text (if main is not Arabic) */}
                  {faid.language !== 'ar' && faid.textAr && (
                    <p className="text-slate-500 leading-relaxed text-sm mt-3 font-arabic" dir="rtl">
                      {faid.textAr}
                    </p>
                  )}
                </div>
              </div>

              {/* Source and author */}
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-50">
                <div className="text-xs text-slate-400">
                  {faid.author && (
                    <span className="font-medium text-slate-500">{faid.author}</span>
                  )}
                  {faid.source && (
                    <span className="text-slate-400">
                      {faid.author && ' · '}
                      {faid.source}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-3">
                  {faid.topic && (
                    <span className="text-xs px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded-full">
                      {faid.topic}
                    </span>
                  )}
                  <button className="flex items-center gap-1 text-xs text-slate-400 hover:text-rose-500 transition-colors">
                    <Heart size={12} />
                    {faid.likes}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
