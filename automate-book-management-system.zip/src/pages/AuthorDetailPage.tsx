import { useParams, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, BookOpen, User, Calendar, MapPin, AlertCircle, Edit } from 'lucide-react';
import { useLibraryStore } from '../store/libraryStore';
import BookCard from '../components/ui/BookCard';

export default function AuthorDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const { authors, books } = useLibraryStore();

  const author = authors.find(a => a.id === id);
  const authorBooks = author ? books.filter(b => b.authorId === author.id) : [];

  if (!author) {
    return (
      <div className="max-w-screen-xl mx-auto px-4 py-20 text-center">
        <div className="text-6xl mb-4">👤</div>
        <h2 className="text-2xl font-bold text-slate-700 mb-2">Автор не найден</h2>
        <Link to="/authors" className="inline-flex items-center gap-2 text-emerald-600 hover:underline">
          <ArrowLeft size={16} /> К авторам
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-screen-xl mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-slate-400 mb-6">
        <Link to="/" className="hover:text-emerald-600">Главная</Link>
        <span>/</span>
        <Link to="/authors" className="hover:text-emerald-600">Авторы</Link>
        <span>/</span>
        <span className="text-slate-600">{author.name}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
        {/* Author info card */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm">
            {/* Avatar */}
            <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-emerald-100 to-emerald-200 flex items-center justify-center mx-auto mb-4 overflow-hidden">
              {author.avatar ? (
                <img src={author.avatar} alt={author.name} className="w-full h-full object-cover" />
              ) : (
                <User size={40} className="text-emerald-600" />
              )}
            </div>

            <h1 className="text-xl font-bold text-slate-800 text-center mb-1">{author.name}</h1>
            {author.nameAr && (
              <p className="text-slate-400 text-center mb-4 font-arabic" dir="rtl">{author.nameAr}</p>
            )}

            {/* Meta info */}
            <div className="space-y-3 mb-4">
              {(author.born || author.died) && (
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Calendar size={15} className="text-emerald-500 shrink-0" />
                  <span>
                    {author.born && `р. ${author.born}`}
                    {author.born && author.died && ' — '}
                    {author.died && `ум. ${author.died}`}
                  </span>
                </div>
              )}
              {author.era && (
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Calendar size={15} className="text-emerald-500 shrink-0" />
                  <span>{author.era}</span>
                </div>
              )}
              {author.nationality && (
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <MapPin size={15} className="text-emerald-500 shrink-0" />
                  <span>{author.nationality}</span>
                </div>
              )}
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <BookOpen size={15} className="text-emerald-500 shrink-0" />
                <span>{authorBooks.length} книг в библиотеке</span>
              </div>
            </div>

            {/* Biography status badge */}
            {author.biographyStatus === 'pending' && (
              <div className="flex items-center gap-2 text-xs text-amber-600 bg-amber-50 border border-amber-100 rounded-xl px-3 py-2 mb-4">
                <AlertCircle size={13} />
                {t('authors.noBiography')}
              </div>
            )}

            <Link
              to="/admin/authors"
              className="flex items-center justify-center gap-2 w-full border border-emerald-200 text-emerald-700 hover:bg-emerald-50 px-4 py-2.5 rounded-xl text-sm font-medium transition-colors"
            >
              <Edit size={14} />
              Редактировать биографию
            </Link>
          </div>
        </div>

        {/* Biography */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm h-full">
            <h2 className="text-xl font-bold text-slate-800 mb-4">{t('authors.biography')}</h2>

            {author.biography ? (
              <div>
                <p className="text-slate-600 leading-relaxed">{author.biography}</p>
                {author.biographyAr && (
                  <div className="mt-6 p-4 bg-emerald-50 rounded-xl border border-emerald-100" dir="rtl">
                    <p className="text-slate-700 leading-relaxed font-arabic">{author.biographyAr}</p>
                  </div>
                )}
                {author.biographyEn && (
                  <div className="mt-4 p-4 bg-blue-50 rounded-xl border border-blue-100">
                    <p className="text-slate-600 leading-relaxed italic">{author.biographyEn}</p>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="w-16 h-16 rounded-2xl bg-amber-100 flex items-center justify-center mb-4">
                  <AlertCircle size={28} className="text-amber-500" />
                </div>
                <h3 className="text-lg font-semibold text-slate-700 mb-2">Биография не добавлена</h3>
                <p className="text-slate-400 text-sm max-w-sm">
                  Биография этого учёного пока не заполнена. Вы можете добавить её через панель администрирования.
                </p>
                <Link
                  to="/admin/authors"
                  className="mt-4 inline-flex items-center gap-2 bg-emerald-600 text-white px-4 py-2.5 rounded-xl text-sm font-medium hover:bg-emerald-700 transition-colors"
                >
                  <Edit size={14} />
                  Добавить биографию
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Author's Books */}
      <div>
        <h2 className="text-xl font-bold text-slate-800 mb-6">{t('authors.books')} ({authorBooks.length})</h2>
        {authorBooks.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {authorBooks.map(book => (
              <BookCard key={book.id} book={book} variant="grid" />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-slate-50 rounded-2xl">
            <p className="text-slate-400">Книги этого автора пока не добавлены в библиотеку</p>
          </div>
        )}
      </div>
    </div>
  );
}
