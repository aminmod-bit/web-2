import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { BookOpen } from 'lucide-react';
import { useLibraryStore } from '../store/libraryStore';

export default function CategoriesPage() {
  const { t } = useTranslation();
  const { categories, books } = useLibraryStore();

  const categoriesWithCount = categories.map(cat => ({
    ...cat,
    bookCount: books.filter(b => b.categoryId === cat.id).length,
  })).sort((a, b) => a.order - b.order);

  return (
    <div className="max-w-screen-xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800">{t('categories.title')}</h1>
        <p className="text-slate-500 mt-1">{t('categories.subtitle')} — {categories.length} разделов</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {categoriesWithCount.map(cat => (
          <Link
            key={cat.id}
            to={`/categories/${cat.slug}`}
            className="group bg-white rounded-2xl border border-slate-100 hover:border-emerald-200 hover:shadow-lg transition-all duration-200 overflow-hidden"
          >
            {/* Color header */}
            <div
              className="h-3"
              style={{ backgroundColor: cat.color || '#10b981' }}
            />
            <div className="p-5">
              <div className="flex items-start gap-3 mb-4">
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0"
                  style={{ backgroundColor: `${cat.color}20` || '#10b98120' }}
                >
                  {cat.icon || '📚'}
                </div>
                <div>
                  <h3 className="font-bold text-slate-800 group-hover:text-emerald-700 transition-colors">
                    {cat.name}
                  </h3>
                  {cat.nameAr && (
                    <p className="text-xs text-slate-400 mt-0.5 font-arabic" dir="rtl">{cat.nameAr}</p>
                  )}
                  {cat.nameEn && (
                    <p className="text-xs text-slate-300 mt-0.5 italic">{cat.nameEn}</p>
                  )}
                </div>
              </div>

              {cat.description && (
                <p className="text-sm text-slate-500 mb-4 line-clamp-2">{cat.description}</p>
              )}

              <div className="flex items-center gap-1.5 text-sm font-medium" style={{ color: cat.color || '#10b981' }}>
                <BookOpen size={14} />
                <span>{cat.bookCount} {cat.bookCount === 1 ? 'книга' : cat.bookCount < 5 ? 'книги' : 'книг'}</span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
