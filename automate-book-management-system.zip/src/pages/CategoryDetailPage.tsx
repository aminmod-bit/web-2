import { useParams, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, BookOpen } from 'lucide-react';
import { useLibraryStore } from '../store/libraryStore';
import BookCard from '../components/ui/BookCard';

export default function CategoryDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const { t } = useTranslation();
  const { categories, books } = useLibraryStore();

  const category = categories.find(c => c.slug === slug);
  const categoryBooks = category ? books.filter(b => b.categoryId === category.id) : [];

  if (!category) {
    return (
      <div className="max-w-screen-xl mx-auto px-4 py-20 text-center">
        <div className="text-6xl mb-4">📂</div>
        <h2 className="text-2xl font-bold text-slate-700 mb-2">Категория не найдена</h2>
        <Link to="/categories" className="inline-flex items-center gap-2 text-emerald-600 hover:underline">
          <ArrowLeft size={16} /> К категориям
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-screen-xl mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-slate-400 mb-6">
        <Link to="/" className="hover:text-emerald-600">Главная</Link>
        <span>/</span>
        <Link to="/categories" className="hover:text-emerald-600">Категории</Link>
        <span>/</span>
        <span className="text-slate-600">{category.name}</span>
      </div>

      {/* Category header */}
      <div className="mb-8 flex items-center gap-4">
        <div
          className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl"
          style={{ backgroundColor: `${category.color}20` }}
        >
          {category.icon || '📚'}
        </div>
        <div>
          <h1 className="text-3xl font-bold text-slate-800">{category.name}</h1>
          {category.nameAr && (
            <p className="text-slate-400 font-arabic mt-0.5" dir="rtl">{category.nameAr}</p>
          )}
          {category.description && (
            <p className="text-slate-500 text-sm mt-1">{category.description}</p>
          )}
          <p className="text-slate-400 text-sm mt-1">
            <span className="font-semibold text-slate-600">{categoryBooks.length}</span> {t('categories.booksInCategory')}
          </p>
        </div>
      </div>

      {/* Books */}
      {categoryBooks.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {categoryBooks.map(book => (
            <BookCard key={book.id} book={book} variant="grid" />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-slate-50 rounded-2xl">
          <div className="text-6xl mb-4">📚</div>
          <h3 className="text-xl font-semibold text-slate-600 mb-2">В этой категории пока нет книг</h3>
          <p className="text-slate-400 text-sm mb-4">Книги будут добавлены через систему импорта</p>
          <Link
            to="/admin/import"
            className="inline-flex items-center gap-2 bg-emerald-600 text-white px-4 py-2.5 rounded-xl text-sm font-medium hover:bg-emerald-700 transition-colors"
          >
            <BookOpen size={14} />
            Импортировать книги
          </Link>
        </div>
      )}
    </div>
  );
}
