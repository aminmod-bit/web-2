import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

import ru from './locales/ru';
import ar from './locales/ar';
import en from './locales/en';

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      ru: { translation: ru },
      ar: { translation: ar },
      en: { translation: en },
    },
    fallbackLng: 'ru',
    supportedLngs: ['ru', 'ar', 'en'],
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage'],
    },
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;
export type SupportedLang = 'ru' | 'ar' | 'en';
