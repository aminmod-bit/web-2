<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Биография — Salaf Library</title>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Noto+Naskh+Arabic:wght@500;600;700&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0}
:root{--bg:#f6f3ec;--paper:#fffdf8;--ink:#1c1c1a;--muted:#6f6d66;--green:#16613f;--line:#e2ddd2;--r:14px}
@media(prefers-color-scheme:dark){:root{--bg:#141710;--paper:#1b1e19;--ink:#e7e2d8;--muted:#a09888;--green:#3ea96e;--line:#2b2b27}}
body{font-family:'Manrope',system-ui,sans-serif;background:var(--bg);color:var(--ink);line-height:1.6}
a{color:var(--green);text-decoration:none}
.ar{font-family:'Noto Naskh Arabic',serif}
.h{border-bottom:1px solid var(--line);background:var(--paper)}
.hi{max-width:980px;margin:0 auto;padding:12px 18px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;color:inherit}
.bm{width:34px;height:34px;border-radius:9px;background:linear-gradient(145deg,#1d7a4b,#123f2b);display:grid;place-items:center;color:#fff7e8;font-family:'Noto Naskh Arabic',serif;font-size:15px}
.wrap{max-width:980px;margin:0 auto;padding:30px 18px 60px}
.bio-head{display:flex;gap:22px;flex-wrap:wrap;align-items:flex-start;margin-bottom:22px}
.bio-avatar{width:110px;height:110px;border-radius:16px;background:#1a4d33;color:#dcc89a;display:grid;place-items:center;font-size:36px;font-weight:700}
.bio-h1{font-size:28px;font-weight:800}
.bio-ar{font-family:'Noto Naskh Arabic',serif;font-size:20px;color:var(--muted);margin-top:2px}
.bio-meta{color:var(--muted);font-size:14px;margin-top:6px}
.bio-text{max-width:700px;font-size:15.5px;line-height:1.7;margin-top:14px;white-space:pre-wrap}
.tag{display:inline-block;font-size:12px;background:var(--paper);border:1px solid var(--line);padding:3px 10px;border-radius:999px;margin-right:6px;color:var(--muted)}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:14px;margin-top:18px}
.card{background:var(--paper);border:1px solid var(--line);border-radius:12px;overflow:hidden}
.card img{width:100%;aspect-ratio:2/2.8;object-fit:cover;display:block;background:#164a32}
.card-body{padding:10px 11px}
.card-title{font-size:13.5px;font-weight:700;line-height:1.35}
.card-meta{font-size:12px;color:var(--muted);margin-top:3px}
.section-title{font-size:18px;font-weight:700;margin:28px 0 10px}
.back{font-size:13.5px;color:var(--muted)}
</style>
</head>
<body>
<header class="h">
  <div class="hi">
    <a class="brand" href="index.html"><div class="bm">سلف</div> Salaf Library</a>
    <nav style="font-size:14px;color:var(--muted);display:flex;gap:16px;flex-wrap:wrap">
      <a href="index.html">Книги</a>
      <a href="scholars.html">Учёные</a>
      <a href="bio.html?type=prophets">Пророки</a>
      <a href="bio.html?type=companions">Сподвижники</a>
      <a href="bio.html?type=tabiin">Таби'ины</a>
    </nav>
  </div>
</header>
<div class="wrap" id="app">Загрузка…</div>

<script>
const TYPES = {
  scholar: {file:'data/scholars.json', title:'Учёные', key:'scholars'},
  scholars: {file:'data/scholars.json', title:'Учёные', key:'scholars'},
  prophet: {file:'data/prophets.json', title:'Пророки', key:'prophets'},
  prophets: {file:'data/prophets.json', title:'Пророки', key:'prophets'},
  companion: {file:'data/companions.json', title:'Сподвижники', key:'companions'},
  companions: {file:'data/companions.json', title:'Сподвижники', key:'companions'},
  tabiin: {file:'data/tabiin.json', title:'Таби\'ины', key:'tabiin'},
  author: {file:'data/authors.json', title:'Авторы', key:'authors'},
  authors: {file:'data/authors.json', title:'Авторы', key:'authors'},
};

function esc(s){return (s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function q(name){return new URLSearchParams(location.search).get(name)}

(async ()=>{
  const typeRaw = (q('type')||'scholar').toLowerCase();
  const t = TYPES[typeRaw] || TYPES.scholar;
  const slug = q('slug') || q('id');
  const app = document.getElementById('app');
  
  let list=[]; try{ list = await fetch(t.file).then(r=>r.json()) }catch(e){}
  if(!slug){
    // list view
    app.innerHTML = `<p class="back"><a href="index.html">← Библиотека</a></p>
    <h1 style="font-size:26px;font-weight:800;margin:10px 0 16px">${t.title}</h1>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:12px">
    ${list.map(p=>`
      <a href="bio.html?type=${encodeURIComponent(typeRaw)}&slug=${encodeURIComponent(p.slug||p.id)}" style="color:inherit;background:var(--paper);border:1px solid var(--line);border-radius:12px;padding:14px 15px;display:block">
        <b>${esc(p.name)}</b>
        ${p.name_ar?`<div class="ar" style="color:var(--muted)">${esc(p.name_ar)}</div>`:''}
        ${p.birth||p.death?`<div style="font-size:12.5px;color:var(--muted);margin-top:4px">${esc(p.birth||'?')} – ${esc(p.death||'')}</div>`:''}
        ${p.bio_short?`<div style="font-size:13px;color:var(--muted);margin-top:4px">${esc(p.bio_short)}</div>`:''}
      </a>`).join('')}
    </div>`;
    document.title = t.title + ' — Salaf Library';
    return;
  }
  const person = list.find(p => (p.slug===slug)||(p.id===slug));
  if(!person){ app.innerHTML = 'Не найдено'; return }
  document.title = person.name + ' — Salaf Library';
  // load books by this author
  let books=[]; try{ books = await fetch('data/books.json').then(r=>r.json()) }catch(e){}
  const authorBooks = books.filter(b => b.author_id === person.id || (person.name && b.author_name && b.author_name.includes(person.name.split(' ').slice(-2).join(' '))));
  const initials = person.name.split(/\s+/).map(w=>w[0]).slice(0,2).join('').toUpperCase();
  app.innerHTML = `
  <p class="back"><a href="bio.html?type=${encodeURIComponent(typeRaw)}">← ${t.title}</a> · <a href="index.html">Библиотека</a></p>
  <div class="bio-head">
    <div class="bio-avatar">${esc(initials)}</div>
    <div>
      <div class="bio-h1">${esc(person.name)}</div>
      ${person.name_ar?`<div class="bio-ar">${esc(person.name_ar)}</div>`:''}
      <div class="bio-meta">${person.birth?esc(person.birth):''}${person.death?' – '+esc(person.death):''}</div>
      ${(person.tags||[]).map(x=>`<span class="tag">${esc(x)}</span>`).join(' ')}
      <div class="bio-text">${esc(person.bio_short||person.bio||'Биография будет добавлена, ин ша Аллах.')}</div>
    </div>
  </div>
  ${authorBooks.length ? `<div class="section-title">Книги ${authorBooks.length}</div>
  <div class="grid">
    ${authorBooks.map(b=>`
    <a class="card" href="book.html?id=${encodeURIComponent(b.id)}" style="color:inherit">
      ${b.cover ? `<img src="${b.cover}" loading="lazy" alt="">` : `<div style="aspect-ratio:2/2.8;background:#1a4d33"></div>`}
      <div class="card-body">
        <div class="card-title">${esc(b.title)}</div>
        <div class="card-meta">${b.pages?b.pages+' стр':''}</div>
      </div>
    </a>`).join('')}
  </div>`: '<p style="color:var(--muted)">Книг этого автора в библиотеке пока нет.</p>'}
  `;
})();
</script>
</body>
</html>