#!/usr/bin/env python3
"""Rebuild search-index.json, sitemap.xml, robots.txt, feed.xml, OG images"""
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
BASE_URL = "https://aminmod-bit.github.io/salaf-library/"

books = json.loads((DATA / "books.json").read_text(encoding="utf-8"))
authors = json.loads((DATA / "authors.json").read_text(encoding="utf-8"))
for name in ["scholars","prophets","companions","tabiin"]:
    p = DATA / f"{name}.json"
    if not p.exists(): p.write_text("[]", encoding="utf-8")

# search-index
def load_list(fn):
    f = DATA / fn
    return json.loads(f.read_text(encoding="utf-8")) if f.exists() else []

search = []
for b in books:
    search.append({"id":b["id"],"type":"book","title":b["title"],"title_ar":b.get("title_ar",""),"author":b.get("author_name",""),"author_id":b.get("author_id",""),"category":b["category"],"tags":b.get("tags",[]),"description":b.get("description",""),"lang":b.get("lang","ru"),"url":f"book.html?id={b['id']}"})
for a in authors:
    search.append({"id":a["id"],"type":"author","title":a["name"],"title_ar":a.get("name_ar",""),"author":"","author_id":a["id"],"category":"authors","tags":a.get("tags",[]),"description":a.get("bio_short",""),"lang":"ru","url":f"bio.html?type=author&slug={a['slug']}"})
for kind, tname in [("scholars","scholar"),("prophets","prophet"),("companions","companion"),("tabiin","tabiin")]:
    for p in load_list(f"{kind}.json"):
        search.append({"id":p["id"],"type":tname,"title":p["name"],"title_ar":p.get("name_ar",""),"author":"","author_id":"","category":kind,"tags":p.get("tags",[]),"description":p.get("bio_short",""),"lang":"ru","url":f"bio.html?type={kind}&slug={p['slug']}"})
(DATA / "search-index.json").write_text(json.dumps(search, ensure_ascii=False), encoding="utf-8")
print(f"search-index: {len(search)}")

# sitemap
urls = ["index.html","bio.html?type=scholars","bio.html?type=prophets","bio.html?type=companions","bio.html?type=tabiin","audio.html","fawaid.html"]
urls += [f"book.html?id={b['id']}" for b in books]
urls += [f"bio.html?type=author&slug={a['slug']}" for a in authors]
sitemap = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + "\n".join([f'  <url><loc>{BASE_URL}{u.replace("&","&amp;")}</loc><changefreq>weekly</changefreq></url>' for u in urls]) + '\n</urlset>\n'
(ROOT / "sitemap.xml").write_text(sitemap, encoding="utf-8")
print(f"sitemap: {len(urls)} URLs")

# robots
(ROOT / "robots.txt").write_text(f"User-agent: *\nAllow: /\nSitemap: {BASE_URL}sitemap.xml\n", encoding="utf-8")

# RSS
from xml.sax.saxutils import escape
recent = books[-30:][::-1]
rss_items = "\n".join([f"<item><title>{escape(b['title'])}</title><link>{BASE_URL}book.html?id={b['id']}</link><guid>{BASE_URL}book.html?id={b['id']}</guid><description>{escape(b.get('author_name',''))}</description></item>" for b in recent])
rss = f'<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>Salaf Library — Новые книги</title><link>{BASE_URL}</link><description>Библиотека исламских книг Ахлю-с-Сунна</description><language>ru</language>\n{rss_items}\n</channel></rss>'
(ROOT / "feed.xml").write_text(rss, encoding="utf-8")
print(f"RSS: {len(recent)} items")

# OG images
og_dir = ROOT / "images" / "og"
og_dir.mkdir(parents=True, exist_ok=True)
try:
    f_b = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 56)
    f_s = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 30)
except: f_b = ImageFont.load_default(); f_s = f_b

def og_image(text, sub, out_path, ar=""):
    im = Image.new("RGB", (1200, 630), (22, 88, 54))
    d = ImageDraw.Draw(im)
    # title wrap
    y=170; words=text.split(); line=""; 
    for w in words:
        test=(line+" "+w).strip()
        if d.textlength(test, font=f_b) > 1060 and line:
            d.text((60,y), line, fill=(235,222,195), font=f_b); y+=66; line=w
        else: line=test
    if line: d.text((60,y), line, fill=(235,222,195), font=f_b)
    if sub: d.text((60, 460), sub[:80], fill=(195,170,130), font=f_s)
    if ar: d.text((60, 520), ar, fill=(190,155,95), font=f_s)
    d.text((60, 570), "مكتبة السلف  •  Salaf Library", fill=(160,130,90), font=f_s)
    im.save(out_path)
    print("OG", out_path.name)

# home
og_image("مكتبة السلف", "Библиотека исламских книг Ахлю-с-Сунна", og_dir / "home.png")
# books
for b in books:
    out = og_dir / f"{b['id'].lower()}.png"
    if out.exists(): continue
    og_image(b["title"][:70], b.get("author_name","")[:60], out, b.get("title_ar",""))
print("OG done")

print("\nAll indexes rebuilt.")
