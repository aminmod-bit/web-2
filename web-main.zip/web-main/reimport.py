#!/usr/bin/env python3
# Re-import books from github with proper UTF-8 handling, enrich authors + biographies from telegraph
import json, re
from pathlib import Path
import requests
from io import BytesIO
try:
    from pypdf import PdfReader
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    print("pip install pypdf pillow requests"); raise SystemExit(1)

ROOT = Path(__file__).parent
DATA = ROOT / "data"
BOOKS_DIR = ROOT / "books"
IMG_COVERS = ROOT / "images" / "covers"
for p in [DATA, BOOKS_DIR/"aqida", BOOKS_DIR/"hadith", BOOKS_DIR/"tafsir", BOOKS_DIR/"fiqh", BOOKS_DIR/"biography", BOOKS_DIR/"other", IMG_COVERS,
          ROOT/"audio"/"aqida", ROOT/"audio"/"hadith", ROOT/"audio"/"tafsir", ROOT/"audio"/"biography",
          ROOT/"images"/"authors", ROOT/"bio"]:
    p.mkdir(parents=True, exist_ok=True)

# Get PDF list
r = requests.get("https://api.github.com/repos/aminmod-bit/salaf-library/contents/books", headers={"User-Agent":"salaf"}, timeout=20)
files = [x for x in r.json() if isinstance(x, dict) and x.get("name","").lower().endswith(".pdf")]
print(f"Found {len(files)} PDFs")

def slugify(s):
    s = re.sub(r"[^\w\s-]", "", s, flags=re.UNICODE)
    s = re.sub(r"[-\s]+", "-", s.strip().lower())
    return s[:90] or "n-a"

def classify(filename, text=""):
    f=(filename+" "+text).lower()
    if any(k in f for k in ["акыд","таухид","иман","вероубежд","основа","усуль","васит","тахави","навакид","мессия","богом","убежден"]): return "aqida"
    if any(k in f for k in ["хадис","сунна","суннан","абу дауд","бухари","муслим","даджжал"]): return "hadith"
    if any(k in f for k in ["тафсир","коран"]): return "tafsir"
    if any(k in f for k in ["фикх","пост","закят","хадж","умра","молитв","намаз","брак","этикет","нрав","адаб","дуа","азкар","поминани","внешн","справления"]): return "fiqh"
    if any(k in f for k in ["биографи","ибн таймия","ибн каййим"]): return "biography"
    return "other"

# Better author extraction
AUTHOR_PATTERNS = [
    (r"[—–\-]\s*([^.\\/\n]{3,60})\.pdf$", 1),
    (r",\s*([А-ЯA-ZЁ][^,]{2,60})\.pdf$", 1),
]
KNOWN_AUTHORS = {
    "ибн таймия": "Шейхуль-Ислам Ибн Таймия",
    "ибн аль-каййим": "Ибн аль-Каййим",
    "ибн каййим": "Ибн аль-Каййим",
    "ибн усеймин": "Шейх Ибн Усеймин",
    "усеймин": "Шейх Ибн Усеймин",
    "ибн баз": "Шейх Ибн Баз",
    "аль-альбани": "Шейх аль-Альбани",
    "альбани": "Шейх аль-Альбани",
    "ан-навави": "Имам ан-Навави",
    "ас-саади": "Шейх ас-Саади",
    "аль-мунаджид": "Шейх аль-Мунаджид",
    "аш-шувейир": "Шейх аш-Шувейир",
    "ар-раджихи": "Шейх ар-Раджихи",
    "аль-каннас": "аль-Каннас",
    "абдуль-мухсин": "Абдуль-Мухсин аль-Касим",
}
def extract_author(filename):
    for pat,_ in AUTHOR_PATTERNS:
        m=re.search(pat, filename)
        if m:
            name=m.group(1).strip()
            if 2 < len(name) < 70 and not re.search(r'\d', name):
                return name
    fl=filename.lower()
    for key,val in KNOWN_AUTHORS.items():
        if key in fl: return val
    return ""

def clean_title(filename):
    t=filename.replace(".pdf","").replace("_"," ")
    t=re.sub(r"\s*[—–\-]\s*[А-ЯA-ZЁ][^—–\-]{2,80}$", "", t)
    t=re.sub(r",\s*[А-ЯA-ZЁ][^,]{2,60}$", "", t)
    return t.strip()

books=[]; authors_map={}
aid_counter=1
def get_author_id(name):
    global aid_counter
    if not name: return ""
    if name not in authors_map:
        slug = slugify(name)
        authors_map[name] = {"id": f"au-{aid_counter:03d}", "name": name, "slug": slug or f"author-{aid_counter}",
            "name_ar":"", "birth":"", "death":"", "bio_short":"", "photo":"" }
        aid_counter+=1
    return authors_map[name]["id"]

# Download and process
for i, item in enumerate(files,1):
    name=item["name"]; url=item["download_url"]
    print(f"[{i}/{len(files)}] {name}", end=" ... ", flush=True)
    try:
        pdf_bytes=requests.get(url, timeout=30).content
    except Exception as e: print(f"dl fail {e}"); continue
    try:
        reader=PdfReader(BytesIO(pdf_bytes)); pages=len(reader.pages)
        meta = reader.metadata or {}
        title_meta = (meta.title or "").strip()
    except: pages=0; title_meta=""
    text_sample=""
    try:
        if pages>0: text_sample=(reader.pages[0].extract_text() or "")[:600]
    except: pass
    cat=classify(name, text_sample)
    title = title_meta if title_meta and len(title_meta)>3 else clean_title(name)
    author_name = extract_author(name)
    author_id = get_author_id(author_name)
    safe_name = re.sub(r'[<>:"/\\|?*]', "-", name)
    safe_name = re.sub(r"\s+", " ", safe_name).strip()
    out_pdf = BOOKS_DIR/cat/safe_name
    if not out_pdf.exists(): out_pdf.write_bytes(pdf_bytes)
    cover_id=f"BK{i:04d}"; cover_path=IMG_COVERS/f"{cover_id}.webp"; cover_made=False
    try:
        img=Image.new("RGB",(400,560),(19,73,47))
        d=ImageDraw.Draw(img)
        try: font=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)
        except: font=ImageFont.load_default()
        try: font_s=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 13)
        except: font_s=font
        # wrap
        words=title.split(); lines=[]; cur=""
        for w in words:
            if len(cur+w) < 24: cur=(cur+" "+w).strip()
            else: lines.append(cur); cur=w
        if cur: lines.append(cur)
        y=120
        for ln in lines[:7]:
            d.text((28,y), ln, fill=(235,222,195), font=font); y+=26
        if author_name:
            d.text((28, 430), author_name[:36], fill=(195,170,130), font=font_s)
        d.text((28, 510), "مكتبة السلف", fill=(190,155,95), font=font_s)
        img.save(cover_path,"WEBP",quality=84); cover_made=True
    except Exception as e: print(f" cover {e}", end=" ")
    book_id=f"{cat[:2].upper()}{i:04d}"
    books.append({
        "id":book_id, "slug":slugify(title) or f"book-{i}",
        "title":title, "title_ar":"",
        "author_id":author_id, "author_name":author_name,
        "category":cat, "lang":"ru", "pages":pages, "year":"",
        "file":f"books/{cat}/{safe_name}",
        "cover": f"images/covers/{cover_id}.webp" if cover_made else "",
        "description":"", "tags":[]
    })
    print(f"ok {cat} {pages}p")

# Enrich authors from telegraph biographies
# Fetch biographies page
def fetch_telegraph(url):
    try:
        r=requests.get(url, timeout=15); r.raise_for_status(); return r.text
    except: return ""
bio_html = fetch_telegraph("https://telegra.ph/Biografii-06-19")
# simple extract names
bio_names = re.findall(r'>([А-ЯЁA-Z][^<]{3,60}?) — 📖', bio_html)
# Build scholars list
scholars=[]
prophets=[]
companions=[]
tabiin=[]

# Predefined scholars with bio
predef_scholars = [
  {"name":"Шейхуль-Ислам Ибн Таймия","name_ar":"ابن تيمية","birth":"661","death":"728","bio_short":"Шейхуль-Ислам, имам ахлю-сунна.","tags":["aqida","fiqh"]},
  {"name":"Ибн аль-Каййим","name_ar":"ابن القيم","birth":"691","death":"751","bio_short":"Ученик Ибн Таймии, имам.","tags":["aqida","tazkiya"]},
  {"name":"Имам ан-Навави","name_ar":"النووي","birth":"631","death":"676","bio_short":"Имам-хадисовед, шафиит.","tags":["hadith","fiqh"]},
  {"name":"Имам аль-Бухари","name_ar":"البخاري","birth":"194","death":"256","bio_short":"Автор «Сахих аль-Бухари».","tags":["hadith"]},
  {"name":"Имам Муслим","name_ar":"مسلم","birth":"206","death":"261","bio_short":"Автор «Сахих Муслим».","tags":["hadith"]},
  {"name":"Имам Ахмад ибн Ханбаль","name_ar":"أحمد بن حنبل","birth":"164","death":"241","bio_short":"Имам ахлю-сунна.","tags":["aqida","hadith","fiqh"]},
  {"name":"Шейх Ибн Баз","name_ar":"ابن باز","birth":"1330","death":"1420","bio_short":"Муфтий Саудовской Аравии.","tags":["aqida","fiqh"]},
  {"name":"Шейх Ибн Усеймин","name_ar":"ابن عثيمين","birth":"1347","death":"1421","bio_short":"Выдающийся учёный КСА.","tags":["aqida","fiqh"]},
  {"name":"Шейх аль-Альбани","name_ar":"الألباني","birth":"1333","death":"1420","bio_short":"Мухаддис 20 века.","tags":["hadith"]},
  {"name":"Шейх Салих аль-Фаузан","name_ar":"الفوزان","birth":"1354","death":"","bio_short":"Член Комитета старейших учёных КСА.","tags":["aqida"]},
  {"name":"Шейх ас-Саади","name_ar":"السعدي","birth":"1307","death":"1376","bio_short":"Муфассир.","tags":["tafsir"]},
  {"name":"Шейх ар-Раджихи","name_ar":"الراجحي","bio_short":"","tags":[]},
  {"name":"Шейх аль-Мунаджид","name_ar":"المنجد","bio_short":"","tags":[]},
  {"name":"Шейх аш-Шувейир","name_ar":"الشويعر","bio_short":"","tags":[]},
]

# Merge into authors_map
for s in predef_scholars:
    n=s["name"]
    if n in authors_map:
        authors_map[n].update({k:v for k,v in s.items() if v})
    else:
        aid = get_author_id(n)
        authors_map[n].update({k:v for k,v in s.items() if v})

# Build scholars.json from authors with bio info
authors_list = sorted(authors_map.values(), key=lambda x: x["id"])
for a in authors_list:
    if a.get("bio_short") or a.get("birth"):
        scholars.append({
            "id": a["id"], "name": a["name"], "name_ar": a.get("name_ar",""),
            "slug": a["slug"], "birth": a.get("birth",""), "death": a.get("death",""),
            "bio_short": a.get("bio_short",""),
            "photo": a.get("photo",""),
            "tags": a.get("tags",[])
        })

# Prophets / Companions / Tabiin from telegraph
prophet_names = ["Адам","Идрис","Нух","Худ","Салих","Ибрахим","Лут","Исмаил","Исхак","Якуб","Юсуф","Айюб","Шуайб","Муса","Харун","Давуд","Сулейман","Ильяс","Аль-Яса","Юнус","Закария","Яхья","Иса","Мухаммад"]
for idx, n in enumerate(prophet_names,1):
    prophets.append({"id":f"pr-{idx:03d}","name":f"{n} ﷺ","slug":slugify(n),"bio_short":"","order":idx})
companion_names = ["Абу Бакр ас-Сиддик","Умар ибн аль-Хаттаб","Усман ибн Аффан","Али ибн Абу Талиб","Тальха ибн Убайдуллах","аз-Зубайр ибн аль-Аввам","Абдуррахман ибн Ауф","Са'д ибн Абу Ваккас","Са'ид ибн Зайд","Абу Убайда ибн аль-Джаррах"]
for idx, n in enumerate(companion_names,1):
    companions.append({"id":f"co-{idx:03d}","name":n,"slug":slugify(n),"bio_short":""})
tabiin_names = ["Са'ид ибн аль-Мусаййиб","Урва ибн аз-Зубайр","аль-Хасан аль-Басри","Мухаммад ибн Сирин","Ибрахим ан-Наха'и","Амир аш-Ша'би","Ата ибн Абу Рабах","Таус ибн Кайсан","Муджахид ибн Джабр","Макхуль ад-Димашки"]
for idx, n in enumerate(tabiin_names,1):
    tabiin.append({"id":f"tb-{idx:03d}","name":n,"slug":slugify(n),"bio_short":""})

# write JSONs
(DATA/"books.json").write_text(json.dumps(books, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA/"authors.json").write_text(json.dumps(authors_list, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA/"scholars.json").write_text(json.dumps(scholars, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA/"prophets.json").write_text(json.dumps(prophets, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA/"companions.json").write_text(json.dumps(companions, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA/"tabiin.json").write_text(json.dumps(tabiin, ensure_ascii=False, indent=2), encoding="utf-8")
for fn in ["audio.json","fawaid.json"]:
    p=DATA/fn
    if not p.exists(): p.write_text("[]", encoding="utf-8")

cats=[
  {"id":"aqida","name":"Акыда","name_ar":"العقيدة","slug":"aqida","count": sum(1 for b in books if b["category"]=="aqida")},
  {"id":"hadith","name":"Хадис","name_ar":"الحديث","slug":"hadith","count": sum(1 for b in books if b["category"]=="hadith")},
  {"id":"tafsir","name":"Тафсир","name_ar":"التفسير","slug":"tafsir","count": sum(1 for b in books if b["category"]=="tafsir")},
  {"id":"fiqh","name":"Фикх","name_ar":"الفقه","slug":"fiqh","count": sum(1 for b in books if b["category"]=="fiqh")},
  {"id":"biography","name":"Биографии","name_ar":"السير","slug":"biography","count": sum(1 for b in books if b["category"]=="biography")},
  {"id":"other","name":"Разное","name_ar":"متفرقات","slug":"other","count": sum(1 for b in books if b["category"]=="other")},
]
(DATA/"categories.json").write_text(json.dumps(cats, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"\nDone. Books:{len(books)} Authors:{len(authors_list)} Scholars:{len(scholars)} Prophets:{len(prophets)} Companions:{len(companions)} Tabiin:{len(tabiin)}")
print(", ".join([f"{c['id']}:{c['count']}" for c in cats]))
