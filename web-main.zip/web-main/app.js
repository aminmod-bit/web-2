// Salaf Library — shared app
// Storage keys
const SL = {
  theme: 'sl_theme',
  fav: 'sl_fav',
  history_books: 'sl_hist_books',
  history_audio: 'sl_hist_audio',
  history_bio: 'sl_hist_bio',
  readPos: 'sl_readpos_',
  audioPos: 'sl_audiopos_',
  seen_counts: 'sl_seen_counts'
};

// Theme
(function(){
  const saved = localStorage.getItem(SL.theme);
  const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  const theme = saved || (prefersDark ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme', theme);
})();
function toggleTheme(){
  const cur = document.documentElement.getAttribute('data-theme') || 'light';
  const next = cur === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem(SL.theme, next);
  toast(next === 'dark' ? 'Тёмная тема' : 'Светлая тема');
}

// Favorites
function getFav(){ try{ return JSON.parse(localStorage.getItem(SL.fav)||'{"books":[],"audio":[],"bio":[]}') }catch(e){ return {books:[],audio:[],bio:[]} } }
function saveFav(f){ localStorage.setItem(SL.fav, JSON.stringify(f)); updateFavCount() }
function toggleFav(type, id){
  const f = getFav();
  const key = type + 's';
  const arr = f[key] || (f[key]=[]);
  const i = arr.indexOf(id);
  if(i>=0){ arr.splice(i,1); toast('Удалено из избранного'); return false }
  else { arr.unshift(id); toast('Добавлено в избранное ❤️'); return true }
}
function isFav(type, id){ const f=getFav(); return (f[type+'s']||[]).includes(id) }
function updateFavCount(){
  const f = getFav();
  const n = (f.books?.length||0)+(f.audio?.length||0)+(f.bio?.length||0);
  document.querySelectorAll('.fav-count').forEach(el=>{ el.textContent = n ? n : ''; el.style.display = n ? '' : 'none' });
}

// History
function pushHistory(key, id, extra={}){
  try{
    const list = JSON.parse(localStorage.getItem(key) || '[]');
    const filtered = list.filter(x => (x.id||x) !== id);
    filtered.unshift({id, t: Date.now(), ...extra});
    localStorage.setItem(key, JSON.stringify(filtered.slice(0,60)));
  }catch(e){}
}
function getHistory(key){ try{ return JSON.parse(localStorage.getItem(key)||'[]') }catch(e){ return [] } }
function recordBookOpen(id, page=1){ pushHistory(SL.history_books, id, {page}); }
function recordAudioListen(id, pos=0){ pushHistory(SL.history_audio, id, {pos}); }
function recordBioView(id){ pushHistory(SL.history_bio, id, {}); }

// Reading position
function saveReadPos(bookId, page){ localStorage.setItem(SL.readPos + bookId, String(page||1)) }
function getReadPos(bookId){ return parseInt(localStorage.getItem(SL.readPos + bookId)||'1',10) }
function saveAudioPos(audioId, sec){ localStorage.setItem(SL.audioPos + audioId, String(Math.floor(sec||0))) }
function getAudioPos(audioId){ return parseFloat(localStorage.getItem(SL.audioPos + audioId)||'0') }

// Toast
function toast(msg, ms=2300){
  let box = document.getElementById('sl_toasts');
  if(!box){ box=document.createElement('div'); box.id='sl_toasts'; document.body.appendChild(box); }
  const el = document.createElement('div');
  el.className='sl-toast'; el.textContent = msg;
  box.appendChild(el);
  setTimeout(()=>{ el.style.opacity='0'; el.style.transform='translateY(6px)'; setTimeout(()=>el.remove(),220); }, ms);
}

// Data loaders (cached)
let _BOOKS=null, _AUTHORS=null, _SEARCH=null;
async function loadBooks(){ if(_BOOKS) return _BOOKS; const r=await fetch('data/books.json'); _BOOKS = r.ok ? await r.json() : []; return _BOOKS }
async function loadAuthors(){ if(_AUTHORS) return _AUTHORS; try{ const r=await fetch('data/authors.json'); _AUTHORS = r.ok ? await r.json() : [] }catch(e){_AUTHORS=[]} return _AUTHORS }
async function loadSearchIndex(){ if(_SEARCH) return _SEARCH; try{ const r=await fetch('data/search-index.json'); _SEARCH = r.ok ? await r.json() : null }catch(e){ _SEARCH=null } return _SEARCH }
async function loadBio(type){ const map={scholar:'data/scholars.json',scholars:'data/scholars.json',prophet:'data/prophets.json',prophets:'data/prophets.json',companion:'data/companions.json',companions:'data/companions.json',tabiin:'data/tabiin.json',author:'data/authors.json',authors:'data/authors.json'}; const url=map[type]||map.scholar; try{ const r=await fetch(url); return r.ok ? await r.json() : [] }catch(e){ return [] } }

function escHtml(s){return (s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}

// book card HTML
function bookCardHtml(b, authorsMap={}){
  const authorName = b.author_name || '';
  const authorId = b.author_id || '';
  const authorLink = authorId && authorsMap[authorId] ? `<a href="bio.html?type=author&slug=${encodeURIComponent(authorsMap[authorId].slug)}" onclick="event.stopPropagation()">${escHtml(authorName)}</a>` : escHtml(authorName||'—');
  const coverSrc = b.thumb || b.cover || '';
  const cover = coverSrc ? `<img src="${coverSrc}" loading="lazy" alt="">` : `<div class="sl-cover-fallback">${escHtml(b.title.slice(0,70))}${authorName?`<small>${escHtml(authorName)}</small>`:''}</div>`;
  const catNames = {aqida:'Акыда',hadith:'Хадис',tafsir:'Тафсир',fiqh:'Фикх',biography:'Биографии',other:'Разное'};
  const langLabel = b.lang === 'ar' ? 'AR · ' : '';
  return `<article class="sl-card" onclick="openBook('${b.id}')">
    <div class="sl-cover">${cover}<span class="sl-badge">${catNames[b.category]||b.category}</span>
      <button class="sl-fav-btn${isFav('book', b.id)?' on':''}" onclick="event.stopPropagation(); const on=toggleFav('book','${b.id}'); this.classList.toggle('on', on); this.textContent = on ? '♥' : '♡'" aria-label="В избранное">${isFav('book',b.id)?'♥':'♡'}</button>
    </div>
    <div class="sl-card-body">
      <div class="sl-card-title">${escHtml(b.title)}</div>
      <div class="sl-card-author">${authorLink}</div>
      <div class="sl-card-meta">${langLabel}${b.pages?b.pages+' стр':''}</div>
      <div class="sl-card-actions" onclick="event.stopPropagation()">
        <button class="sl-btn primary" onclick="openBook('${b.id}')">Открыть</button>
        <a class="sl-btn" href="${b.file}" download>PDF</a>
      </div>
    </div>
  </article>`;
}
function openBook(id){ recordBookOpen(id, getReadPos(id)); location.href = 'book.html?id='+encodeURIComponent(id) }

// PWA install
let deferredPrompt=null;
window.addEventListener('beforeinstallprompt', (e)=>{ e.preventDefault(); deferredPrompt=e; showInstallBanner(true); const il=document.getElementById('installLink'); if(il) il.style.display='' });
function showInstallBanner(show){
  let el=document.getElementById('sl_install_banner');
  if(!el && show){
    el=document.createElement('div'); el.id='sl_install_banner';
    el.innerHTML = `<span>📲 Установить Salaf Library как приложение?</span>
      <button class="sl-btn primary" id="sl_install_go" style="font-size:12.5px;padding:5px 10px">Установить</button>
      <button class="sl-btn" id="sl_install_no" style="font-size:12.5px;padding:5px 10px">×</button>`;
    document.body.appendChild(el);
    el.querySelector('#sl_install_go').onclick = async ()=>{
      el.classList.remove('show'); if(deferredPrompt){ deferredPrompt.prompt(); await deferredPrompt.userChoice; deferredPrompt=null; }
    };
    el.querySelector('#sl_install_no').onclick = ()=> el.classList.remove('show');
  }
  if(el) el.classList.toggle('show', !!show && !!deferredPrompt);
}
function triggerInstall(){
  if(deferredPrompt){ deferredPrompt.prompt(); deferredPrompt.userChoice.then(()=>{deferredPrompt=null}) }
  else toast('Установка доступна через меню браузера · "Установить приложение"');
}

// Service worker
if('serviceWorker' in navigator){
  window.addEventListener('load', ()=>{ navigator.serviceWorker.register('./sw.js').catch(()=>{}) });
}

// New content notifications
async function checkNewContent(){
  try{
    const [books, audio, bio] = await Promise.all([
      fetch('data/books.json').then(r=>r.ok?r.json():[]).catch(()=>[]),
      fetch('data/audio.json').then(r=>r.ok?r.json():[]).catch(()=>[]),
      fetch('data/scholars.json').then(r=>r.ok?r.json():[]).catch(()=>[])
    ]);
    const counts = {books: books.length, audio: audio.length, bio: bio.length};
    const seen = JSON.parse(localStorage.getItem(SL.seen_counts) || '{}');
    const msgs = [];
    if(seen.books != null && counts.books > seen.books) msgs.push(`📚 Новых книг: ${counts.books - seen.books}`);
    if(seen.audio != null && counts.audio > seen.audio) msgs.push(`🎧 Новых аудио: ${counts.audio - seen.audio}`);
    if(seen.bio != null && counts.bio > seen.bio) msgs.push(`👤 Новых биографий: ${counts.bio - seen.bio}`);
    localStorage.setItem(SL.seen_counts, JSON.stringify(counts));
    if(msgs.length && seen.books != null){
      setTimeout(()=>toast(msgs.join(' · '), 4200), 1200);
    }
  }catch(e){}
}

// update fav count on load
document.addEventListener('DOMContentLoaded', ()=>{ updateFavCount(); checkNewContent(); });
