#!/usr/bin/env python3
"""
Import 116 PDFs from aminmod-bit/salaf-library /books
Classify, extract metadata, generate covers
Output: data/books.json, authors.json, etc.
"""
import json, os, re, sys
from pathlib import Path
import requests
from io import BytesIO

try:
    from pypdf import PdfReader
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    print("pip install pypdf pillow requests")
    sys.exit(1)

ROOT = Path(__file__).parent.parent
DATA = ROOT / "data"
BOOKS_DIR = ROOT / "books"
IMG_COVERS = ROOT / "images" / "covers"
for p in [DATA, BOOKS_DIR / "aqida", BOOKS_DIR / "hadith", BOOKS_DIR / "tafsir", BOOKS_DIR / "fiqh", BOOKS_DIR / "biography", BOOKS_DIR / "other", IMG_COVERS]:
    p.mkdir(parents=True, exist_ok=True)

# Get list from GitHub API
r = requests.get("https://api.github.com/repos/aminmod-bit/salaf-library/contents/books", headers={"User-Agent":"salaf"})
files = [x for x in r.json() if isinstance(x, dict) and x.get("name","").lower().endswith(".pdf")]
print(f"Found {len(files)} PDFs")

def slugify(s):
    s = re.sub(r"[^\w\s-]", "", s, flags=re.UNICODE)
    s = re.sub(r"[-\s]+", "-", s.strip())
    return s.lower()[:80]

def classify(filename, text_sample=""):
    f = (filename + " " + text_sample).lower()
    if any(k in f for k in ["акыд","таухид","иман","вероубежд","основа","усуль","васит","тахави","навакид","мессия","богом","убежден"]):
        return "aqida"
    if any(k in f for k in ["хадис","сунна","суннан","абу дауд","бухари","муслим","даджжал"]):
        return "hadith"
    if any(k in f for k in ["тафсир","коран","коране"]):
        return "tafsir"
    if any(k in f for k in ["фикх","пост","закят","хадж","умра","молитв","намаз","брак","этикет","нрав","адаб","дуа","азкар","поминани"]):
        return "fiqh"
    if any(k in f for k in ["биографи","ибн таймия","ибн каййим","жизн"]):
        return "biography"
    return "other"

def extract_author(filename):
    m = re.search(r"[—\-–,]\s*([А-ЯA-Z][^.]+\.pdf$)", filename)
    if m:
        return m.group(1).replace(".pdf","").strip()
    known = [
        "Ибн Таймия","Ибн аль-Каййим","Ибн Усеймин","Ибн Баз",
        "Мухаммад ибн Абдуль-Ваххаб","ан-Навави","аль-Альбани",
        "ас-Саади","аль-Мунаджид","аш-Шувейир","ар-Раджихи"
    ]
    fl = filename.lower()
    for a in known:
        if a.lower().split()[0] in fl or a.lower() in fl:
            return a
    return ""

def clean_title(filename):
    t = filename.replace(".pdf","").replace("_"," ")
    t = re.sub(r"\s*[—\-–]\s*[А-ЯA-Z].+$", "", t)
    t = re.sub(r"\s*,\s*[А-ЯA-Z][^,]+$", "", t)
    return t.strip()

books = []
authors_map = {}
aid_counter = 1

def get_author_id(name):
    global aid_counter
    if not name: return ""
    if name not in authors_map:
        slug = slugify(re.sub(r"[^\w]", "-", name))
        authors_map[name] = {"id": f"au-{aid_counter:03d}", "name": name, "slug": slug or f"author-{aid_counter}"}
        aid_counter += 1
    return authors_map[name]["id"]

for i, item in enumerate(files, 1):
    name = item["name"]
    url = item["download_url"]
    print(f"[{i}/{len(files)}] {name}", end=" ... ", flush=True)
    try:
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        pdf_bytes = resp.content
    except Exception as e:
        print(f"download fail {e}")
        continue
    
    try:
        reader = PdfReader(BytesIO(pdf_bytes))
        pages = len(reader.pages)
        meta = reader.metadata or {}
        title_meta = (meta.title or "").strip()
    except Exception:
        pages = 0
        title_meta = ""
    
    text_sample = ""
    try:
        if pages > 0:
            text_sample = (reader.pages[0].extract_text() or "")[:600]
    except Exception:
        pass

    cat = classify(name, text_sample)
    title = title_meta if title_meta and len(title_meta) > 3 else clean_title(name)
    author_name = extract_author(name)
    author_id = get_author_id(author_name)

    safe_name = re.sub(r'[<>:"/\\|?*]', "-", name)
    safe_name = re.sub(r"\s+", " ", safe_name).strip()
    out_cat_dir = BOOKS_DIR / cat
    out_cat_dir.mkdir(exist_ok=True, parents=True)
    out_pdf = out_cat_dir / safe_name
    if not out_pdf.exists():
        out_pdf.write_bytes(pdf_bytes)

    cover_id = f"BK{i:04d}"
    cover_path = IMG_COVERS / f"{cover_id}.webp"
    cover_made = False
    try:
        img = Image.new("RGB", (400, 560), (24, 85, 52))
        d = ImageDraw.Draw(img)
        font = ImageFont.load_default()
        words = title.split()
        lines=[]; cur=""
        for w in words:
            if len(cur+w) < 22: cur = (cur+" "+w).strip()
            else: lines.append(cur); cur=w
        if cur: lines.append(cur)
        y=120
        for ln in lines[:6]:
            d.text((30,y), ln[:28], fill=(240,230,210), font=font)
            y+=28
        if author_name:
            d.text((30, 440), author_name[:30], fill=(200,180,140), font=font)
        d.text((30, 510), "مكتبة السلف", fill=(200,170,100), font=font)
        img.save(cover_path, "WEBP", quality=82)
        cover_made = True
    except Exception as e:
        print(f" cover err {e}", end=" ")
    
    book_id = f"{cat[:2].upper()}{i:04d}"
    books.append({
        "id": book_id,
        "slug": slugify(title) or f"book-{i}",
        "title": title,
        "title_ar": "",
        "author_id": author_id,
        "author_name": author_name,
        "category": cat,
        "lang": "ru",
        "pages": pages,
        "year": "",
        "file": f"books/{cat}/{safe_name}",
        "cover": f"images/covers/{cover_id}.webp" if cover_made else "",
        "description": "",
        "tags": []
    })
    print(f"ok {cat} {pages}p")

(DATA / "books.json").write_text(json.dumps(books, ensure_ascii=False, indent=2), encoding="utf-8")
authors = sorted(authors_map.values(), key=lambda x: x["id"])
(DATA / "authors.json").write_text(json.dumps(authors, ensure_ascii=False, indent=2), encoding="utf-8")

for fn, default in [
    ("scholars.json", []),
    ("prophets.json", []),
    ("companions.json", []),
    ("tabiin.json", []),
    ("audio.json", []),
    ("fawaid.json", []),
]:
    p = DATA / fn
    if not p.exists():
        p.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")

cats = [
  {"id":"aqida","name":"Акыда","name_ar":"العقيدة","slug":"aqida","count": sum(1 for b in books if b["category"]=="aqida")},
  {"id":"hadith","name":"Хадис","name_ar":"الحديث","slug":"hadith","count": sum(1 for b in books if b["category"]=="hadith")},
  {"id":"tafsir","name":"Тафсир","name_ar":"التفسير","slug":"tafsir","count": sum(1 for b in books if b["category"]=="tafsir")},
  {"id":"fiqh","name":"Фикх","name_ar":"الفقه","slug":"fiqh","count": sum(1 for b in books if b["category"]=="fiqh")},
  {"id":"biography","name":"Биографии","name_ar":"السير","slug":"biography","count": sum(1 for b in books if b["category"]=="biography")},
  {"id":"other","name":"Разное","name_ar":"متفرقات","slug":"other","count": sum(1 for b in books if b["category"]=="other")},
]
(DATA / "categories.json").write_text(json.dumps(cats, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"\nDone. Books: {len(books)}, Authors: {len(authors)}")
print("Categories:", ", ".join([f"{c['id']}:{c['count']}" for c in cats]))
