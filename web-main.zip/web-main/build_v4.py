#!/usr/bin/env python3
"""
Salaf Library v4 – full import from GitHub aminmod-bit/salaf-library
Builds per-book folders:
  library/BK0001/
    original.pdf
    book.pdf
    cover.webp
    thumb.webp
    metadata.json

Also builds:
  data/books.json
  data/authors.json
  data/scholars.json / prophets.json / companions.json / tabiin.json
  data/categories.json
  data/search-index.json
  data/fawaid/index.json + data/fawaid/FW*.json
  data/audio.json
"""
import json, re, os
from pathlib import Path
import requests
from io import BytesIO
try:
    from pypdf import PdfReader
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    print("pip install pypdf pillow requests"); raise SystemExit(1)

ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT / "library"
DATA = ROOT / "data"
FAWAID_DIR = DATA / "fawaid"
AUDIO_ROOT = ROOT / "audio"
IMG_OG = ROOT / "images" / "og"

for p in [LIB, DATA, FAWAID_DIR, AUDIO_ROOT,
          ROOT/"images"/"covers", ROOT/"images"/"authors",
          IMG_OG]:
    p.mkdir(parents=True, exist_ok=True)

# --- fetch PDF list from GitHub ---
r = requests.get("https://api.github.com/repos/aminmod-bit/salaf-library/contents/books", headers={"User-Agent":"salaf"}, timeout=20)
files = [x for x in r.json() if isinstance(x, dict) and x.get("name","").lower().endswith(".pdf")]
print(f"GitHub PDFs: {len(files)}")

def slugify(s):
    s = re.sub(r"[^\w\s-]", "", s, flags=re.UNICODE)
    s = re.sub(r"[-\s]+", "-", s.strip().lower())
    return s[:90] or "n-a"

def classify(filename, text=""):
    f=(filename+" "+text).lower()
    if any(k in f for k in ["акыд","таухид","иман","вероубежд","основа","усуль","васит","тахави","навакид","мессия","богом","убежден"]): return "aqida"
    if any(k in f for k in ["хадис","сунна","суннан","абу дауд","бухари","муслим","даджжал"]): return "hadith"
    if any(k in f for k in ["тафсир","коран"]): return "tafsir"
    if any(k in f for k in ["фикх","пост","закят","хадж","умра","молитв","намаз","брак","этикет","нрав","адаб","дуа","азкар","поминани","внешн","справления"]): return "fiqh"
    if any(k in f for k in ["биографи","ибн таймия","ибн каййим"]): return "biography"
    return "other"

KNOWN_AUTHORS = {
    "ибн таймия": "Шейхуль-Ислам Ибн Таймия",
    "ибн аль-каййим": "Ибн аль-Каййим",
    "ибн каййим": "Ибн аль-Каййим",
    "ибн усеймин": "Шейх Ибн Усеймин",
    "усеймин": "Шейх Ибн Усеймин",
    "ибн баз": "Шейх Ибн Баз",
    "аль-альбани": "Шейх аль-Альбани",
    "альбани": "Шейх аль-Альбани",
    "ан-навави": "Имам ан-Навави",
    "ас-саади": "Шейх ас-Саади",
    "аль-мунаджид": "Шейх аль-Мунаджид",
    "аш-шувейир": "Шейх аш-Шувейир",
    "ар-раджихи": "Шейх ар-Раджихи",
    "аль-каннас": "аль-Каннас",
    "абдуль-мухсин": "Абдуль-Мухсин аль-Касим",
}
def extract_author(filename):
    m=re.search(r"[—–\-]\s*([^.\\/\\\n]{3,60})\.pdf$", filename)
    if m:
        name=m.group(1).strip()
        if 2 < len(name) < 70 and not re.search(r'\d', name):
            return name
    m2=re.search(r",\s*([А-ЯA-ZЁ][^,]{2,60})\.pdf$", filename)
    if m2:
        name=m2.group(1).strip()
        if len(name) < 70: return name
    fl=filename.lower()
    for key,val in KNOWN_AUTHORS.items():
        if key in fl: return val
    return ""

def clean_title(filename):
    t=filename.replace(".pdf","").replace("_"," ")
    t=re.sub(r"\s*[—–\-]\s*[А-ЯA-ZЁ][^—–\-]{2,80}$", "", t)
    t=re.sub(r",\s*[А-ЯA-ZЁ][^,]{2,60}$", "", t)
    return t.strip()

books=[]
authors_map={}
aid_counter=1
def get_author_id(name):
    global aid_counter
    if not name: return ""
    if name not in authors_map:
        slug = slugify(name)
        authors_map[name] = {"id": f"au-{aid_counter:03d}", "name": name, "slug": slug or f"author-{aid_counter}",
            "name_ar":"", "birth":"", "death":"", "bio_short":"", "bio_full":"", "photo":"", "tags":[], "links":{}}
        aid_counter+=1
    return authors_map[name]["id"]

# font for covers
try:
    FONT_B = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 20)
    FONT_S = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
except:
    FONT_B = ImageFont.load_default(); FONT_S = FONT_B

def make_cover(title, author, out_webp):
    img=Image.new("RGB",(600,840),(18,68,44))
    d=ImageDraw.Draw(img)
    # wrap title
    words=title.split(); lines=[]; cur=""
    for w in words:
        if len(cur+w) < 26: cur=(cur+" "+w).strip()
        else: lines.append(cur); cur=w
    if cur: lines.append(cur)
    y=140
    for ln in lines[:7]:
        d.text((32,y), ln, fill=(235,222,195), font=FONT_B); y+=30
    if author:
        d.text((32, 700), author[:40], fill=(195,170,130), font=FONT_S)
    d.text((32, 780), "مكتبة السلف", fill=(190,155,95), font=FONT_S)
    img.save(out_webp,"WEBP", quality=84)
    # thumb
    tw=300; th=int(840*tw/600)
    im2 = img.resize((tw,th), Image.LANCZOS)
    im2.save(out_webp.parent / "thumb.webp", "WEBP", quality=80)

for i, item in enumerate(files, 1):
    name = item["name"]; url = item["download_url"]
    print(f"[{i}/{len(files)}] {name}", end=" ... ", flush=True)
    try:
        pdf_bytes = requests.get(url, timeout=30).content
    except Exception as e:
        print("dl fail", e); continue
    try:
        reader = PdfReader(BytesIO(pdf_bytes)); pages = len(reader.pages)
        meta = reader.metadata or {}; title_meta = (meta.title or "").strip()
    except: pages=0; title_meta=""
    text_sample=""
    try:
        if pages>0: text_sample = (reader.pages[0].extract_text() or "")[:600]
    except: pass
    cat = classify(name, text_sample)
    title = clean_title(name)
    # use pdf title only if it looks clean
    if title_meta and len(title_meta)>3:
        bad = title_meta.count('Ð') + title_meta.count('Ñ') + title_meta.count('�')
        if bad < len(title_meta)*0.1:
            title = title_meta
    author_name = extract_author(name)
    author_id = get_author_id(author_name)
    book_id = f"BK{i:04d}"
    book_dir = LIB / book_id
    book_dir.mkdir(parents=True, exist_ok=True)
    (book_dir / "original.pdf").write_bytes(pdf_bytes)
    (book_dir / "book.pdf").write_bytes(pdf_bytes)
    make_cover(title, author_name, book_dir / "cover.webp")
    meta_obj = {
        "id": book_id,
        "slug": slugify(title) or f"book-{i}",
        "title": title,
        "title_ar": "",
        "author_id": author_id,
        "author_name": author_name,
        "category": cat,
        "lang": "ru",
        "pages": pages,
        "year": "",
        "description": "",
        "tags": [],
        "file": f"library/{book_id}/book.pdf",
        "cover": f"library/{book_id}/cover.webp",
        "thumb": f"library/{book_id}/thumb.webp",
        "original_name": name,
        "created_at": "2026-06-19",
        "updated_at": "2026-06-19"
    }
    (book_dir / "metadata.json").write_text(json.dumps(meta_obj, ensure_ascii=False, indent=2), encoding="utf-8")
    books.append({k: meta_obj[k] for k in ["id","slug","title","title_ar","author_id","author_name","category","lang","pages","year","file","cover","thumb","description","tags"]})
    print(f"ok {cat} {pages}p")

print(f"\nBooks: {len(books)}")

# --- authors enrich ---
predef_scholars = [
  {"name":"Шейхуль-Ислам Ибн Таймия","name_ar":"ابن تيمية","birth":"661","death":"728","bio_short":"Шейхуль-Ислам, имам ахлю-сунна.","tags":["aqida","fiqh"]},
  {"name":"Ибн аль-Каййим","name_ar":"ابن القيم","birth":"691","death":"751","bio_short":"Ученик Ибн Таймии, имам.","tags":["aqida","tazkiya"]},
  {"name":"Имам ан-Навави","name_ar":"النووي","birth":"631","death":"676","bio_short":"Имам-хадисовед, шафиит.","tags":["hadith","fiqh"]},
  {"name":"Имам аль-Бухари","name_ar":"البخاري","birth":"194","death":"256","bio_short":"Автор «Сахих аль-Бухари».","tags":["hadith"]},
  {"name":"Имам Муслим","name_ar":"مسلم","birth":"206","death":"261","bio_short":"Автор «Сахих Муслим».","tags":["hadith"]},
  {"name":"Имам Ахмад ибн Ханбаль","name_ar":"أحمد بن حنبل","birth":"164","death":"241","bio_short":"Имам ахлю-сунна.","tags":["aqida","hadith","fiqh"]},
  {"name":"Шейх Ибн Баз","name_ar":"ابن باز","birth":"1330","death":"1420","bio_short":"Муфтий Саудовской Аравии.","tags":["aqida","fiqh"]},
  {"name":"Шейх Ибн Усеймин","name_ar":"ابن عثيمين","birth":"1347","death":"1421","bio_short":"Выдающийся учёный КСА.","tags":["aqida","fiqh"]},
  {"name":"Шейх аль-Альбани","name_ar":"الألباني","birth":"1333","death":"1420","bio_short":"Мухаддис 20 века.","tags":["hadith"]},
  {"name":"Шейх Салих аль-Фаузан","name_ar":"الفوزان","birth":"1354","death":"","bio_short":"Член Комитета старейших учёных КСА.","tags":["aqida"]},
  {"name":"Шейх ас-Саади","name_ar":"السعدي","birth":"1307","death":"1376","bio_short":"Муфассир.","tags":["tafsir"]},
  {"name":"Шейх ар-Раджихи","name_ar":"الراجحي","bio_short":"","tags":[]},
  {"name":"Шейх аль-Мунаджид","name_ar":"المنجد","bio_short":"","tags":[]},
  {"name":"Шейх аш-Шувейир","name_ar":"الشويعر","bio_short":"","tags":[]},
]
for s in predef_scholars:
    n = s["name"]
    if n in authors_map:
        for k,v in s.items():
            if v: authors_map[n][k] = v
    else:
        get_author_id(n)
        authors_map[n].update(s)

authors_list = sorted(authors_map.values(), key=lambda x: x["id"])
# add related_books field
author_books = {}
for b in books:
    if b["author_id"]:
        author_books.setdefault(b["author_id"], []).append(b["id"])
for a in authors_list:
    a["related_books"] = author_books.get(a["id"], [])
    a.setdefault("bio_full","")
    a.setdefault("links",{})

# scholars list (authors with bio)
scholars = []
for a in authors_list:
    if a.get("bio_short") or a.get("birth"):
        scholars.append({
            "id": a["id"], "name": a["name"], "name_ar": a.get("name_ar",""),
            "slug": a["slug"], "birth": a.get("birth",""), "death": a.get("death",""),
            "bio_short": a.get("bio_short",""), "bio_full": a.get("bio_full",""),
            "photo": a.get("photo",""), "tags": a.get("tags",[]),
            "related_books": a.get("related_books",[]),
            "related_audio": [], "related_fawaid": [], "related_authors": []
        })

# prophets / companions / tabiin
def mk_bio_list(names, prefix):
    out=[]
    for idx, n in enumerate(names,1):
        slug = slugify(n)
        out.append({
            "id": f"{prefix}-{idx:03d}",
            "slug": slug,
            "name": f"{n} ﷺ" if prefix=="pr" else n,
            "name_ar": "",
            "birth": "", "death": "",
            "bio_short": "", "bio_full": "",
            "photo": "",
            "tags": [],
            "related_books": [],
            "related_audio": [],
            "related_fawaid": [],
            "related_authors": []
        })
    return out

prophet_names = ["Адам","Идрис","Нух","Худ","Салих","Ибрахим","Лут","Исмаил","Исхак","Якуб","Юсуф","Айюб","Шуайб","Муса","Харун","Давуд","Сулейман","Ильяс","Аль-Яса","Юнус","Закария","Яхья","Иса","Мухаммад"]
companions_names = ["Абу Бакр ас-Сиддик","Умар ибн аль-Хаттаб","Усман ибн Аффан","Али ибн Абу Талиб","Тальха ибн Убайдуллах","аз-Зубайр ибн аль-Аввам","Абдуррахман ибн Ауф","Са'д ибн Абу Ваккас","Са'ид ибн Зайд","Абу Убайда ибн аль-Джаррах"]
tabiin_names = ["Са'ид ибн аль-Мусаййиб","Урва ибн аз-Зубайр","аль-Хасан аль-Басри","Мухаммад ибн Сирин","Ибрахим ан-Наха'и","Амир аш-Ша'би","Ата ибн Абу Рабах","Таус ибн Кайсан","Муджахид ибн Джабр","Макхуль ад-Димашки"]

prophets = mk_bio_list(prophet_names, "pr")
companions = mk_bio_list(companions_names, "co")
tabiin = mk_bio_list(tabiin_names, "tb")

# categories
from collections import Counter
cat_counts = Counter(b["category"] for b in books)
categories = [
  {"id":"aqida","name":"Акыда","name_ar":"العقيدة","slug":"aqida","count":cat_counts.get("aqida",0)},
  {"id":"hadith","name":"Хадис","name_ar":"الحديث","slug":"hadith","count":cat_counts.get("hadith",0)},
  {"id":"tafsir","name":"Тафсир","name_ar":"التفسير","slug":"tafsir","count":cat_counts.get("tafsir",0)},
  {"id":"fiqh","name":"Фикх","name_ar":"الفقه","slug":"fiqh","count":cat_counts.get("fiqh",0)},
  {"id":"biography","name":"Биографии","name_ar":"السير","slug":"biography","count":cat_counts.get("biography",0)},
  {"id":"other","name":"Разное","name_ar":"متفرقات","slug":"other","count":cat_counts.get("other",0)},
]

# fawaid - sharded
fawaid_samples = [
  {"text": "Знание — это не заучивание множества текстов, а свет, который Аллах помещает в сердце.", "author_id":"", "source":"", "tags":["знание"]},
  {"text": "Терпение — это когда сердце не чувствует гнева против предопределённого.", "author_id":"", "source":"", "tags":["терпение"]},
  {"text": "Искренность — забыть о взорах творений, помня постоянно о взоре Творца.", "author_id":"", "source":"", "tags":["ихляс"]},
]
fawaid_index=[]
for idx, fw in enumerate(fawaid_samples, 1):
    fid = f"FW{idx:06d}"
    obj = {"id": fid, **fw, "created_at":"2026-06-19"}
    (FAWAID_DIR / f"{fid}.json").write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    fawaid_index.append({"id":fid, "tags":fw["tags"], "author_id": fw.get("author_id","")})

# audio catalog - empty stub
audio_catalog = []

# search-index
search_index=[]
for b in books:
    search_index.append({
        "id": b["id"], "type":"book",
        "title": b["title"], "title_ar": b.get("title_ar",""),
        "author": b.get("author_name",""), "author_id": b.get("author_id",""),
        "category": b["category"], "tags": b.get("tags",[]),
        "description": b.get("description",""), "lang": b.get("lang","ru"),
        "url": f"book.html?id={b['id']}"
    })
for a in authors_list:
    search_index.append({
        "id": a["id"], "type":"author",
        "title": a["name"], "title_ar": a.get("name_ar",""),
        "author":"", "author_id": a["id"],
        "category":"authors", "tags": a.get("tags",[]),
        "description": a.get("bio_short",""), "lang":"ru",
        "url": f"bio.html?type=author&slug={a['slug']}"
    })
for lst, tname in [(scholars,"scholar"),(prophets,"prophet"),(companions,"companion"),(tabiin,"tabiin")]:
    for p in lst:
        search_index.append({
            "id": p["id"], "type": tname,
            "title": p["name"], "title_ar": p.get("name_ar",""),
            "author":"", "author_id":"",
            "category": tname+"s", "tags": p.get("tags",[]),
            "description": p.get("bio_short",""), "lang":"ru",
            "url": f"bio.html?type={tname}s&slug={p['slug']}"
        })

# write JSONs
(DATA / "books.json").write_text(json.dumps(books, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA / "authors.json").write_text(json.dumps(authors_list, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA / "scholars.json").write_text(json.dumps(scholars, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA / "prophets.json").write_text(json.dumps(prophets, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA / "companions.json").write_text(json.dumps(companions, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA / "tabiin.json").write_text(json.dumps(tabiin, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA / "categories.json").write_text(json.dumps(categories, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA / "audio.json").write_text(json.dumps(audio_catalog, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA / "fawaid" / "index.json").write_text(json.dumps(fawaid_index, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA / "search-index.json").write_text(json.dumps(search_index, ensure_ascii=False), encoding="utf-8")

print(f"\nV4 build done.")
print(f" books: {len(books)}")
print(f" authors: {len(authors_list)} / scholars: {len(scholars)}")
print(f" prophets: {len(prophets)}, companions: {len(companions)}, tabiin: {len(tabiin)}")
print(f" fawaid: {len(fawaid_index)}")
print(f" search-index entries: {len(search_index)}")
print(f" categories: {', '.join([c['id']+':'+str(c['count']) for c in categories])}")
