// Salaf Library — Service Worker (PWA / offline)
const CACHE = 'salaf-v4-20260619';
const CORE = [
  './','./index.html','./book.html','./bio.html',
  './audio.html','./fawaid.html','./favorites.html','./history.html',
  './assets/app.css','./assets/app.js',
  './data/books.json','./data/authors.json','./data/categories.json','./data/search-index.json',
  './manifest.json'
];
self.addEventListener('install', e=>{
  e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate', e=>{
  e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch', e=>{
  const url = new URL(e.request.url);
  if(url.origin === location.origin){
    e.respondWith(
      caches.match(e.request).then(cached=>{
        const fetchP = fetch(e.request).then(res=>{
          if(res.ok){ const copy=res.clone(); caches.open(CACHE).then(c=>c.put(e.request, copy)) }
          return res;
        }).catch(()=>cached);
        return cached || fetchP;
      })
    );
  }
});
