#!/usr/bin/env python3
"""
Migrate Salaf Library v3 -> v4
v4 structure:
  library/BK0001/
    original.pdf
    book.pdf          (optimized / same)
    cover.webp        (600x840)
    thumb.webp        (300px width)
    metadata.json
  data/
    books.json
    authors.json
    scholars.json
    prophets.json
    companions.json
    tabiin.json
    audio.json
    categories.json
    fawaid/index.json
    fawaid/FW000001.json ...
    search-index.json
  audio/AU000001/
    audio.mp3
    cover.webp
    metadata.json
"""
import json, shutil, re
from pathlib import Path
try:
    from PIL import Image
except ImportError:
    print("pip install pillow"); raise

V3 = Path("/home/user/salaf-library-v3")
V4 = Path(__file__).resolve().parents[1]

LIB = V4 / "library"
DATA = V4 / "data"
FAWAID_DIR = DATA / "fawaid"
AUDIO_DIR = V4 / "audio"

for p in [LIB, DATA, FAWAID_DIR, AUDIO_DIR, V4/"images"/"og"]:
    p.mkdir(parents=True, exist_ok=True)

# Load v3
V3 = Path("/home/user/salaf-library-v3")
def load_json(rel): 
    f = V3 / rel
    return json.loads(f.read_text(encoding="utf-8")) if f.exists() else []

books_v3 = load_json("data/books.json")
authors_v3 = load_json("data/authors.json")
scholars_v3 = load_json("data/scholars.json")
prophets_v3 = load_json("data/prophets.json")
companions_v3 = load_json("data/companions.json")
tabiin_v3 = load_json("data/tabiin.json")

# copy function for covers with thumb generation
def process_cover(src_rel, dst_dir):
    src = V3 / src_rel if src_rel else None
    if src and src.exists():
        dst_cover = dst_dir / "cover.webp"
        shutil.copy2(src, dst_cover)
        # thumb
        try:
            im = Image.open(dst_cover)
            w,h = im.size
            tw = 300
            th = int(h * tw / w)
            im2 = im.resize((tw, th), Image.LANCZOS)
            im2.save(dst_dir / "thumb.webp", "WEBP", quality=80)
        except Exception as e:
            print("  thumb fail", e)
        return True
    return False

new_books = []
id_map = {}  # old_id -> new_id (BK0001...)

for i, b in enumerate(books_v3, 1):
    new_id = f"BK{i:04d}"
    id_map[b["id"]] = new_id
    book_dir = LIB / new_id
    book_dir.mkdir(parents=True, exist_ok=True)
    
    # PDF
    src_pdf = V3 / b.get("file","")
    if src_pdf.exists():
        shutil.copy2(src_pdf, book_dir / "original.pdf")
        shutil.copy2(src_pdf, book_dir / "book.pdf")
        file_rel = f"library/{new_id}/book.pdf"
    else:
        file_rel = b.get("file","")
    
    # cover
    has_cover = process_cover(b.get("cover",""), book_dir)
    cover_rel = f"library/{new_id}/cover.webp" if has_cover else ""
    thumb_rel = f"library/{new_id}/thumb.webp" if has_cover else ""
    
    # metadata.json per book
    meta = {
        "id": new_id,
        "legacy_id": b.get("id"),
        "slug": b.get("slug",""),
        "title": b.get("title",""),
        "title_ar": b.get("title_ar",""),
        "author_id": b.get("author_id",""),
        "author_name": b.get("author_name",""),
        "category": b.get("category","other"),
        "lang": b.get("lang","ru"),
        "pages": b.get("pages",0),
        "year": b.get("year",""),
        "description": b.get("description",""),
        "tags": b.get("tags",[]),
        "file": file_rel,
        "cover": cover_rel,
        "thumb": thumb_rel,
        "created_at": "2026-06-19",
        "updated_at": "2026-06-19"
    }
    (book_dir / "metadata.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    
    new_books.append({
        "id": new_id,
        "slug": meta["slug"],
        "title": meta["title"],
        "title_ar": meta["title_ar"],
        "author_id": meta["author_id"],
        "author_name": meta["author_name"],
        "category": meta["category"],
        "lang": meta["lang"],
        "pages": meta["pages"],
        "year": meta["year"],
        "file": file_rel,
        "cover": cover_rel,
        "thumb": thumb_rel,
        "description": meta["description"],
        "tags": meta["tags"]
    })
    if i % 20 == 0:
        print(f"{i}/{len(books_v3)}")

print(f"Books migrated: {len(new_books)}")

# authors - enrich for bio relations
authors = []
for a in authors_v3:
    authors.append({
        "id": a["id"],
        "slug": a.get("slug",""),
        "name": a["name"],
        "name_ar": a.get("name_ar",""),
        "birth": a.get("birth",""),
        "death": a.get("death",""),
        "bio_short": a.get("bio_short",""),
        "bio_full": a.get("bio_full",""),
        "photo": a.get("photo",""),
        "tags": a.get("tags",[]),
        "links": a.get("links", {})
    })

# scholars / prophets / companions / tabiin - add relation fields
def enrich_bio_list(lst, kind):
    out=[]
    for p in lst:
        out.append({
            "id": p["id"],
            "slug": p.get("slug",""),
            "name": p["name"],
            "name_ar": p.get("name_ar",""),
            "birth": p.get("birth",""),
            "death": p.get("death",""),
            "bio_short": p.get("bio_short",""),
            "bio_full": p.get("bio_full",""),
            "photo": p.get("photo",""),
            "tags": p.get("tags",[]),
            "related_books": [],   # filled later
            "related_audio": [],
            "related_fawaid": [],
            "related_authors": []
        })
    return out

scholars = enrich_bio_list(scholars_v3, "scholars")
prophets = enrich_bio_list(prophets_v3, "prophets")
companions = enrich_bio_list(companions_v3, "companions")
tabiin = enrich_bio_list(tabiin_v3, "tabiin")

# link books to scholars/authors by author_id
author_books = {}
for b in new_books:
    if b["author_id"]:
        author_books.setdefault(b["author_id"], []).append(b["id"])

for s in scholars:
    s["related_books"] = author_books.get(s["id"], [])
for a in authors:
    # if author is also a scholar, copy related_books
    sc = next((x for x in scholars if x["id"]==a["id"]), None)
    if sc:
        a["related_books"] = sc["related_books"]
    else:
        a["related_books"] = author_books.get(a["id"], [])

# categories
from collections import Counter
cat_counts = Counter(b["category"] for b in new_books)
categories = [
    {"id":"aqida","name":"Акыда","name_ar":"العقيدة","slug":"aqida","count":cat_counts.get("aqida",0)},
    {"id":"hadith","name":"Хадис","name_ar":"الحديث","slug":"hadith","count":cat_counts.get("hadith",0)},
    {"id":"tafsir","name":"Тафсир","name_ar":"التفسير","slug":"tafsir","count":cat_counts.get("tafsir",0)},
    {"id":"fiqh","name":"Фикх","name_ar":"الفقه","slug":"fiqh","count":cat_counts.get("fiqh",0)},
    {"id":"biography","name":"Биографии","name_ar":"السير","slug":"biography","count":cat_counts.get("biography",0)},
    {"id":"other","name":"Разное","name_ar":"متفرقات","slug":"other","count":cat_counts.get("other",0)},
]

# fawaid - create sharded structure, with sample entries
fawaid_index = []
sample_fawaid = [
  {"text": "Знание — это не заучивание множества текстов, а свет, который Аллах помещает в сердце.", "author_id":"au-004", "source":"", "tags":["знание"]},
  {"text": "Терпение — это когда сердце не чувствует гнева против предопределённого.", "author_id":"", "source":"", "tags":["терпение"]},
  {"text": "Искренность — забыть о взорах творений, помня постоянно о взоре Творца.", "author_id":"", "source":"", "tags":["ихляс"]},
]
FAWAID_DIR.mkdir(parents=True, exist_ok=True)
for idx, fw in enumerate(sample_fawaid, 1):
    fid = f"FW{idx:06d}"
    obj = {"id":fid, **fw, "created_at":"2026-06-19"}
    (FAWAID_DIR / f"{fid}.json").write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    fawaid_index.append({"id":fid, "tags": fw["tags"], "author_id": fw.get("author_id","")})

(DATA / "fawaid" / "index.json").write_text(json.dumps(fawaid_index, ensure_ascii=False, indent=2), encoding="utf-8")

# audio - create stub catalog
audio_catalog = []
(DATA / "audio.json").write_text(json.dumps(audio_catalog, ensure_ascii=False, indent=2), encoding="utf-8")

# write main JSONs
(DATA / "books.json").write_text(json.dumps(new_books, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA / "authors.json").write_text(json.dumps(authors, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA / "scholars.json").write_text(json.dumps(scholars, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA / "prophets.json").write_text(json.dumps(prophets, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA / "companions.json").write_text(json.dumps(companions, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA / "tabiin.json").write_text(json.dumps(tabiin, ensure_ascii=False, indent=2), encoding="utf-8")
(DATA / "categories.json").write_text(json.dumps(categories, ensure_ascii=False, indent=2), encoding="utf-8")

# search-index.json
search_index = []
for b in new_books:
    search_index.append({
        "id": b["id"],
        "type": "book",
        "title": b["title"],
        "title_ar": b.get("title_ar",""),
        "author": b.get("author_name",""),
        "author_id": b.get("author_id",""),
        "category": b["category"],
        "tags": b.get("tags",[]),
        "description": b.get("description",""),
        "lang": b.get("lang","ru"),
        "url": f"book.html?id={b['id']}"
    })
for a in authors:
    search_index.append({
        "id": a["id"], "type":"author",
        "title": a["name"], "title_ar": a.get("name_ar",""),
        "author": "", "author_id": a["id"],
        "category": "authors",
        "tags": a.get("tags",[]),
        "description": a.get("bio_short",""),
        "lang": "ru",
        "url": f"bio.html?type=author&slug={a['slug']}"
    })
for lst, tname in [(scholars,"scholar"),(prophets,"prophet"),(companions,"companion"),(tabiin,"tabiin")]:
    for p in lst:
        search_index.append({
            "id": p["id"], "type": tname,
            "title": p["name"], "title_ar": p.get("name_ar",""),
            "author":"", "author_id":"",
            "category": tname+"s",
            "tags": p.get("tags",[]),
            "description": p.get("bio_short",""),
            "lang":"ru",
            "url": f"bio.html?type={tname}s&slug={p['slug']}"
        })

(DATA / "search-index.json").write_text(json.dumps(search_index, ensure_ascii=False), encoding="utf-8")

print(f"Search index: {len(search_index)} entries")
print("Done v4 migration.")
print(f"  books: {len(new_books)}")
print(f"  authors: {len(authors)}")
print(f"  scholars: {len(scholars)}, prophets: {len(prophets)}, companions: {len(companions)}, tabiin: {len(tabiin)}")
print(f"  fawaid: {len(fawaid_index)}")
