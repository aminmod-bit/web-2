#!/usr/bin/env python3
"""
Salaf Library - Telegraph importer
Парсит 5 страниц Telegraph и обновляет books.json,
добавляя найденные ссылки PDF/Читать/Аудио.

Использование:
  pip install requests beautifulsoup4
  python tools/telegraph_import.py

Он не затирает уже заполненные ссылки в books.json.
"""
import json, re
from pathlib import Path
import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).parent.parent
BOOKS_FILE = ROOT / "books.json"

PAGES = {
    "aqida": "https://telegra.ph/Akyda-06-19",
    "hadith": "https://telegra.ph/Hadis-06-19",
    "tafsir": "https://telegra.ph/Tafsir-06-19",
    "bio": "https://telegra.ph/Biografii-06-19",
    "audio": "https://telegra.ph/Audio-06-19-3",
}

def fetch_page(url):
    r = requests.get(url, timeout=15)
    r.raise_for_status()
    return BeautifulSoup(r.text, "html.parser")

def norm(s): 
    return re.sub(r'\s+',' ', s or '').strip().lower()

def find_book(books, title):
    nt = norm(title)
    for b in books:
        if norm(b["title"]) in nt or nt in norm(b["title"]):
            return b
    # fuzzy: по первым 3 словам
    words = nt.split()[:3]
    if words:
        for b in books:
            if all(w in norm(b["title"]) for w in words):
                return b
    return None

def parse_telegraph(cat, url, books):
    print(f"\n== {cat} : {url}")
    soup = fetch_page(url)
    # Все ссылки на странице
    links = soup.find_all("a", href=True)
    found = 0
    # Telegraph страницы Salaf Library обычно имеют структуру:
    # <h3>Название книги</h3> ... <a>Читать онлайн</a> <a>Скачать PDF</a> <a>Слушать аудио</a>
    # Мы просто ищем заголовки h3/h4/strong и ближайшие ссылки
    for header in soup.find_all(["h3","h4","strong","p"]):
        text = header.get_text(" ", strip=True)
        if len(text) < 3 or len(text) > 120: continue
        # пропускаем служебные
        if "вернуться" in text.lower() or "salaf library" in text.lower():
            continue
        book = find_book(books, text)
        if not book: continue
        # ищем ссылки рядом с этим заголовком
        container = header.find_parent()
        next_tags = []
        n = header.find_next_sibling()
        for _ in range(5):
            if not n: break
            next_tags.append(n)
            n = n.find_next_sibling()
        search_area = " ".join([str(t) for t in [container]+next_tags])
        area_soup = BeautifulSoup(search_area, "html.parser")
        for a in area_soup.find_all("a", href=True):
            href = a["href"]
            atxt = a.get_text().lower()
            if "читать" in atxt and not book.get("read"):
                book["read"] = href; found+=1
            elif "pdf" in atxt or "скачать" in atxt:
                if not book.get("pdf"):
                    book["pdf"] = href; found+=1
            elif "слушать" in atxt or "аудио" in atxt:
                if not book.get("audio"):
                    book["audio"] = href; found+=1
    print(f"  найдено/обновлено ссылок: {found}")
    return found

def main():
    with open(BOOKS_FILE, encoding="utf-8") as f:
        books = json.load(f)
    total = 0
    for cat, url in PAGES.items():
        try:
            total += parse_telegraph(cat, url, books)
        except Exception as e:
            print(f"  Ошибка {cat}: {e}")
    with open(BOOKS_FILE, "w", encoding="utf-8") as f:
        json.dump(books, f, ensure_ascii=False, indent=2)
    print(f"\nГотово. Обновлено ссылок: {total}")
    print(f"Файл: {BOOKS_FILE}")

if __name__ == "__main__":
    main()
