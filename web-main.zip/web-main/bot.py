#!/usr/bin/env python3
"""
Salaf Library Telegram Bot
Поиск по тому же books.json что и сайт.

Установка:
  pip install python-telegram-bot==21.0

Запуск:
  export BOT_TOKEN="1234:ABC..."
  python bot.py

Бесплатный хостинг: Render.com / Railway.app / Fly.io
"""
import json
import os
from pathlib import Path
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

# Загружаем каталог
BOOKS_PATH = Path(__file__).parent.parent / "books.json"
with open(BOOKS_PATH, encoding="utf-8") as f:
    BOOKS = json.load(f)

CAT_NAMES = {
    "aqida": "Акыда",
    "hadith": "Хадис",
    "tafsir": "Тафсир",
    "bio": "Биография",
    "audio": "Аудио",
}

def search_books(query: str, cat=None, limit=10):
    q = query.lower().strip()
    results = []
    for b in BOOKS:
        if cat and b["cat"] != cat:
            continue
        hay = " ".join([b.get("title",""), b.get("author",""), b.get("ar",""), b.get("section","")]).lower()
        if not q or q in hay:
            results.append(b)
        if len(results) >= limit*3:  # запас
            break
    return results[:limit]

def format_book(b):
    lines = [f"📖 <b>{b['title']}</b>"]
    if b.get("ar"):
        lines.append(f"<i>{b['ar']}</i>")
    if b.get("author"):
        lines.append(f"👤 {b['author']}")
    links = []
    if b.get("read"): links.append(f'<a href="{b["read"]}">Читать</a>')
    if b.get("pdf"): links.append(f'<a href="{b["pdf"]}">PDF</a>')
    if b.get("audio"): links.append(f'<a href="{b["audio"]}">🎧 Аудио</a>')
    if links:
        lines.append(" | ".join(links))
    return "\n".join(lines)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    kb = [
        [InlineKeyboardButton("Акыда", callback_data="cat:aqida"),
         InlineKeyboardButton("Хадис", callback_data="cat:hadith")],
        [InlineKeyboardButton("Тафсир", callback_data="cat:tafsir"),
         InlineKeyboardButton("Биографии", callback_data="cat:bio")],
        [InlineKeyboardButton("🎧 Аудио", callback_data="cat:audio")],
    ]
    await update.message.reply_html(
        "مكتبة السلف\n\n<b>Salaf Library</b>\n\n"
        "Напишите название книги, автора, или выберите раздел.\n\n"
        f"Всего в библиотеке: {len(BOOKS)} книг.",
        reply_markup=InlineKeyboardMarkup(kb)
    )

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.message.text.strip()
    results = search_books(q, limit=8)
    if not results:
        await update.message.reply_text("Ничего не найдено. Попробуйте другой запрос.")
        return
    for b in results[:5]:
        kb_buttons = []
        if b.get("read"): kb_buttons.append([InlineKeyboardButton("📖 Читать", url=b["read"])])
        if b.get("pdf"): kb_buttons.append([InlineKeyboardButton("⬇ PDF", url=b["pdf"])])
        if b.get("audio"): kb_buttons.append([InlineKeyboardButton("🎧 Слушать", url=b["audio"])])
        await update.message.reply_html(
            format_book(b),
            reply_markup=InlineKeyboardMarkup(kb_buttons) if kb_buttons else None,
            disable_web_page_preview=True
        )
    if len(results) > 5:
        await update.message.reply_text(f"Найдено ещё {len(results)-5}. Уточните запрос.")

async def cat_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    cat = query.data.split(":",1)[1]
    results = search_books("", cat=cat, limit=12)
    text = f"<b>{CAT_NAMES.get(cat, cat)}</b> — {len([b for b in BOOKS if b['cat']==cat])} книг\n\n"
    text += "\n\n".join([f"• {b['title']}" + (f" — {b['author']}" if b.get('author') else "") for b in results[:10]])
    await query.edit_message_text(text, parse_mode="HTML")

def main():
    token = os.getenv("BOT_TOKEN")
    if not token:
        print("Установите BOT_TOKEN env var. Получить у @BotFather")
        return
    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(cat_callback, pattern=r"^cat:"))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    print(f"Salaf Library Bot запущен. Книг в базе: {len(BOOKS)}")
    app.run_polling()

if __name__ == "__main__":
    main()
