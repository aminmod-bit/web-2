import { create } from 'zustand';
import { books } from '../data/books';
import { scholars } from '../data/scholars';
import { lessons } from '../data/lessons';
import { fawaid } from '../data/fawaid';
import { categories } from '../data/categories';
import { goals, readingPlan } from '../data/goals';
import type { Book, Scholar, Lesson, Faidah, Category, Goal, ReadingPlan } from '../types';

interface LibraryState {
  books: Book[];
  scholars: Scholar[];
  lessons: Lesson[];
  fawaid: Faidah[];
  categories: Category[];
  goals: Goal[];
  readingPlan: ReadingPlan;
  favorites: string[];
  searchQuery: string;
  activeTab: string;
  theme: 'light' | 'dark';
  toggleFavorite: (id: string) => void;
  setSearchQuery: (q: string) => void;
  setActiveTab: (tab: string) => void;
  toggleTheme: () => void;
  updateGoalProgress: (id: string, value: number) => void;
}

export const useStore = create<LibraryState>((set) => ({
  books,
  scholars,
  lessons,
  fawaid,
  categories,
  goals,
  readingPlan,
  favorites: ['b1', 'b3', 'b6'],
  searchQuery: '',
  activeTab: 'home',
  theme: 'dark',
  toggleFavorite: (id) =>
    set((state) => ({
      favorites: state.favorites.includes(id)
        ? state.favorites.filter((f) => f !== id)
        : [...state.favorites, id],
    })),
  setSearchQuery: (q) => set({ searchQuery: q }),
  setActiveTab: (tab) => set({ activeTab: tab }),
  toggleTheme: () =>
    set((state) => ({ theme: state.theme === 'dark' ? 'light' : 'dark' })),
  updateGoalProgress: (id, value) =>
    set((state) => ({
      goals: state.goals.map((g) =>
        g.id === id ? { ...g, current: Math.min(g.current + value, g.target) } : g
      ),
    })),
}));
