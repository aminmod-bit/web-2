import React from 'react';
import { Play, Clock, Eye } from 'lucide-react';
import { Lesson } from '../../types';
import { useStore } from '../../store/useStore';
import { cn } from '../../utils/cn';

interface LessonCardProps {
  lesson: Lesson;
  onClick?: () => void;
  variant?: 'horizontal' | 'compact';
}

const scholarAvatarColors: Record<string, string> = {
  's1': 'from-blue-600 to-blue-800',
  's2': 'from-emerald-600 to-emerald-800',
  's3': 'from-rose-600 to-rose-800',
  's4': 'from-purple-600 to-purple-800',
  's5': 'from-teal-600 to-teal-800',
};

export const LessonCard: React.FC<LessonCardProps> = ({
  lesson,
  onClick,
  variant = 'horizontal',
}) => {
  const { scholars } = useStore();
  const scholar = scholars.find((s) => s.id === lesson.scholarId);

  if (variant === 'compact') {
    return (
      <div
        className={cn(
          'flex items-center gap-3 p-3 rounded-2xl cursor-pointer',
          'bg-white/5 hover:bg-white/10 transition-all duration-200',
          'border border-white/5 hover:border-white/10'
        )}
        onClick={onClick}
      >
        {/* Play icon */}
        <div className={cn(
          'w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0',
          'bg-gradient-to-br',
          scholarAvatarColors[lesson.scholarId] ?? 'from-slate-600 to-slate-800'
        )}>
          <Play size={14} className="text-white fill-white ml-0.5" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-white text-sm font-medium line-clamp-1">{lesson.title}</h3>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="text-white/40 text-[11px]">{scholar?.name}</span>
            <span className="text-white/20 text-[11px]">·</span>
            <span className="flex items-center gap-1 text-white/40 text-[11px]">
              <Clock size={9} /> {lesson.duration}
            </span>
          </div>
        </div>
        {lesson.isNew && (
          <span className="text-[9px] font-bold bg-emerald-500 text-white px-1.5 py-0.5 rounded-full flex-shrink-0">
            NEW
          </span>
        )}
      </div>
    );
  }

  return (
    <div
      className={cn(
        'flex-shrink-0 w-56 cursor-pointer group',
      )}
      onClick={onClick}
    >
      {/* Thumbnail */}
      <div className={cn(
        'h-32 rounded-2xl mb-2.5 flex items-center justify-center relative overflow-hidden',
        'bg-gradient-to-br transition-all duration-300',
        'group-hover:shadow-xl group-hover:-translate-y-1',
        scholarAvatarColors[lesson.scholarId] ?? 'from-slate-600 to-slate-800'
      )}>
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_30%_107%,#fff_0%,transparent_50%)]" />
        <div className={cn(
          'w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm',
          'flex items-center justify-center transition-all duration-300',
          'group-hover:scale-110 group-hover:bg-white/30'
        )}>
          <Play size={20} className="text-white fill-white ml-1" />
        </div>
        
        {/* Duration badge */}
        <div className="absolute bottom-2 right-2 bg-black/50 backdrop-blur-sm text-white text-[10px] px-1.5 py-0.5 rounded-md flex items-center gap-1">
          <Clock size={8} /> {lesson.duration}
        </div>

        {lesson.isNew && (
          <div className="absolute top-2 left-2 bg-emerald-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full">
            NEW
          </div>
        )}
      </div>

      <div className="px-0.5">
        <h3 className="text-white text-xs font-medium line-clamp-2 leading-tight mb-1">
          {lesson.title}
        </h3>
        <p className="text-white/40 text-[10px] truncate">{scholar?.name}</p>
        <div className="flex items-center gap-2 mt-1">
          <span className="flex items-center gap-1 text-white/30 text-[10px]">
            <Eye size={9} /> {(lesson.views / 1000).toFixed(1)}k
          </span>
          <span className="text-white/20 text-[10px]">·</span>
          <span className="text-white/30 text-[10px]">{lesson.category}</span>
        </div>

        {/* Progress */}
        {lesson.progress !== undefined && (
          <div className="mt-2">
            <div className="h-0.5 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full"
                style={{ width: `${lesson.progress}%` }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
