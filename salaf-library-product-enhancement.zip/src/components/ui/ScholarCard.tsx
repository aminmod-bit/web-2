import React from 'react';
import { BookOpen, Headphones } from 'lucide-react';
import { Scholar } from '../../types';
import { cn } from '../../utils/cn';

interface ScholarCardProps {
  scholar: Scholar;
  onClick?: () => void;
  variant?: 'compact' | 'full';
}

export const ScholarCard: React.FC<ScholarCardProps> = ({
  scholar,
  onClick,
  variant = 'compact',
}) => {
  if (variant === 'compact') {
    return (
      <div
        className="flex-shrink-0 w-28 cursor-pointer group"
        onClick={onClick}
      >
        {/* Avatar */}
        <div className={cn(
          'w-20 h-20 rounded-2xl mx-auto mb-2 flex items-center justify-center text-2xl',
          'bg-gradient-to-br transition-all duration-300',
          'group-hover:shadow-lg group-hover:-translate-y-1 group-hover:scale-105',
          scholar.avatarColor
        )}>
          {scholar.nameAr.charAt(0)}
        </div>
        <div className="text-center">
          <h3 className="text-white text-xs font-medium line-clamp-2 leading-tight">
            {scholar.name}
          </h3>
          <p className="text-white/40 text-[10px] mt-0.5">{scholar.born}–{scholar.died ?? 'present'}</p>
        </div>
      </div>
    );
  }

  return (
    <div
      className={cn(
        'flex items-center gap-3 p-3 rounded-2xl cursor-pointer',
        'bg-white/5 hover:bg-white/10 transition-all duration-200',
        'border border-white/5 hover:border-white/10'
      )}
      onClick={onClick}
    >
      <div className={cn(
        'w-12 h-12 rounded-xl flex items-center justify-center text-xl flex-shrink-0',
        'bg-gradient-to-br',
        scholar.avatarColor
      )}>
        {scholar.nameAr.charAt(0)}
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="text-white text-sm font-medium truncate">{scholar.name}</h3>
        <p className="text-white/40 text-xs">{scholar.madhab} · {scholar.origin}</p>
        <div className="flex items-center gap-3 mt-1">
          <span className="flex items-center gap-1 text-white/30 text-[10px]">
            <BookOpen size={9} /> {scholar.bookIds.length} books
          </span>
          <span className="flex items-center gap-1 text-white/30 text-[10px]">
            <Headphones size={9} /> {scholar.lessonIds.length} lessons
          </span>
        </div>
      </div>
    </div>
  );
};
