import React from 'react';
import { Heart, Star } from 'lucide-react';
import { Book } from '../../types';
import { useStore } from '../../store/useStore';
import { cn } from '../../utils/cn';

interface BookCardProps {
  book: Book;
  onClick?: () => void;
  size?: 'sm' | 'md' | 'lg';
  showProgress?: boolean;
}

export const BookCard: React.FC<BookCardProps> = ({
  book,
  onClick,
  size = 'md',
  showProgress = false,
}) => {
  const { favorites, toggleFavorite } = useStore();
  const isFav = favorites.includes(book.id);

  const sizeClasses = {
    sm: 'w-28',
    md: 'w-36',
    lg: 'w-44',
  };

  const coverHeight = {
    sm: 'h-40',
    md: 'h-52',
    lg: 'h-64',
  };

  return (
    <div
      className={cn(
        'flex-shrink-0 cursor-pointer group',
        sizeClasses[size]
      )}
      onClick={onClick}
    >
      {/* Cover */}
      <div className={cn(
        'relative rounded-xl overflow-hidden mb-2.5 shadow-lg transition-all duration-300',
        'group-hover:shadow-xl group-hover:-translate-y-1 group-hover:scale-[1.02]',
        coverHeight[size],
        `bg-gradient-to-br ${book.coverGradient}`
      )}>
        {/* Book spine effect */}
        <div className="absolute left-0 top-0 bottom-0 w-3 bg-black/20 rounded-l-xl" />
        
        {/* Book content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center p-3 text-center">
          <div className="text-white/80 text-xs font-medium leading-tight mb-2 line-clamp-3">
            {book.titleAr}
          </div>
          <div className="w-8 h-0.5 bg-white/40 rounded my-1" />
          <div className="text-white/50 text-[10px]">{book.author.split(' ').slice(-1)[0]}</div>
        </div>

        {/* New badge */}
        {book.isNew && (
          <div className="absolute top-2 right-2 bg-emerald-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full">
            NEW
          </div>
        )}

        {/* Favorite button */}
        <button
          className={cn(
            'absolute bottom-2 right-2 p-1.5 rounded-full transition-all duration-200',
            'opacity-0 group-hover:opacity-100',
            isFav ? 'bg-rose-500 opacity-100' : 'bg-black/40 hover:bg-rose-500'
          )}
          onClick={(e) => {
            e.stopPropagation();
            toggleFavorite(book.id);
          }}
        >
          <Heart
            size={10}
            className="text-white"
            fill={isFav ? 'white' : 'none'}
          />
        </button>

        {/* Overlay on hover */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-300" />
      </div>

      {/* Info */}
      <div className="px-0.5">
        <h3 className="text-white text-xs font-medium leading-tight line-clamp-2 mb-0.5">
          {book.title}
        </h3>
        <p className="text-white/40 text-[10px] truncate">{book.author}</p>
        
        {/* Rating */}
        <div className="flex items-center gap-1 mt-1">
          <Star size={9} className="text-amber-400 fill-amber-400" />
          <span className="text-white/50 text-[10px]">{book.rating}</span>
          <span className="text-white/30 text-[10px]">·</span>
          <span className="text-white/40 text-[10px]">{book.pages}p</span>
        </div>

        {/* Progress */}
        {showProgress && book.progress !== undefined && (
          <div className="mt-2">
            <div className="h-0.5 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-violet-500 to-blue-500 rounded-full transition-all duration-500"
                style={{ width: `${book.progress}%` }}
              />
            </div>
            <span className="text-white/30 text-[9px] mt-0.5 block">{book.progress}%</span>
          </div>
        )}
      </div>
    </div>
  );
};
