import React from 'react';
import { ChevronRight } from 'lucide-react';

interface SectionHeaderProps {
  title: string;
  titleAr?: string;
  onSeeAll?: () => void;
  showSeeAll?: boolean;
}

export const SectionHeader: React.FC<SectionHeaderProps> = ({
  title,
  titleAr,
  onSeeAll,
  showSeeAll = true,
}) => {
  return (
    <div className="flex items-center justify-between mb-4 px-4 md:px-0">
      <div>
        <h2 className="text-white font-semibold text-base">{title}</h2>
        {titleAr && (
          <p className="text-white/30 text-xs mt-0.5" dir="rtl">{titleAr}</p>
        )}
      </div>
      {showSeeAll && onSeeAll && (
        <button
          onClick={onSeeAll}
          className="flex items-center gap-1 text-violet-400 text-xs font-medium hover:text-violet-300 transition-colors"
        >
          See all <ChevronRight size={13} />
        </button>
      )}
    </div>
  );
};
