import React from 'react';
import { Heart, Quote } from 'lucide-react';
import { Faidah } from '../../types';
import { useStore } from '../../store/useStore';
import { cn } from '../../utils/cn';

interface FaidahCardProps {
  faidah: Faidah;
  onClick?: () => void;
}

const scholarAvatarColors: Record<string, string> = {
  's1': 'from-blue-600 to-blue-800',
  's2': 'from-emerald-600 to-emerald-800',
  's3': 'from-rose-600 to-rose-800',
  's4': 'from-purple-600 to-purple-800',
  's5': 'from-teal-600 to-teal-800',
};

const categoryColors: Record<string, string> = {
  Spirituality: 'text-rose-400 bg-rose-400/10',
  Aqeedah: 'text-blue-400 bg-blue-400/10',
  Tazkiyah: 'text-purple-400 bg-purple-400/10',
  Worship: 'text-amber-400 bg-amber-400/10',
  Quran: 'text-teal-400 bg-teal-400/10',
};

export const FaidahCard: React.FC<FaidahCardProps> = ({ faidah, onClick }) => {
  const { scholars } = useStore();
  const scholar = scholars.find((s) => s.id === faidah.scholarId);

  return (
    <div
      className={cn(
        'p-4 rounded-2xl cursor-pointer transition-all duration-200',
        'bg-white/5 hover:bg-white/8 border border-white/5 hover:border-white/10',
        'group'
      )}
      onClick={onClick}
    >
      {/* Quote icon */}
      <div className="flex items-start justify-between mb-3">
        <Quote size={16} className="text-white/20 flex-shrink-0" />
        <span className={cn(
          'text-[10px] font-medium px-2 py-0.5 rounded-full',
          categoryColors[faidah.category] ?? 'text-white/40 bg-white/10'
        )}>
          {faidah.category}
        </span>
      </div>

      {/* Arabic text */}
      <p className="text-white/90 text-sm leading-relaxed text-right mb-2 font-medium" dir="rtl">
        {faidah.textAr}
      </p>

      {/* Divider */}
      <div className="h-px bg-white/5 my-3" />

      {/* English text */}
      <p className="text-white/50 text-xs leading-relaxed italic line-clamp-2">
        "{faidah.text}"
      </p>

      {/* Footer */}
      <div className="flex items-center justify-between mt-3">
        <div className="flex items-center gap-2">
          <div className={cn(
            'w-5 h-5 rounded-md flex items-center justify-center text-[10px] font-bold text-white',
            'bg-gradient-to-br',
            scholarAvatarColors[faidah.scholarId] ?? 'from-slate-600 to-slate-800'
          )}>
            {scholar?.nameAr.charAt(0)}
          </div>
          <div>
            <p className="text-white/60 text-[10px]">{scholar?.name}</p>
            <p className="text-white/30 text-[9px]">{faidah.source}</p>
          </div>
        </div>
        <button
          className={cn(
            'p-1.5 rounded-full transition-all duration-200',
            faidah.isFavorite
              ? 'text-rose-400'
              : 'text-white/20 hover:text-rose-400'
          )}
          onClick={(e) => e.stopPropagation()}
        >
          <Heart
            size={12}
            fill={faidah.isFavorite ? 'currentColor' : 'none'}
          />
        </button>
      </div>
    </div>
  );
};
