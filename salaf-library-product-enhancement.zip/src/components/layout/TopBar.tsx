import React from 'react';
import { Search, Moon, Sun } from 'lucide-react';
import { useStore } from '../../store/useStore';

interface TopBarProps {
  title: string;
  titleAr?: string;
  onSearchClick?: () => void;
  onNavigate?: (page: string) => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  title,
  titleAr,
  onSearchClick,
  onNavigate,
}) => {
  const { theme, toggleTheme } = useStore();

  return (
    <header className="flex items-center justify-between px-4 pt-4 pb-2 sticky top-0 z-30 bg-[#0f0f14]/80 backdrop-blur-xl border-b border-white/5">
      <div>
        <h1 className="text-white font-semibold text-lg leading-tight">{title}</h1>
        {titleAr && (
          <p className="text-white/30 text-xs" dir="rtl">{titleAr}</p>
        )}
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={onSearchClick ?? (() => onNavigate?.('search'))}
          className="w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors"
          aria-label="Search"
        >
          <Search size={15} className="text-white/60" />
        </button>
        <button
          onClick={toggleTheme}
          className="w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors"
          aria-label="Toggle theme"
        >
          {theme === 'dark' ? (
            <Moon size={15} className="text-white/60" />
          ) : (
            <Sun size={15} className="text-amber-400" />
          )}
        </button>
        <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-violet-500 to-blue-600 flex items-center justify-center">
          <span className="text-white text-xs font-bold">A</span>
        </div>
      </div>
    </header>
  );
};
