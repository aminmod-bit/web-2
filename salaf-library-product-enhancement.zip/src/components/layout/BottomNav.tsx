import React from 'react';
import { Home, BookOpen, Users, Headphones, Lightbulb, BarChart3, Search, Target } from 'lucide-react';
import { cn } from '../../utils/cn';

interface BottomNavProps {
  activePage: string;
  onNavigate: (page: string) => void;
}

const navItems = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'books', label: 'Books', icon: BookOpen },
  { id: 'scholars', label: 'Scholars', icon: Users },
  { id: 'lessons', label: 'Lessons', icon: Headphones },
  { id: 'fawaid', label: 'Fawaid', icon: Lightbulb },
];

export const BottomNav: React.FC<BottomNavProps> = ({ activePage, onNavigate }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 md:hidden">
      {/* Blur backdrop */}
      <div className="absolute inset-0 bg-[#0f0f14]/90 backdrop-blur-xl border-t border-white/5" />
      
      <div className="relative flex items-center justify-around px-2 py-2 pb-safe">
        {navItems.map(({ id, label, icon: Icon }) => {
          const isActive = activePage === id;
          return (
            <button
              key={id}
              onClick={() => onNavigate(id)}
              className={cn(
                'flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition-all duration-200',
                isActive
                  ? 'text-violet-400'
                  : 'text-white/30 hover:text-white/60'
              )}
              aria-label={label}
            >
              <div className={cn(
                'relative transition-all duration-200',
                isActive && 'scale-110'
              )}>
                <Icon size={20} strokeWidth={isActive ? 2 : 1.5} />
                {isActive && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-violet-400 rounded-full" />
                )}
              </div>
              <span className={cn(
                'text-[9px] font-medium transition-all duration-200',
                isActive ? 'opacity-100' : 'opacity-0'
              )}>
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export const SideNav: React.FC<BottomNavProps> = ({ activePage, onNavigate }) => {
  const allItems = [
    { id: 'home', label: 'Home', labelAr: 'الرئيسية', icon: Home },
    { id: 'books', label: 'Books', labelAr: 'الكتب', icon: BookOpen },
    { id: 'scholars', label: 'Scholars', labelAr: 'العلماء', icon: Users },
    { id: 'lessons', label: 'Lessons', labelAr: 'الدروس', icon: Headphones },
    { id: 'fawaid', label: 'Fawaid', labelAr: 'الفوائد', icon: Lightbulb },
    { id: 'search', label: 'Search', labelAr: 'البحث', icon: Search },
    { id: 'goals', label: 'Goals', labelAr: 'الأهداف', icon: Target },
    { id: 'dashboard', label: 'Dashboard', labelAr: 'لوحة التحكم', icon: BarChart3 },
  ];

  return (
    <aside className="hidden md:flex flex-col w-56 min-h-screen bg-[#0f0f14] border-r border-white/5 fixed left-0 top-0 bottom-0 z-40">
      {/* Logo */}
      <div className="p-6 mb-2">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-violet-500 to-blue-600 flex items-center justify-center">
            <BookOpen size={16} className="text-white" />
          </div>
          <div>
            <h1 className="text-white font-bold text-sm">Salaf</h1>
            <p className="text-white/30 text-[10px]">مكتبة السلف</p>
          </div>
        </div>
      </div>

      {/* Nav items */}
      <div className="flex-1 px-3 space-y-0.5">
        {allItems.map(({ id, label, labelAr, icon: Icon }) => {
          const isActive = activePage === id;
          return (
            <button
              key={id}
              onClick={() => onNavigate(id)}
              className={cn(
                'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 text-left',
                isActive
                  ? 'bg-violet-500/15 text-violet-400'
                  : 'text-white/40 hover:text-white/70 hover:bg-white/5'
              )}
            >
              <Icon size={16} strokeWidth={isActive ? 2 : 1.5} />
              <div className="flex-1 min-w-0">
                <div className="text-xs font-medium">{label}</div>
                <div className="text-[9px] opacity-60" dir="rtl">{labelAr}</div>
              </div>
              {isActive && (
                <div className="w-1 h-4 bg-violet-400 rounded-full ml-auto" />
              )}
            </button>
          );
        })}
      </div>

      {/* Version */}
      <div className="p-4 text-white/20 text-[10px] text-center">
        Salaf Library v1.0 RC1
      </div>
    </aside>
  );
};
