import React from 'react';
import { ArrowLeft, Heart, Download, BookOpen, Star, Globe, FileText, Calendar, User, Tag } from 'lucide-react';
import { useStore } from '../store/useStore';
import { BookCard } from '../components/ui/BookCard';
import { cn } from '../utils/cn';

interface BookDetailPageProps {
  bookId: string;
  onNavigate: (page: string, id?: string) => void;
}

const langLabels: Record<string, string> = {
  ar: 'Arabic',
  en: 'English',
  ur: 'Urdu',
  fr: 'French',
};

export const BookDetailPage: React.FC<BookDetailPageProps> = ({ bookId, onNavigate }) => {
  const { books, scholars, favorites, toggleFavorite } = useStore();
  const book = books.find((b) => b.id === bookId);

  if (!book) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <p className="text-white/40">Book not found</p>
          <button className="text-violet-400 text-sm mt-2" onClick={() => onNavigate('books')}>
            Back to books
          </button>
        </div>
      </div>
    );
  }

  const scholar = scholars.find((s) => s.id === book.authorId);
  const relatedBooks = books.filter((b) => book.relatedBooks.includes(b.id));
  const authorBooks = books.filter((b) => b.authorId === book.authorId && b.id !== book.id);
  const isFav = favorites.includes(book.id);

  return (
    <div className="flex-1 overflow-y-auto pb-24 md:pb-8">
      {/* Header */}
      <div className={cn(
        'relative h-64 md:h-80 bg-gradient-to-br overflow-hidden',
        book.coverGradient
      )}>
        <div className="absolute inset-0 bg-black/30" />
        {/* Back */}
        <button
          onClick={() => onNavigate('books')}
          className="absolute top-4 left-4 p-2 rounded-xl bg-black/30 backdrop-blur-sm text-white hover:bg-black/50 transition-colors z-10"
          aria-label="Go back"
        >
          <ArrowLeft size={18} />
        </button>

        {/* Actions */}
        <div className="absolute top-4 right-4 flex gap-2 z-10">
          <button
            onClick={() => toggleFavorite(book.id)}
            className={cn(
              'p-2 rounded-xl backdrop-blur-sm transition-all duration-200',
              isFav ? 'bg-rose-500 text-white' : 'bg-black/30 text-white hover:bg-rose-500'
            )}
            aria-label="Toggle favorite"
          >
            <Heart size={18} fill={isFav ? 'white' : 'none'} />
          </button>
          <button
            className="p-2 rounded-xl bg-black/30 backdrop-blur-sm text-white hover:bg-black/50 transition-colors"
            aria-label="Download"
          >
            <Download size={18} />
          </button>
        </div>

        {/* Book spine visual */}
        <div className="absolute bottom-0 left-0 right-0 h-2/3 flex items-end justify-center pb-6">
          <div className="relative">
            {/* Book cover mockup */}
            <div className={cn(
              'w-32 h-44 rounded-xl shadow-2xl bg-gradient-to-br relative overflow-hidden',
              book.coverGradient
            )}>
              <div className="absolute left-0 top-0 bottom-0 w-3 bg-black/30 rounded-l-xl" />
              <div className="absolute inset-0 flex flex-col items-center justify-center p-3 text-center">
                <p className="text-white/90 text-xs font-medium leading-tight">{book.titleAr}</p>
                <div className="w-6 h-0.5 bg-white/40 rounded my-2" />
                <p className="text-white/50 text-[9px]">{book.year}</p>
              </div>
            </div>
            {/* Shadow */}
            <div className="absolute -bottom-2 left-2 right-2 h-4 bg-black/30 blur-md rounded-full" />
          </div>
        </div>
      </div>

      <div className="px-4 md:px-0 py-5 space-y-6">

        {/* Title & author */}
        <div>
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1">
              <h1 className="text-white font-bold text-xl leading-tight">{book.title}</h1>
              <p className="text-white/50 text-sm mt-1" dir="rtl">{book.titleAr}</p>
            </div>
            <div className="flex items-center gap-1 bg-amber-500/10 px-2 py-1 rounded-xl border border-amber-500/20">
              <Star size={12} className="text-amber-400 fill-amber-400" />
              <span className="text-amber-400 text-sm font-medium">{book.rating}</span>
            </div>
          </div>

          {/* Author link */}
          {scholar && (
            <button
              onClick={() => onNavigate('scholar', scholar.id)}
              className="flex items-center gap-2 mt-3 group"
            >
              <div className={cn(
                'w-7 h-7 rounded-lg flex items-center justify-center text-sm font-bold text-white',
                'bg-gradient-to-br',
                scholar.avatarColor
              )}>
                {scholar.nameAr.charAt(0)}
              </div>
              <div className="text-left">
                <p className="text-violet-400 text-sm font-medium group-hover:text-violet-300 transition-colors">
                  {scholar.name}
                </p>
                <p className="text-white/30 text-[10px]">{scholar.madhab} · {scholar.origin}</p>
              </div>
            </button>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex gap-3">
          <button className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-violet-500 to-blue-600 text-white font-semibold text-sm flex items-center justify-center gap-2 hover:opacity-90 transition-opacity shadow-lg shadow-violet-500/25">
            <BookOpen size={16} /> Read Now
          </button>
          <button className="px-5 py-3 rounded-2xl bg-white/10 text-white font-medium text-sm flex items-center justify-center gap-2 hover:bg-white/15 transition-colors border border-white/10">
            <Download size={16} /> Download
          </button>
        </div>

        {/* Meta info */}
        <div className="grid grid-cols-2 gap-2.5">
          {[
            { icon: Globe, label: 'Language', value: langLabels[book.language] ?? book.language },
            { icon: FileText, label: 'Pages', value: `${book.pages} pages` },
            { icon: Calendar, label: 'Year', value: book.year.toString() },
            { icon: Tag, label: 'Category', value: book.category },
            { icon: Download, label: 'Downloads', value: book.downloads.toLocaleString() },
            { icon: User, label: 'Size', value: book.size },
          ].map(({ icon: Icon, label, value }) => (
            <div key={label} className="flex items-center gap-2.5 p-3 rounded-2xl bg-white/5 border border-white/5">
              <div className="w-7 h-7 rounded-lg bg-white/8 flex items-center justify-center flex-shrink-0">
                <Icon size={13} className="text-white/40" />
              </div>
              <div className="min-w-0">
                <p className="text-white/30 text-[10px]">{label}</p>
                <p className="text-white text-xs font-medium truncate">{value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-2">
          {book.tags.map((tag) => (
            <span
              key={tag}
              className="px-3 py-1 rounded-full bg-violet-500/10 border border-violet-500/20 text-violet-400 text-[11px]"
            >
              #{tag}
            </span>
          ))}
        </div>

        {/* Description */}
        <div>
          <h2 className="text-white font-semibold text-sm mb-2">About this Book</h2>
          <p className="text-white/60 text-sm leading-relaxed">{book.description}</p>
          <p className="text-white/50 text-sm leading-relaxed mt-3 text-right" dir="rtl">{book.descriptionAr}</p>
        </div>

        {/* Author books */}
        {authorBooks.length > 0 && (
          <div>
            <h2 className="text-white font-semibold text-sm mb-3">More by {book.author.split(' ')[0]}</h2>
            <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-none -mx-4 px-4">
              {authorBooks.map((b) => (
                <BookCard key={b.id} book={b} size="sm" onClick={() => onNavigate('book', b.id)} />
              ))}
            </div>
          </div>
        )}

        {/* Related books */}
        {relatedBooks.length > 0 && (
          <div>
            <h2 className="text-white font-semibold text-sm mb-3">Related Books</h2>
            <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-none -mx-4 px-4">
              {relatedBooks.map((b) => (
                <BookCard key={b.id} book={b} size="sm" onClick={() => onNavigate('book', b.id)} />
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
