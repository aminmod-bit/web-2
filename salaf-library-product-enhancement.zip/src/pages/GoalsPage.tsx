import React, { useState } from 'react';
import { Target, Flame, BookOpen, FileText, Headphones, Lightbulb, Trophy, Calendar, TrendingUp } from 'lucide-react';
import { useStore } from '../store/useStore';
import { TopBar } from '../components/layout/TopBar';
import { ProgressRing } from '../components/ui/ProgressRing';
import { cn } from '../utils/cn';

interface GoalsPageProps {
  onNavigate: (page: string, id?: string) => void;
}

const goalTypeIcons: Record<string, React.ElementType> = {
  books: BookOpen,
  pages: FileText,
  lessons: Headphones,
  fawaid: Lightbulb,
};

const ringColors: string[] = ['#8b5cf6', '#3b82f6', '#10b981', '#f59e0b'];

export const GoalsPage: React.FC<GoalsPageProps> = ({ onNavigate }) => {
  const { goals, readingPlan } = useStore();
  const [activeTab, setActiveTab] = useState<'goals' | 'plan' | 'stats'>('goals');

  const completedGoals = goals.filter((g) => g.isCompleted);
  const activeGoals = goals.filter((g) => !g.isCompleted);
  const overallProgress = Math.round(
    goals.reduce((sum, g) => sum + Math.min((g.current / g.target) * 100, 100), 0) / goals.length
  );

  return (
    <div className="flex-1 overflow-y-auto pb-24 md:pb-8">
      <TopBar title="Goals & Plan" titleAr="الأهداف والخطة" onNavigate={onNavigate} />

      <div className="px-4 md:px-0 py-4 space-y-5">

        {/* Overview banner */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-violet-600/20 via-blue-600/10 to-transparent p-5 border border-violet-500/20">
          <div className="absolute top-0 right-0 w-32 h-32 bg-violet-500/10 rounded-full -translate-y-8 translate-x-8 blur-2xl" />
          <div className="flex items-center gap-5">
            <ProgressRing progress={overallProgress} size={80} color="#8b5cf6">
              <div className="text-center">
                <span className="text-white font-bold text-sm">{overallProgress}%</span>
              </div>
            </ProgressRing>
            <div>
              <h2 className="text-white font-bold text-lg">Overall Progress</h2>
              <p className="text-white/40 text-xs mt-0.5">{completedGoals.length} of {goals.length} goals completed</p>
              <div className="flex items-center gap-3 mt-2">
                <div className="flex items-center gap-1.5">
                  <Flame size={14} className="text-amber-400 fill-amber-400" />
                  <span className="text-white font-semibold text-sm">{readingPlan.currentStreak}</span>
                  <span className="text-white/30 text-xs">day streak</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Trophy size={14} className="text-yellow-400" />
                  <span className="text-white font-semibold text-sm">{readingPlan.longestStreak}</span>
                  <span className="text-white/30 text-xs">best</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2">
          {(['goals', 'plan', 'stats'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                'flex-1 py-2 rounded-xl text-xs font-medium capitalize transition-all',
                activeTab === tab
                  ? 'bg-violet-500/20 text-violet-400 border border-violet-500/30'
                  : 'bg-white/5 text-white/40 hover:bg-white/8'
              )}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* GOALS TAB */}
        {activeTab === 'goals' && (
          <div className="space-y-4">
            {/* Active Goals */}
            <div>
              <h3 className="text-white/60 text-xs font-medium uppercase tracking-wider mb-3">Active Goals</h3>
              <div className="space-y-3">
                {activeGoals.map((goal, i) => {
                  const Icon = goalTypeIcons[goal.type] ?? Target;
                  const pct = Math.round((goal.current / goal.target) * 100);
                  const daysLeft = Math.ceil(
                    (new Date(goal.deadline).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
                  );

                  return (
                    <div
                      key={goal.id}
                      className="p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/8 transition-all"
                    >
                      <div className="flex items-start gap-4">
                        <ProgressRing progress={pct} size={56} color={ringColors[i % ringColors.length]}>
                          <span className="text-white text-[10px] font-bold">{pct}%</span>
                        </ProgressRing>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <h4 className="text-white font-medium text-sm leading-tight">{goal.title}</h4>
                            <span className="text-lg flex-shrink-0">{goal.icon}</span>
                          </div>
                          <p className="text-white/40 text-[11px] mt-0.5">{goal.description}</p>
                          <div className="flex items-center gap-3 mt-2">
                            <div className="flex items-center gap-1 text-white/50 text-[11px]">
                              <Icon size={10} />
                              <span>{goal.current} / {goal.target}</span>
                            </div>
                            {daysLeft > 0 && (
                              <div className="flex items-center gap-1 text-white/30 text-[11px]">
                                <Calendar size={10} />
                                <span>{daysLeft}d left</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Progress bar */}
                      <div className="mt-3">
                        <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full bg-gradient-to-r ${goal.color} transition-all duration-700`}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>

                      {/* Mini history chart */}
                      {goal.history.length > 0 && (
                        <div className="mt-3 flex items-end gap-1 h-8">
                          {goal.history.map((h, idx) => {
                            const barH = Math.round((h.value / goal.target) * 100);
                            return (
                              <div
                                key={idx}
                                className="flex-1 rounded-sm bg-white/10 relative overflow-hidden"
                                style={{ height: '100%' }}
                              >
                                <div
                                  className={`absolute bottom-0 left-0 right-0 rounded-sm bg-gradient-to-t ${goal.color} opacity-70`}
                                  style={{ height: `${barH}%` }}
                                />
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Completed Goals */}
            {completedGoals.length > 0 && (
              <div>
                <h3 className="text-white/60 text-xs font-medium uppercase tracking-wider mb-3">Completed 🏆</h3>
                <div className="space-y-2">
                  {completedGoals.map((goal) => {
                    const Icon = goalTypeIcons[goal.type] ?? Target;
                    return (
                      <div
                        key={goal.id}
                        className="flex items-center gap-3 p-3 rounded-2xl bg-emerald-500/5 border border-emerald-500/20"
                      >
                        <span className="text-xl">{goal.icon}</span>
                        <div className="flex-1">
                          <p className="text-white/80 text-sm font-medium">{goal.title}</p>
                          <div className="flex items-center gap-1 text-emerald-400 text-[11px] mt-0.5">
                            <Icon size={10} />
                            <span>{goal.target} / {goal.target}</span>
                          </div>
                        </div>
                        <Trophy size={16} className="text-yellow-400" />
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* READING PLAN TAB */}
        {activeTab === 'plan' && (
          <div className="space-y-4">
            {/* Plan info */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
              <h3 className="text-white font-semibold text-sm mb-3">{readingPlan.name}</h3>
              <p className="text-white/50 text-xs leading-relaxed mb-4">{readingPlan.goal}</p>

              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'Daily Pages', value: readingPlan.dailyPages, unit: 'pages', color: 'text-violet-400' },
                  { label: 'Weekly Lessons', value: readingPlan.weeklyLessons, unit: 'lessons', color: 'text-emerald-400' },
                  { label: 'Pages Read', value: readingPlan.totalPagesRead, unit: 'total', color: 'text-blue-400' },
                  { label: 'Lessons Done', value: readingPlan.totalLessonsCompleted, unit: 'total', color: 'text-amber-400' },
                ].map(({ label, value, unit, color }) => (
                  <div key={label} className="p-3 rounded-xl bg-white/5 text-center">
                    <div className={`${color} font-bold text-xl`}>{value}</div>
                    <div className="text-white/30 text-[10px]">{unit}</div>
                    <div className="text-white/50 text-[10px] mt-0.5">{label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Streak info */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-600/15 to-orange-600/10 border border-amber-500/20">
              <div className="flex items-center gap-3 mb-3">
                <Flame size={24} className="text-amber-400 fill-amber-400" />
                <div>
                  <h3 className="text-white font-bold text-2xl">{readingPlan.currentStreak} days</h3>
                  <p className="text-white/40 text-xs">Current Streak</p>
                </div>
              </div>
              <div className="flex items-center justify-between text-sm">
                <div>
                  <span className="text-white/60 text-xs">Longest: </span>
                  <span className="text-amber-400 font-semibold">{readingPlan.longestStreak} days</span>
                </div>
                <div>
                  <span className="text-white/60 text-xs">Started: </span>
                  <span className="text-white/80 text-xs">{readingPlan.startDate}</span>
                </div>
              </div>
            </div>

            {/* Weekly grid */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
              <h3 className="text-white font-medium text-sm mb-3">This Week</h3>
              <div className="flex items-end gap-2">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, i) => {
                  const val = readingPlan.weeklyProgress[i];
                  const pct = Math.min((val / readingPlan.dailyPages) * 100, 100);
                  const isToday = i === new Date().getDay();
                  return (
                    <div key={day} className="flex-1 flex flex-col items-center gap-1.5">
                      <span className="text-white/40 text-[9px]">{val}p</span>
                      <div className="w-full bg-white/8 rounded-lg overflow-hidden" style={{ height: 60 }}>
                        <div
                          className={`w-full rounded-lg transition-all duration-500 ${isToday ? 'bg-gradient-to-t from-violet-600 to-violet-400' : pct >= 100 ? 'bg-gradient-to-t from-emerald-600 to-emerald-400' : 'bg-gradient-to-t from-white/20 to-white/10'}`}
                          style={{ height: `${pct}%`, marginTop: `${100 - pct}%` }}
                        />
                      </div>
                      <span className={`text-[9px] ${isToday ? 'text-violet-400 font-bold' : 'text-white/30'}`}>{day.slice(0, 1)}</span>
                    </div>
                  );
                })}
              </div>
              <div className="flex items-center justify-between mt-3 text-[10px]">
                <span className="text-white/30">Daily target: {readingPlan.dailyPages} pages</span>
                <span className="text-violet-400">
                  {readingPlan.weeklyProgress.reduce((s, v) => s + v, 0)}/{readingPlan.dailyPages * 7} this week
                </span>
              </div>
            </div>
          </div>
        )}

        {/* STATS TAB */}
        {activeTab === 'stats' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
              <h3 className="text-white font-medium text-sm mb-4 flex items-center gap-2">
                <TrendingUp size={14} className="text-violet-400" /> Reading Statistics
              </h3>
              <div className="space-y-4">
                {goals.map((goal) => {
                  const pct = Math.round((goal.current / goal.target) * 100);
                  const Icon = goalTypeIcons[goal.type] ?? Target;
                  return (
                    <div key={goal.id}>
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <Icon size={12} className="text-white/40" />
                          <span className="text-white/60 text-xs">{goal.title}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-white text-xs font-medium">{goal.current}</span>
                          <span className="text-white/30 text-xs">/ {goal.target}</span>
                        </div>
                      </div>
                      <div className="h-2 bg-white/8 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full bg-gradient-to-r ${goal.color} transition-all duration-700`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Achievement history */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
              <h3 className="text-white font-medium text-sm mb-3">Goal History</h3>
              <div className="space-y-2">
                {goals.flatMap((g) =>
                  g.history.slice(-3).map((h, idx) => ({
                    id: `${g.id}-${idx}`,
                    goalTitle: g.title,
                    date: h.date,
                    value: h.value,
                    target: g.target,
                    icon: g.icon,
                    color: g.color,
                  }))
                ).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 8).map((item) => (
                  <div key={item.id} className="flex items-center gap-3 py-1.5">
                    <span className="text-base">{item.icon}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-white/60 text-xs truncate">{item.goalTitle}</p>
                      <p className="text-white/30 text-[10px]">{item.date}</p>
                    </div>
                    <span className="text-white/60 text-xs">{item.value} / {item.target}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
