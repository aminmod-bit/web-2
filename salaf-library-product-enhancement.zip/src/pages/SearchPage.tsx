import React, { useState, useMemo } from 'react';
import { Search, BookOpen, Users, Headphones, Lightbulb, X } from 'lucide-react';
import { useStore } from '../store/useStore';
import { TopBar } from '../components/layout/TopBar';
import { BookCard } from '../components/ui/BookCard';
import { cn } from '../utils/cn';

interface SearchPageProps {
  onNavigate: (page: string, id?: string) => void;
}

type SearchTab = 'all' | 'books' | 'scholars' | 'lessons' | 'fawaid';

export const SearchPage: React.FC<SearchPageProps> = ({ onNavigate }) => {
  const { books, scholars, lessons, fawaid, categories } = useStore();
  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState<SearchTab>('all');

  const q = query.toLowerCase().trim();

  const results = useMemo(() => {
    if (!q) return { books: [], scholars: [], lessons: [], fawaid: [], categories: [] };
    return {
      books: books.filter((b) =>
        b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q) || b.titleAr.includes(query)
      ),
      scholars: scholars.filter((s) =>
        s.name.toLowerCase().includes(q) || s.nameAr.includes(query) || s.origin.toLowerCase().includes(q)
      ),
      lessons: lessons.filter((l) =>
        l.title.toLowerCase().includes(q) || l.titleAr.includes(query)
      ),
      fawaid: fawaid.filter((f) =>
        f.text.toLowerCase().includes(q) || f.textAr.includes(query)
      ),
      categories: categories.filter((c) =>
        c.name.toLowerCase().includes(q) || c.nameAr.includes(query)
      ),
    };
  }, [q, books, scholars, lessons, fawaid, categories, query]);

  const totalResults = results.books.length + results.scholars.length + results.lessons.length + results.fawaid.length;

  const tabs: { id: SearchTab; label: string; icon: React.ElementType; count: number }[] = [
    { id: 'all', label: 'All', icon: Search, count: totalResults },
    { id: 'books', label: 'Books', icon: BookOpen, count: results.books.length },
    { id: 'scholars', label: 'Scholars', icon: Users, count: results.scholars.length },
    { id: 'lessons', label: 'Lessons', icon: Headphones, count: results.lessons.length },
    { id: 'fawaid', label: 'Fawaid', icon: Lightbulb, count: results.fawaid.length },
  ];

  const recentSearches = ['Ibn al-Qayyim', 'Aqeedah', 'Tawheed', 'Nawawi'];

  return (
    <div className="flex-1 overflow-y-auto pb-24 md:pb-8">
      <TopBar title="Search" titleAr="البحث" onNavigate={onNavigate} />

      <div className="px-4 md:px-0 py-4 space-y-4">

        {/* Search input */}
        <div className="relative">
          <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" />
          <input
            type="text"
            autoFocus
            placeholder="Search books, scholars, lessons, fawaid..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-white/8 border border-white/10 rounded-2xl pl-11 pr-10 py-3 text-white text-sm placeholder-white/25 outline-none focus:border-violet-500/50 focus:bg-white/10 transition-all"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
            >
              <X size={12} className="text-white/60" />
            </button>
          )}
        </div>

        {/* No query state */}
        {!q && (
          <div className="space-y-6">
            {/* Recent searches */}
            <div>
              <h3 className="text-white/50 text-xs font-medium uppercase tracking-wider mb-3">Recent Searches</h3>
              <div className="flex flex-wrap gap-2">
                {recentSearches.map((s) => (
                  <button
                    key={s}
                    onClick={() => setQuery(s)}
                    className="px-3 py-1.5 rounded-xl bg-white/5 border border-white/5 text-white/50 text-xs hover:bg-white/10 hover:text-white/80 transition-all"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Browse categories */}
            <div>
              <h3 className="text-white/50 text-xs font-medium uppercase tracking-wider mb-3">Browse Categories</h3>
              <div className="grid grid-cols-2 gap-2">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setQuery(cat.name)}
                    className={cn(
                      'flex items-center gap-3 p-3 rounded-2xl text-left transition-all',
                      `bg-gradient-to-br ${cat.color} opacity-80 hover:opacity-100`
                    )}
                  >
                    <span className="text-lg">{cat.icon}</span>
                    <div>
                      <p className="text-white font-medium text-xs">{cat.name}</p>
                      <p className="text-white/60 text-[10px]">{cat.bookCount} books</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Results */}
        {q && (
          <>
            {/* Tabs */}
            <div className="flex gap-1.5 overflow-x-auto scrollbar-none pb-1">
              {tabs.map(({ id, label, icon: Icon, count }) => (
                <button
                  key={id}
                  onClick={() => setActiveTab(id)}
                  className={cn(
                    'flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all',
                    activeTab === id
                      ? 'bg-violet-500/20 text-violet-400 border border-violet-500/30'
                      : 'bg-white/5 text-white/40 hover:bg-white/8 hover:text-white/60'
                  )}
                >
                  <Icon size={11} />
                  {label}
                  {count > 0 && (
                    <span className={cn(
                      'text-[9px] px-1 rounded-full',
                      activeTab === id ? 'bg-violet-500/30 text-violet-300' : 'bg-white/10 text-white/40'
                    )}>
                      {count}
                    </span>
                  )}
                </button>
              ))}
            </div>

            {totalResults === 0 && (
              <div className="text-center py-16">
                <Search size={40} className="text-white/10 mx-auto mb-3" />
                <p className="text-white/30 text-sm">No results for "{query}"</p>
                <p className="text-white/20 text-xs mt-1">Try a different search term</p>
              </div>
            )}

            {/* Books results */}
            {(activeTab === 'all' || activeTab === 'books') && results.books.length > 0 && (
              <div>
                {activeTab === 'all' && (
                  <h3 className="text-white/50 text-xs font-medium uppercase tracking-wider mb-3 flex items-center gap-2">
                    <BookOpen size={11} /> Books ({results.books.length})
                  </h3>
                )}
                <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none -mx-4 px-4">
                  {results.books.map((book) => (
                    <BookCard
                      key={book.id}
                      book={book}
                      size="sm"
                      onClick={() => onNavigate('book', book.id)}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Scholars results */}
            {(activeTab === 'all' || activeTab === 'scholars') && results.scholars.length > 0 && (
              <div>
                {activeTab === 'all' && (
                  <h3 className="text-white/50 text-xs font-medium uppercase tracking-wider mb-3 flex items-center gap-2">
                    <Users size={11} /> Scholars ({results.scholars.length})
                  </h3>
                )}
                <div className="space-y-2">
                  {results.scholars.map((scholar) => (
                    <button
                      key={scholar.id}
                      className="w-full flex items-center gap-3 p-3 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/8 transition-all text-left"
                      onClick={() => onNavigate('scholar', scholar.id)}
                    >
                      <div className={cn(
                        'w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold text-white flex-shrink-0 bg-gradient-to-br',
                        scholar.avatarColor
                      )}>
                        {scholar.nameAr.charAt(0)}
                      </div>
                      <div>
                        <p className="text-white text-sm font-medium">{scholar.name}</p>
                        <p className="text-white/30 text-[11px]">{scholar.madhab} · {scholar.origin}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Lessons results */}
            {(activeTab === 'all' || activeTab === 'lessons') && results.lessons.length > 0 && (
              <div>
                {activeTab === 'all' && (
                  <h3 className="text-white/50 text-xs font-medium uppercase tracking-wider mb-3 flex items-center gap-2">
                    <Headphones size={11} /> Lessons ({results.lessons.length})
                  </h3>
                )}
                <div className="space-y-2">
                  {results.lessons.map((lesson) => (
                    <div
                      key={lesson.id}
                      className="flex items-center gap-3 p-3 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/8 transition-all cursor-pointer"
                      onClick={() => onNavigate('lessons')}
                    >
                      <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0">
                        <Headphones size={16} className="text-white/50" />
                      </div>
                      <div>
                        <p className="text-white text-sm font-medium line-clamp-1">{lesson.title}</p>
                        <p className="text-white/30 text-[11px]">{lesson.duration} · {lesson.category}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Fawaid results */}
            {(activeTab === 'all' || activeTab === 'fawaid') && results.fawaid.length > 0 && (
              <div>
                {activeTab === 'all' && (
                  <h3 className="text-white/50 text-xs font-medium uppercase tracking-wider mb-3 flex items-center gap-2">
                    <Lightbulb size={11} /> Fawaid ({results.fawaid.length})
                  </h3>
                )}
                <div className="space-y-2">
                  {results.fawaid.map((f) => (
                    <div
                      key={f.id}
                      className="p-3 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/8 transition-all cursor-pointer"
                      onClick={() => onNavigate('fawaid')}
                    >
                      <p className="text-white/70 text-xs leading-relaxed line-clamp-2 text-right" dir="rtl">
                        {f.textAr}
                      </p>
                      <p className="text-white/30 text-[10px] mt-1">{f.source}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
