import React from 'react';
import { BookOpen, Headphones, Flame, Target } from 'lucide-react';
import { useStore } from '../store/useStore';
import { BookCard } from '../components/ui/BookCard';
import { LessonCard } from '../components/ui/LessonCard';
import { FaidahCard } from '../components/ui/FaidahCard';
import { ScholarCard } from '../components/ui/ScholarCard';
import { SectionHeader } from '../components/ui/SectionHeader';
import { ProgressRing } from '../components/ui/ProgressRing';
import { TopBar } from '../components/layout/TopBar';

interface HomePageProps {
  onNavigate: (page: string, id?: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const { books, lessons, fawaid, scholars, categories, readingPlan, goals } = useStore();

  const inProgressBooks = books.filter((b) => b.progress !== undefined && b.progress > 0 && b.progress < 100);
  const inProgressLessons = lessons.filter((l) => l.progress !== undefined && l.progress > 0 && l.progress < 100);
  const recentBooks = [...books].sort(() => Math.random() - 0.5).slice(0, 6);
  const recentLessons = lessons.filter((l) => l.isNew).slice(0, 4);
  const recentFawaid = fawaid.slice(0, 3);
  const popularBooks = [...books].sort((a, b) => b.downloads - a.downloads).slice(0, 6);

  const todayPercent = Math.round(
    (readingPlan.weeklyProgress[new Date().getDay()] / readingPlan.dailyPages) * 100
  );

  return (
    <div className="flex-1 overflow-y-auto pb-24 md:pb-8">
      <TopBar
        title="Salaf Library"
        titleAr="مكتبة السلف"
        onNavigate={onNavigate}
      />

      <div className="px-4 md:px-0 space-y-8 py-4">

        {/* Hero greeting */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-violet-600/30 via-blue-600/20 to-transparent p-5 border border-violet-500/20">
          <div className="absolute top-0 right-0 w-40 h-40 bg-violet-500/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl" />
          <div className="relative">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-violet-300/70 text-xs mb-1">السلام عليكم</p>
                <h2 className="text-white text-xl font-bold">Good day, Reader</h2>
                <p className="text-white/40 text-sm mt-0.5">Continue your journey of knowledge</p>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1.5 text-amber-400">
                  <Flame size={16} className="fill-amber-400" />
                  <span className="text-sm font-bold">{readingPlan.currentStreak}</span>
                </div>
                <p className="text-white/30 text-[10px]">day streak</p>
              </div>
            </div>

            {/* Daily progress bars */}
            <div className="space-y-2">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-white/60 flex items-center gap-1.5">
                    <BookOpen size={11} /> Daily reading
                  </span>
                  <span className="text-white/40">
                    {readingPlan.weeklyProgress[new Date().getDay()]}/{readingPlan.dailyPages} pages
                  </span>
                </div>
                <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-violet-500 to-blue-500 rounded-full transition-all duration-700"
                    style={{ width: `${Math.min(todayPercent, 100)}%` }}
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-white/60 flex items-center gap-1.5">
                    <Headphones size={11} /> Weekly lessons
                  </span>
                  <span className="text-white/40">
                    2/{readingPlan.weeklyLessons} lessons
                  </span>
                </div>
                <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full transition-all duration-700"
                    style={{ width: '66%' }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick stats row */}
        <div className="grid grid-cols-4 gap-2">
          {[
            { label: 'Books', value: books.length, icon: BookOpen, color: 'text-violet-400' },
            { label: 'Lessons', value: lessons.length, icon: Headphones, color: 'text-emerald-400' },
            { label: 'Fawaid', value: fawaid.length, icon: Target, color: 'text-amber-400' },
            { label: 'Streak', value: readingPlan.currentStreak + 'd', icon: Flame, color: 'text-rose-400' },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="bg-white/5 rounded-2xl p-3 border border-white/5 text-center">
              <Icon size={16} className={`${color} mx-auto mb-1`} />
              <div className="text-white font-bold text-base leading-tight">{value}</div>
              <div className="text-white/30 text-[9px]">{label}</div>
            </div>
          ))}
        </div>

        {/* Continue Reading */}
        {inProgressBooks.length > 0 && (
          <section>
            <SectionHeader
              title="Continue Reading"
              titleAr="متابعة القراءة"
              onSeeAll={() => onNavigate('books')}
            />
            <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-none -mx-4 px-4">
              {inProgressBooks.map((book) => (
                <BookCard
                  key={book.id}
                  book={book}
                  size="md"
                  showProgress
                  onClick={() => onNavigate('book', book.id)}
                />
              ))}
            </div>
          </section>
        )}

        {/* Continue Listening */}
        {inProgressLessons.length > 0 && (
          <section>
            <SectionHeader
              title="Continue Listening"
              titleAr="متابعة الاستماع"
              onSeeAll={() => onNavigate('lessons')}
            />
            <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-none -mx-4 px-4">
              {inProgressLessons.map((lesson) => (
                <LessonCard
                  key={lesson.id}
                  lesson={lesson}
                  onClick={() => onNavigate('lessons')}
                />
              ))}
            </div>
          </section>
        )}

        {/* Reading Plan */}
        <section>
          <SectionHeader
            title="Reading Plan"
            titleAr="خطة القراءة"
            onSeeAll={() => onNavigate('goals')}
          />
          <div className="bg-white/5 rounded-3xl p-4 border border-white/5">
            <div className="flex items-center gap-4 mb-4">
              <ProgressRing progress={readingPlan.completionPercent} size={72} color="#8b5cf6">
                <div className="text-center">
                  <span className="text-white font-bold text-sm">{readingPlan.completionPercent}%</span>
                </div>
              </ProgressRing>
              <div className="flex-1">
                <h3 className="text-white font-medium text-sm">{readingPlan.name}</h3>
                <p className="text-white/40 text-xs mt-0.5 line-clamp-2">{readingPlan.goal}</p>
                <div className="flex items-center gap-4 mt-2">
                  <div>
                    <span className="text-violet-400 font-bold text-sm">{readingPlan.dailyPages}</span>
                    <span className="text-white/30 text-[10px] ml-1">pages/day</span>
                  </div>
                  <div>
                    <span className="text-emerald-400 font-bold text-sm">{readingPlan.weeklyLessons}</span>
                    <span className="text-white/30 text-[10px] ml-1">lessons/week</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Weekly progress bars */}
            <div className="flex items-end justify-between gap-1.5">
              {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, i) => {
                const val = readingPlan.weeklyProgress[i];
                const pct = Math.min((val / readingPlan.dailyPages) * 100, 100);
                const isToday = i === new Date().getDay();
                return (
                  <div key={`${day}-${i}`} className="flex-1 flex flex-col items-center gap-1">
                    <div className="w-full bg-white/5 rounded-full overflow-hidden" style={{ height: 48 }}>
                      <div
                        className={`w-full rounded-full transition-all duration-500 ${isToday ? 'bg-gradient-to-t from-violet-500 to-violet-400' : 'bg-gradient-to-t from-white/20 to-white/10'}`}
                        style={{ height: `${pct}%`, marginTop: `${100 - pct}%` }}
                      />
                    </div>
                    <span className={`text-[9px] ${isToday ? 'text-violet-400 font-bold' : 'text-white/30'}`}>{day}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Goals */}
        <section>
          <SectionHeader
            title="Goals"
            titleAr="الأهداف"
            onSeeAll={() => onNavigate('goals')}
          />
          <div className="grid grid-cols-2 gap-3">
            {goals.slice(0, 4).map((goal) => {
              const pct = Math.round((goal.current / goal.target) * 100);
              return (
                <div
                  key={goal.id}
                  className="p-3 rounded-2xl border border-white/5 bg-white/5 cursor-pointer hover:bg-white/8 transition-all"
                  onClick={() => onNavigate('goals')}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-lg">{goal.icon}</span>
                    {goal.isCompleted && (
                      <span className="text-[9px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded-full font-bold">DONE</span>
                    )}
                  </div>
                  <h4 className="text-white text-[11px] font-medium leading-tight line-clamp-2 mb-2">
                    {goal.title}
                  </h4>
                  <div className="h-1 bg-white/10 rounded-full overflow-hidden mb-1.5">
                    <div
                      className={`h-full rounded-full bg-gradient-to-r ${goal.color}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[9px]">
                    <span className="text-white/40">{goal.current}/{goal.target}</span>
                    <span className="text-white/60 font-medium">{pct}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Recent Books */}
        <section>
          <SectionHeader
            title="Recent Books"
            titleAr="أحدث الكتب"
            onSeeAll={() => onNavigate('books')}
          />
          <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-none -mx-4 px-4">
            {recentBooks.map((book) => (
              <BookCard
                key={book.id}
                book={book}
                size="sm"
                onClick={() => onNavigate('book', book.id)}
              />
            ))}
          </div>
        </section>

        {/* Recent Lessons */}
        <section>
          <SectionHeader
            title="New Lessons"
            titleAr="أحدث الدروس"
            onSeeAll={() => onNavigate('lessons')}
          />
          <div className="space-y-2">
            {recentLessons.map((lesson) => (
              <LessonCard
                key={lesson.id}
                lesson={lesson}
                variant="compact"
                onClick={() => onNavigate('lessons')}
              />
            ))}
          </div>
        </section>

        {/* Recent Fawaid */}
        <section>
          <SectionHeader
            title="Recent Fawaid"
            titleAr="أحدث الفوائد"
            onSeeAll={() => onNavigate('fawaid')}
          />
          <div className="space-y-3">
            {recentFawaid.map((f) => (
              <FaidahCard key={f.id} faidah={f} onClick={() => onNavigate('fawaid')} />
            ))}
          </div>
        </section>

        {/* Biographies */}
        <section>
          <SectionHeader
            title="Scholars & Biographies"
            titleAr="التراجم والعلماء"
            onSeeAll={() => onNavigate('scholars')}
          />
          <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-none -mx-4 px-4">
            {scholars.map((scholar) => (
              <ScholarCard
                key={scholar.id}
                scholar={scholar}
                variant="compact"
                onClick={() => onNavigate('scholar', scholar.id)}
              />
            ))}
          </div>
        </section>

        {/* Popular */}
        <section>
          <SectionHeader
            title="Most Popular"
            titleAr="الأكثر شيوعًا"
            onSeeAll={() => onNavigate('books')}
          />
          <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-none -mx-4 px-4">
            {popularBooks.map((book) => (
              <BookCard
                key={book.id}
                book={book}
                size="md"
                onClick={() => onNavigate('book', book.id)}
              />
            ))}
          </div>
        </section>

        {/* Categories */}
        <section>
          <SectionHeader
            title="Categories"
            titleAr="التصنيفات"
            showSeeAll={false}
          />
          <div className="grid grid-cols-2 gap-2.5">
            {categories.map((cat) => (
              <button
                key={cat.id}
                className={`relative overflow-hidden rounded-2xl p-4 text-left bg-gradient-to-br ${cat.color} transition-all duration-200 hover:scale-[1.02] hover:shadow-lg`}
                onClick={() => onNavigate('books')}
              >
                <div className="absolute top-0 right-0 w-16 h-16 bg-white/10 rounded-full -translate-y-4 translate-x-4 blur-xl" />
                <div className="text-2xl mb-2">{cat.icon}</div>
                <h3 className="text-white font-semibold text-sm">{cat.name}</h3>
                <p className="text-white/60 text-[10px]" dir="rtl">{cat.nameAr}</p>
                <div className="flex items-center gap-3 mt-2">
                  <span className="text-white/70 text-[10px]">{cat.bookCount} books</span>
                  <span className="text-white/50 text-[10px]">{cat.lessonCount} lessons</span>
                </div>
              </button>
            ))}
          </div>
        </section>

      </div>
    </div>
  );
};
