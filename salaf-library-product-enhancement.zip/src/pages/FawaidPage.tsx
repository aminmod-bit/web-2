import React, { useState } from 'react';
import { Search, Lightbulb, Heart } from 'lucide-react';
import { useStore } from '../store/useStore';
import { TopBar } from '../components/layout/TopBar';
import { FaidahCard } from '../components/ui/FaidahCard';
import { cn } from '../utils/cn';

interface FawaidPageProps {
  onNavigate: (page: string, id?: string) => void;
}

const cats = ['All', 'Spirituality', 'Aqeedah', 'Tazkiyah', 'Worship', 'Quran'];

export const FawaidPage: React.FC<FawaidPageProps> = ({ onNavigate }) => {
  const { fawaid } = useStore();
  const [searchQ, setSearchQ] = useState('');
  const [activeCat, setActiveCat] = useState('All');
  const [showFavOnly, setShowFavOnly] = useState(false);

  const filtered = fawaid.filter((f) => {
    const matchSearch = !searchQ || f.text.toLowerCase().includes(searchQ.toLowerCase()) || f.textAr.includes(searchQ);
    const matchCat = activeCat === 'All' || f.category === activeCat;
    const matchFav = !showFavOnly || f.isFavorite;
    return matchSearch && matchCat && matchFav;
  });

  const favCount = fawaid.filter((f) => f.isFavorite).length;

  return (
    <div className="flex-1 overflow-y-auto pb-24 md:pb-8">
      <TopBar title="Fawaid" titleAr="الفوائد" onNavigate={onNavigate} />

      <div className="px-4 md:px-0 py-4 space-y-4">

        {/* Banner */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-600/20 to-orange-600/10 p-4 border border-amber-500/20">
          <div className="absolute top-0 right-0 text-6xl opacity-10 translate-x-4 -translate-y-2">💡</div>
          <h2 className="text-white font-semibold text-base">Collection of Fawaid</h2>
          <p className="text-white/40 text-xs mt-1">Gems of knowledge from the scholars of Islam</p>
          <div className="flex items-center gap-4 mt-3">
            <div>
              <span className="text-amber-400 font-bold text-lg">{fawaid.length}</span>
              <span className="text-white/30 text-xs ml-1">total</span>
            </div>
            <div>
              <span className="text-rose-400 font-bold text-lg">{favCount}</span>
              <span className="text-white/30 text-xs ml-1">saved</span>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30" />
          <input
            type="text"
            placeholder="Search fawaid..."
            value={searchQ}
            onChange={(e) => setSearchQ(e.target.value)}
            className="w-full bg-white/5 border border-white/5 rounded-2xl pl-10 pr-4 py-2.5 text-white text-sm placeholder-white/25 outline-none focus:border-violet-500/40 transition-all"
          />
        </div>

        {/* Category filter */}
        <div className="flex gap-2 overflow-x-auto scrollbar-none pb-1 -mx-4 px-4">
          {cats.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCat(cat)}
              className={cn(
                'flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-medium transition-all',
                activeCat === cat
                  ? 'bg-amber-500/80 text-white shadow-lg shadow-amber-500/25'
                  : 'bg-white/5 text-white/40 hover:bg-white/10 hover:text-white/70'
              )}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Favorites toggle */}
        <div className="flex items-center justify-between">
          <p className="text-white/30 text-xs">{filtered.length} fawaid</p>
          <button
            onClick={() => setShowFavOnly(!showFavOnly)}
            className={cn(
              'flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all',
              showFavOnly
                ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                : 'bg-white/5 text-white/30 hover:bg-white/10'
            )}
          >
            <Heart size={11} fill={showFavOnly ? 'currentColor' : 'none'} />
            Saved only
          </button>
        </div>

        {/* Fawaid list */}
        <div className="space-y-3">
          {filtered.map((f) => (
            <FaidahCard key={f.id} faidah={f} />
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16">
            <Lightbulb size={40} className="text-white/10 mx-auto mb-3" />
            <p className="text-white/30 text-sm">No fawaid found</p>
          </div>
        )}

      </div>
    </div>
  );
};
