import React, { useState } from 'react';
import { Search, BookOpen, Headphones, Lightbulb } from 'lucide-react';
import { useStore } from '../store/useStore';
import { TopBar } from '../components/layout/TopBar';
import { cn } from '../utils/cn';

interface ScholarsPageProps {
  onNavigate: (page: string, id?: string) => void;
}

const madhhabs = ['All', 'Hanbali', "Shafi'i", 'Maliki', 'Hanafi'];

export const ScholarsPage: React.FC<ScholarsPageProps> = ({ onNavigate }) => {
  const { scholars } = useStore();
  const [searchQ, setSearchQ] = useState('');
  const [activeMadhab, setActiveMadhab] = useState('All');
  const [filter, setFilter] = useState<'all' | 'classical' | 'contemporary'>('all');

  const filtered = scholars.filter((s) => {
    const matchSearch = !searchQ || s.name.toLowerCase().includes(searchQ.toLowerCase()) || s.nameAr.includes(searchQ);
    const matchMadhab = activeMadhab === 'All' || s.madhab === activeMadhab;
    const matchFilter =
      filter === 'all' ||
      (filter === 'classical' && s.isClassical) ||
      (filter === 'contemporary' && !s.isClassical);
    return matchSearch && matchMadhab && matchFilter;
  });

  return (
    <div className="flex-1 overflow-y-auto pb-24 md:pb-8">
      <TopBar title="Scholars" titleAr="العلماء" onNavigate={onNavigate} />

      <div className="px-4 md:px-0 py-4 space-y-4">

        {/* Search */}
        <div className="relative">
          <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30" />
          <input
            type="text"
            placeholder="Search scholars..."
            value={searchQ}
            onChange={(e) => setSearchQ(e.target.value)}
            className="w-full bg-white/5 border border-white/5 rounded-2xl pl-10 pr-4 py-2.5 text-white text-sm placeholder-white/25 outline-none focus:border-violet-500/40 transition-all"
          />
        </div>

        {/* Era filter */}
        <div className="flex gap-2">
          {(['all', 'classical', 'contemporary'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                'px-3 py-1.5 rounded-xl text-xs font-medium capitalize transition-all',
                filter === f
                  ? 'bg-violet-500 text-white'
                  : 'bg-white/5 text-white/40 hover:bg-white/10'
              )}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Madhab filter */}
        <div className="flex gap-2 overflow-x-auto scrollbar-none pb-1">
          {madhhabs.map((m) => (
            <button
              key={m}
              onClick={() => setActiveMadhab(m)}
              className={cn(
                'flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-medium transition-all',
                activeMadhab === m
                  ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                  : 'bg-white/5 text-white/30 hover:text-white/60'
              )}
            >
              {m}
            </button>
          ))}
        </div>

        <p className="text-white/30 text-xs">{filtered.length} scholars</p>

        {/* Scholar cards */}
        <div className="space-y-3">
          {filtered.map((scholar) => (
            <button
              key={scholar.id}
              className="w-full flex items-center gap-4 p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/8 hover:border-white/10 transition-all duration-200 text-left"
              onClick={() => onNavigate('scholar', scholar.id)}
            >
              {/* Avatar */}
              <div className={cn(
                'w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-bold text-white flex-shrink-0',
                'bg-gradient-to-br',
                scholar.avatarColor
              )}>
                {scholar.nameAr.charAt(0)}
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-white font-medium text-sm">{scholar.name}</h3>
                    <p className="text-white/40 text-xs" dir="rtl">{scholar.nameAr}</p>
                  </div>
                  {scholar.isClassical && (
                    <span className="text-[9px] bg-amber-500/15 text-amber-400 border border-amber-500/20 px-1.5 py-0.5 rounded-full font-medium">
                      Classical
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-3 mt-2">
                  <span className="text-white/30 text-[11px]">{scholar.madhab}</span>
                  <span className="text-white/15">·</span>
                  <span className="text-white/30 text-[11px]">{scholar.born}–{scholar.died ?? 'present'}</span>
                  <span className="text-white/15">·</span>
                  <span className="text-white/30 text-[11px]">{scholar.origin}</span>
                </div>
                <div className="flex items-center gap-4 mt-2">
                  <span className="flex items-center gap-1 text-white/30 text-[10px]">
                    <BookOpen size={9} className="text-violet-400" /> {scholar.bookIds.length}
                  </span>
                  <span className="flex items-center gap-1 text-white/30 text-[10px]">
                    <Headphones size={9} className="text-emerald-400" /> {scholar.lessonIds.length}
                  </span>
                  <span className="flex items-center gap-1 text-white/30 text-[10px]">
                    <Lightbulb size={9} className="text-amber-400" /> {scholar.fawaidIds.length}
                  </span>
                </div>
              </div>
            </button>
          ))}
        </div>

      </div>
    </div>
  );
};
