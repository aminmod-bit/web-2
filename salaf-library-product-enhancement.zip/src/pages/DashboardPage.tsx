import React from 'react';
import { BookOpen, Users, Headphones, Lightbulb, TrendingUp, Flame, Trophy, Calendar, BarChart3 } from 'lucide-react';
import { useStore } from '../store/useStore';
import { TopBar } from '../components/layout/TopBar';
import { ProgressRing } from '../components/ui/ProgressRing';
import { cn } from '../utils/cn';

interface DashboardPageProps {
  onNavigate: (page: string, id?: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const { books, scholars, lessons, fawaid, readingPlan, goals, favorites } = useStore();

  const completedGoals = goals.filter((g) => g.isCompleted).length;
  const overallProgress = Math.round(
    goals.reduce((sum, g) => sum + Math.min((g.current / g.target) * 100, 100), 0) / goals.length
  );

  const totalDownloads = books.reduce((sum, b) => sum + b.downloads, 0);

  const recentActivity = [
    { text: 'Started "Kitab al-Tawheed"', time: '2h ago', icon: '📖', color: 'text-violet-400' },
    { text: 'Completed Lesson: "La Ilaha Illallah"', time: '1d ago', icon: '✅', color: 'text-emerald-400' },
    { text: 'Saved 3 fawaid', time: '2d ago', icon: '💡', color: 'text-amber-400' },
    { text: 'Downloaded "Al-Aqeedah al-Wasitiyyah"', time: '3d ago', icon: '⬇️', color: 'text-blue-400' },
    { text: 'Goal reached: 50 lessons!', time: '1w ago', icon: '🏆', color: 'text-yellow-400' },
  ];

  return (
    <div className="flex-1 overflow-y-auto pb-24 md:pb-8">
      <TopBar title="Dashboard" titleAr="لوحة التحكم" onNavigate={onNavigate} />

      <div className="px-4 md:px-0 py-4 space-y-5">

        {/* Hero stats */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-violet-600/25 via-blue-600/15 to-transparent p-5 border border-violet-500/20">
          <div className="absolute top-0 right-0 w-40 h-40 bg-violet-500/10 rounded-full -translate-y-1/2 translate-x-1/4 blur-3xl" />
          <div className="relative flex items-center gap-5">
            <ProgressRing progress={overallProgress} size={80} color="#8b5cf6">
              <div className="text-center">
                <span className="text-white font-bold text-sm">{overallProgress}%</span>
              </div>
            </ProgressRing>
            <div>
              <h2 className="text-white font-bold text-lg">Library Progress</h2>
              <p className="text-white/40 text-xs mt-0.5">Your overall learning journey</p>
              <div className="flex items-center gap-3 mt-2">
                <div className="flex items-center gap-1.5">
                  <Flame size={14} className="text-amber-400 fill-amber-400" />
                  <span className="text-amber-400 font-bold">{readingPlan.currentStreak}</span>
                  <span className="text-white/30 text-xs">streak</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Trophy size={14} className="text-yellow-400" />
                  <span className="text-white font-bold">{completedGoals}</span>
                  <span className="text-white/30 text-xs">goals done</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main stats grid */}
        <div className="grid grid-cols-2 gap-3">
          {[
            {
              label: 'Books',
              labelAr: 'الكتب',
              value: books.length,
              icon: BookOpen,
              color: 'from-violet-500/20 to-violet-600/10',
              border: 'border-violet-500/20',
              textColor: 'text-violet-400',
              onClick: () => onNavigate('books'),
            },
            {
              label: 'Scholars',
              labelAr: 'العلماء',
              value: scholars.length,
              icon: Users,
              color: 'from-emerald-500/20 to-emerald-600/10',
              border: 'border-emerald-500/20',
              textColor: 'text-emerald-400',
              onClick: () => onNavigate('scholars'),
            },
            {
              label: 'Lessons',
              labelAr: 'الدروس',
              value: lessons.length,
              icon: Headphones,
              color: 'from-blue-500/20 to-blue-600/10',
              border: 'border-blue-500/20',
              textColor: 'text-blue-400',
              onClick: () => onNavigate('lessons'),
            },
            {
              label: 'Fawaid',
              labelAr: 'الفوائد',
              value: fawaid.length,
              icon: Lightbulb,
              color: 'from-amber-500/20 to-amber-600/10',
              border: 'border-amber-500/20',
              textColor: 'text-amber-400',
              onClick: () => onNavigate('fawaid'),
            },
          ].map(({ label, labelAr, value, icon: Icon, color, border, textColor, onClick }) => (
            <button
              key={label}
              onClick={onClick}
              className={cn(
                'relative overflow-hidden p-4 rounded-2xl text-left bg-gradient-to-br border transition-all hover:scale-[1.02] active:scale-[0.98]',
                color, border
              )}
            >
              <div className="absolute top-0 right-0 w-12 h-12 bg-white/5 rounded-full -translate-y-4 translate-x-4" />
              <Icon size={20} className={`${textColor} mb-2`} />
              <div className="text-white font-bold text-2xl">{value}</div>
              <div className="text-white/60 text-xs">{label}</div>
              <div className="text-white/30 text-[9px] mt-0.5" dir="rtl">{labelAr}</div>
            </button>
          ))}
        </div>

        {/* Extended stats */}
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: 'Favorites', value: favorites.length, icon: '❤️' },
            { label: 'Pages Read', value: readingPlan.totalPagesRead, icon: '📄' },
            { label: 'Total Downloads', value: `${(totalDownloads / 1000).toFixed(0)}k`, icon: '⬇️' },
          ].map(({ label, value, icon }) => (
            <div key={label} className="p-3 rounded-2xl bg-white/5 border border-white/5 text-center">
              <div className="text-lg mb-1">{icon}</div>
              <div className="text-white font-bold text-sm">{value}</div>
              <div className="text-white/30 text-[9px]">{label}</div>
            </div>
          ))}
        </div>

        {/* Library completion */}
        <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
          <h3 className="text-white font-semibold text-sm mb-3 flex items-center gap-2">
            <BarChart3 size={14} className="text-violet-400" /> Library Completion
          </h3>
          <div className="space-y-3">
            {[
              { label: 'Books collected', current: books.length, target: 50, color: 'from-violet-500 to-violet-400' },
              { label: 'Scholars catalogued', current: scholars.length, target: 20, color: 'from-emerald-500 to-emerald-400' },
              { label: 'Lessons recorded', current: lessons.length, target: 30, color: 'from-blue-500 to-blue-400' },
              { label: 'Fawaid collected', current: fawaid.length, target: 50, color: 'from-amber-500 to-amber-400' },
            ].map(({ label, current, target, color }) => {
              const pct = Math.round((current / target) * 100);
              return (
                <div key={label}>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-white/50">{label}</span>
                    <span className="text-white/60">{current} / {target}</span>
                  </div>
                  <div className="h-2 bg-white/8 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full bg-gradient-to-r ${color} transition-all duration-700`}
                      style={{ width: `${Math.min(pct, 100)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Weekly reading chart */}
        <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
          <h3 className="text-white font-semibold text-sm mb-3 flex items-center gap-2">
            <TrendingUp size={14} className="text-emerald-400" /> Weekly Reading
          </h3>
          <div className="flex items-end gap-2" style={{ height: 80 }}>
            {readingPlan.weeklyProgress.map((val, i) => {
              const pct = Math.min((val / readingPlan.dailyPages) * 100, 100);
              const isToday = i === new Date().getDay();
              const days = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
              return (
                <div key={i} className="flex-1 flex flex-col items-center gap-1">
                  <div className="flex-1 w-full bg-white/8 rounded-lg overflow-hidden relative">
                    <div
                      className={cn(
                        'absolute bottom-0 left-0 right-0 rounded-lg transition-all duration-700',
                        isToday
                          ? 'bg-gradient-to-t from-violet-600 to-violet-400'
                          : pct >= 100
                          ? 'bg-gradient-to-t from-emerald-600 to-emerald-400'
                          : 'bg-gradient-to-t from-white/25 to-white/10'
                      )}
                      style={{ height: `${pct}%` }}
                    />
                  </div>
                  <span className={cn('text-[9px]', isToday ? 'text-violet-400 font-bold' : 'text-white/30')}>
                    {days[i]}
                  </span>
                </div>
              );
            })}
          </div>
          <div className="flex items-center justify-between mt-2 text-[10px]">
            <span className="text-white/30">Target: {readingPlan.dailyPages} pages/day</span>
            <span className="text-emerald-400">
              {readingPlan.weeklyProgress.reduce((s, v) => s + v, 0)} pages this week
            </span>
          </div>
        </div>

        {/* Recent activity */}
        <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
          <h3 className="text-white font-semibold text-sm mb-3 flex items-center gap-2">
            <Calendar size={14} className="text-blue-400" /> Recent Activity
          </h3>
          <div className="space-y-3">
            {recentActivity.map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <span className="text-base flex-shrink-0">{item.icon}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-white/70 text-xs">{item.text}</p>
                  <p className="text-white/30 text-[10px] mt-0.5">{item.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick links */}
        <div>
          <h3 className="text-white/50 text-xs font-medium uppercase tracking-wider mb-3">Quick Navigation</h3>
          <div className="grid grid-cols-2 gap-2">
            {[
              { label: 'Browse Books', icon: BookOpen, page: 'books', color: 'text-violet-400' },
              { label: 'View Scholars', icon: Users, page: 'scholars', color: 'text-emerald-400' },
              { label: 'Listen Lessons', icon: Headphones, page: 'lessons', color: 'text-blue-400' },
              { label: 'Read Fawaid', icon: Lightbulb, page: 'fawaid', color: 'text-amber-400' },
            ].map(({ label, icon: Icon, page, color }) => (
              <button
                key={page}
                onClick={() => onNavigate(page)}
                className="flex items-center gap-2.5 p-3 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/8 transition-all text-left"
              >
                <Icon size={16} className={color} />
                <span className="text-white/60 text-xs">{label}</span>
              </button>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
