import React, { useState } from 'react';
import { Search, Headphones, Clock, Eye } from 'lucide-react';
import { useStore } from '../store/useStore';
import { TopBar } from '../components/layout/TopBar';
import { LessonCard } from '../components/ui/LessonCard';
import { cn } from '../utils/cn';

interface LessonsPageProps {
  onNavigate: (page: string, id?: string) => void;
}

export const LessonsPage: React.FC<LessonsPageProps> = ({ onNavigate }) => {
  const { lessons } = useStore();
  const [searchQ, setSearchQ] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [viewMode, setViewMode] = useState<'cards' | 'list'>('list');

  const filtered = lessons.filter((l) => {
    const matchSearch = !searchQ || l.title.toLowerCase().includes(searchQ.toLowerCase());
    const matchCat = activeCategory === 'All' || l.category === activeCategory;
    return matchSearch && matchCat;
  });

  const totalDuration = lessons.reduce((sum, l) => sum + l.durationSeconds, 0);
  const formatTotalDuration = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return `${h}h ${m}m`;
  };

  return (
    <div className="flex-1 overflow-y-auto pb-24 md:pb-8">
      <TopBar title="Lessons" titleAr="الدروس" onNavigate={onNavigate} />

      <div className="px-4 md:px-0 py-4 space-y-4">

        {/* Stats banner */}
        <div className="flex gap-3">
          {[
            { label: 'Total Lessons', value: lessons.length, icon: Headphones },
            { label: 'Total Duration', value: formatTotalDuration(totalDuration), icon: Clock },
            { label: 'Views', value: `${(lessons.reduce((s, l) => s + l.views, 0) / 1000).toFixed(0)}k`, icon: Eye },
          ].map(({ label, value, icon: Icon }) => (
            <div key={label} className="flex-1 p-3 rounded-2xl bg-white/5 border border-white/5 text-center">
              <Icon size={14} className="text-white/30 mx-auto mb-1" />
              <div className="text-white font-bold text-sm">{value}</div>
              <div className="text-white/30 text-[9px]">{label}</div>
            </div>
          ))}
        </div>

        {/* Search */}
        <div className="relative">
          <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30" />
          <input
            type="text"
            placeholder="Search lessons..."
            value={searchQ}
            onChange={(e) => setSearchQ(e.target.value)}
            className="w-full bg-white/5 border border-white/5 rounded-2xl pl-10 pr-4 py-2.5 text-white text-sm placeholder-white/25 outline-none focus:border-violet-500/40 transition-all"
          />
        </div>

        {/* Category filter */}
        <div className="flex gap-2 overflow-x-auto scrollbar-none pb-1 -mx-4 px-4">
          {['All', 'Aqeedah', 'Tawheed', 'Hadith', 'Fiqh', 'Spirituality'].map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={cn(
                'flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-medium transition-all',
                activeCategory === cat
                  ? 'bg-violet-500 text-white shadow-lg shadow-violet-500/25'
                  : 'bg-white/5 text-white/40 hover:bg-white/10 hover:text-white/70'
              )}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Toggle view */}
        <div className="flex items-center justify-between">
          <p className="text-white/30 text-xs">{filtered.length} lessons</p>
          <div className="flex gap-1.5">
            {(['list', 'cards'] as const).map((m) => (
              <button
                key={m}
                onClick={() => setViewMode(m)}
                className={cn(
                  'px-2.5 py-1 rounded-lg text-[10px] capitalize transition-all',
                  viewMode === m ? 'bg-white/15 text-white' : 'bg-white/5 text-white/30'
                )}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        {/* Lessons */}
        {viewMode === 'list' ? (
          <div className="space-y-2">
            {filtered.map((lesson) => (
              <LessonCard
                key={lesson.id}
                lesson={lesson}
                variant="compact"
                onClick={() => onNavigate('lessons')}
              />
            ))}
          </div>
        ) : (
          <div className="flex gap-4 flex-wrap">
            {filtered.map((lesson) => (
              <LessonCard
                key={lesson.id}
                lesson={lesson}
                variant="horizontal"
                onClick={() => onNavigate('lessons')}
              />
            ))}
          </div>
        )}

        {filtered.length === 0 && (
          <div className="text-center py-16">
            <Headphones size={40} className="text-white/10 mx-auto mb-3" />
            <p className="text-white/30 text-sm">No lessons found</p>
          </div>
        )}

      </div>
    </div>
  );
};
