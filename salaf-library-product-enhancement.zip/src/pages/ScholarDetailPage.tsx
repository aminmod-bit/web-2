import React, { useState } from 'react';
import { ArrowLeft, MapPin, Calendar, BookOpen, Headphones, Lightbulb, ExternalLink } from 'lucide-react';
import { useStore } from '../store/useStore';
import { BookCard } from '../components/ui/BookCard';
import { LessonCard } from '../components/ui/LessonCard';
import { FaidahCard } from '../components/ui/FaidahCard';
import { cn } from '../utils/cn';

interface ScholarDetailPageProps {
  scholarId: string;
  onNavigate: (page: string, id?: string) => void;
}

type Tab = 'bio' | 'books' | 'lessons' | 'fawaid';

export const ScholarDetailPage: React.FC<ScholarDetailPageProps> = ({ scholarId, onNavigate }) => {
  const { scholars, books, lessons, fawaid } = useStore();
  const [activeTab, setActiveTab] = useState<Tab>('bio');

  const scholar = scholars.find((s) => s.id === scholarId);
  if (!scholar) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <p className="text-white/40">Scholar not found</p>
      </div>
    );
  }

  const scholarBooks = books.filter((b) => scholar.bookIds.includes(b.id));
  const scholarLessons = lessons.filter((l) => scholar.lessonIds.includes(l.id));
  const scholarFawaid = fawaid.filter((f) => scholar.fawaidIds.includes(f.id));
  const relatedScholars = scholars.filter((s) => scholar.relatedScholarIds.includes(s.id));

  const tabs: { id: Tab; label: string; count: number; icon: typeof BookOpen }[] = [
    { id: 'bio', label: 'Biography', count: 0, icon: ExternalLink },
    { id: 'books', label: 'Books', count: scholarBooks.length, icon: BookOpen },
    { id: 'lessons', label: 'Lessons', count: scholarLessons.length, icon: Headphones },
    { id: 'fawaid', label: 'Fawaid', count: scholarFawaid.length, icon: Lightbulb },
  ];

  return (
    <div className="flex-1 overflow-y-auto pb-24 md:pb-8">
      {/* Header */}
      <div className={cn(
        'relative h-48 bg-gradient-to-br overflow-hidden',
        scholar.avatarColor
      )}>
        <div className="absolute inset-0 bg-black/30" />
        <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 rounded-full -translate-y-1/4 translate-x-1/4 blur-2xl" />

        <button
          onClick={() => onNavigate('scholars')}
          className="absolute top-4 left-4 p-2 rounded-xl bg-black/30 backdrop-blur-sm text-white hover:bg-black/50 transition-colors z-10"
          aria-label="Go back"
        >
          <ArrowLeft size={18} />
        </button>

        <div className="absolute bottom-6 left-4 right-4 flex items-end gap-4">
          <div className={cn(
            'w-20 h-20 rounded-2xl flex items-center justify-center text-3xl font-bold text-white',
            'bg-white/20 backdrop-blur-sm border border-white/20 shadow-xl'
          )}>
            {scholar.nameAr.charAt(0)}
          </div>
          <div>
            <h1 className="text-white font-bold text-xl">{scholar.name}</h1>
            <p className="text-white/70 text-sm" dir="rtl">{scholar.nameAr}</p>
            {scholar.isClassical && (
              <span className="text-[9px] bg-amber-500/20 text-amber-300 border border-amber-400/30 px-2 py-0.5 rounded-full font-medium mt-1 inline-block">
                Classical Scholar
              </span>
            )}
          </div>
        </div>
      </div>

      <div className="px-4 md:px-0 py-4 space-y-5">

        {/* Quick info */}
        <div className="flex flex-wrap gap-3">
          <span className="flex items-center gap-1.5 text-white/50 text-xs">
            <Calendar size={12} className="text-violet-400" />
            {scholar.born}–{scholar.died ?? 'present'}
          </span>
          <span className="flex items-center gap-1.5 text-white/50 text-xs">
            <MapPin size={12} className="text-rose-400" />
            {scholar.origin}
          </span>
          <span className="text-white/50 text-xs bg-white/5 px-2.5 py-0.5 rounded-full border border-white/10">
            {scholar.madhab}
          </span>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: 'Books', value: scholarBooks.length, icon: BookOpen, color: 'text-violet-400' },
            { label: 'Lessons', value: scholarLessons.length, icon: Headphones, color: 'text-emerald-400' },
            { label: 'Fawaid', value: scholarFawaid.length, icon: Lightbulb, color: 'text-amber-400' },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="text-center p-3 rounded-2xl bg-white/5 border border-white/5">
              <Icon size={16} className={`${color} mx-auto mb-1`} />
              <div className="text-white font-bold text-lg">{value}</div>
              <div className="text-white/30 text-[10px]">{label}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-1.5 overflow-x-auto scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  'flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium transition-all',
                  activeTab === tab.id
                    ? 'bg-violet-500/20 text-violet-400 border border-violet-500/30'
                    : 'bg-white/5 text-white/40 hover:bg-white/8 hover:text-white/60'
                )}
              >
                <Icon size={12} />
                {tab.label}
                {tab.count > 0 && (
                  <span className={cn(
                    'text-[9px] px-1 py-0.5 rounded-full',
                    activeTab === tab.id ? 'bg-violet-500/30 text-violet-300' : 'bg-white/10 text-white/40'
                  )}>
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Tab content */}
        {activeTab === 'bio' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
              <h3 className="text-white font-medium text-sm mb-2">Biography</h3>
              <p className="text-white/60 text-sm leading-relaxed">{scholar.bio}</p>
            </div>
            <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
              <p className="text-white/70 text-sm leading-relaxed text-right" dir="rtl">{scholar.bioAr}</p>
            </div>

            {/* Related scholars */}
            {relatedScholars.length > 0 && (
              <div>
                <h3 className="text-white font-medium text-sm mb-3">Related Scholars</h3>
                <div className="space-y-2">
                  {relatedScholars.map((s) => (
                    <button
                      key={s.id}
                      className="w-full flex items-center gap-3 p-3 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/8 transition-all text-left"
                      onClick={() => onNavigate('scholar', s.id)}
                    >
                      <div className={cn(
                        'w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold text-white flex-shrink-0',
                        'bg-gradient-to-br',
                        s.avatarColor
                      )}>
                        {s.nameAr.charAt(0)}
                      </div>
                      <div>
                        <p className="text-white text-sm font-medium">{s.name}</p>
                        <p className="text-white/30 text-[11px]">{s.madhab} · {s.born}–{s.died}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'books' && (
          <div className="grid grid-cols-3 gap-x-3 gap-y-5">
            {scholarBooks.map((book) => (
              <BookCard
                key={book.id}
                book={book}
                size="sm"
                onClick={() => onNavigate('book', book.id)}
              />
            ))}
          </div>
        )}

        {activeTab === 'lessons' && (
          <div className="space-y-2">
            {scholarLessons.map((lesson) => (
              <LessonCard
                key={lesson.id}
                lesson={lesson}
                variant="compact"
                onClick={() => onNavigate('lessons')}
              />
            ))}
          </div>
        )}

        {activeTab === 'fawaid' && (
          <div className="space-y-3">
            {scholarFawaid.map((f) => (
              <FaidahCard key={f.id} faidah={f} onClick={() => onNavigate('fawaid')} />
            ))}
          </div>
        )}

      </div>
    </div>
  );
};
