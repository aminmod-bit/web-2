import React, { useState } from 'react';
import { Search, BookOpen } from 'lucide-react';
import { useStore } from '../store/useStore';
import { TopBar } from '../components/layout/TopBar';
import { BookCard } from '../components/ui/BookCard';
import { cn } from '../utils/cn';

interface BooksPageProps {
  onNavigate: (page: string, id?: string) => void;
}

const languages = ['All', 'ar', 'en', 'ur'];
const sortOptions = ['Popular', 'Newest', 'Rating', 'Pages'];

export const BooksPage: React.FC<BooksPageProps> = ({ onNavigate }) => {
  const { books, categories } = useStore();
  const [activeCategory, setActiveCategory] = useState('All');
  const [activeLang, setActiveLang] = useState('All');
  const [sortBy, setSortBy] = useState('Popular');
  const [searchQ, setSearchQ] = useState('');


  const filtered = books
    .filter((b) => {
      const matchCat = activeCategory === 'All' || b.category === activeCategory;
      const matchLang = activeLang === 'All' || b.language === activeLang;
      const matchSearch = !searchQ || b.title.toLowerCase().includes(searchQ.toLowerCase()) || b.author.toLowerCase().includes(searchQ.toLowerCase());
      return matchCat && matchLang && matchSearch;
    })
    .sort((a, b) => {
      if (sortBy === 'Popular') return b.downloads - a.downloads;
      if (sortBy === 'Rating') return b.rating - a.rating;
      if (sortBy === 'Newest') return b.year - a.year;
      if (sortBy === 'Pages') return b.pages - a.pages;
      return 0;
    });

  return (
    <div className="flex-1 overflow-y-auto pb-24 md:pb-8">
      <TopBar title="Books" titleAr="الكتب" onNavigate={onNavigate} />

      <div className="px-4 md:px-0 py-4 space-y-4">

        {/* Search bar */}
        <div className="relative">
          <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30" />
          <input
            type="text"
            placeholder="Search books, authors..."
            value={searchQ}
            onChange={(e) => setSearchQ(e.target.value)}
            className="w-full bg-white/5 border border-white/5 rounded-2xl pl-10 pr-4 py-2.5 text-white text-sm placeholder-white/25 outline-none focus:border-violet-500/40 focus:bg-white/8 transition-all"
          />
        </div>

        {/* Category filter */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none -mx-4 px-4">
          {['All', ...categories.map((c) => c.name)].map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={cn(
                'flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-medium transition-all duration-200',
                activeCategory === cat
                  ? 'bg-violet-500 text-white shadow-lg shadow-violet-500/25'
                  : 'bg-white/5 text-white/40 hover:bg-white/10 hover:text-white/70'
              )}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Sort & filters row */}
        <div className="flex items-center justify-between">
          <div className="flex gap-1.5">
            {languages.map((lang) => (
              <button
                key={lang}
                onClick={() => setActiveLang(lang)}
                className={cn(
                  'px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all duration-200 uppercase',
                  activeLang === lang
                    ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                    : 'bg-white/5 text-white/30 hover:text-white/60'
                )}
              >
                {lang}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="bg-white/5 text-white/60 text-[11px] rounded-xl px-2.5 py-1.5 border border-white/5 outline-none cursor-pointer"
            >
              {sortOptions.map((opt) => (
                <option key={opt} value={opt} className="bg-[#1a1a2e]">{opt}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Results count */}
        <p className="text-white/30 text-xs">{filtered.length} books found</p>

        {/* Books grid */}
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-x-3 gap-y-6">
          {filtered.map((book) => (
            <BookCard
              key={book.id}
              book={book}
              size="sm"
              showProgress
              onClick={() => onNavigate('book', book.id)}
            />
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16">
            <BookOpen size={40} className="text-white/10 mx-auto mb-3" />
            <p className="text-white/30 text-sm">No books found</p>
            <button
              className="text-violet-400 text-xs mt-2"
              onClick={() => { setSearchQ(''); setActiveCategory('All'); setActiveLang('All'); }}
            >
              Clear filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
