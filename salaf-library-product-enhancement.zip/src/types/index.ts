export interface Book {
  id: string;
  title: string;
  titleAr: string;
  author: string;
  authorId: string;
  category: string;
  categoryId: string;
  language: 'ar' | 'en' | 'ur' | 'fr';
  pages: number;
  size: string;
  description: string;
  descriptionAr: string;
  coverColor: string;
  coverGradient: string;
  year: number;
  downloads: number;
  rating: number;
  tags: string[];
  relatedBooks: string[];
  isNew?: boolean;
  isFeatured?: boolean;
  progress?: number;
}

export interface Scholar {
  id: string;
  name: string;
  nameAr: string;
  born: string;
  died?: string;
  origin: string;
  madhab: string;
  bio: string;
  bioAr: string;
  bookIds: string[];
  lessonIds: string[];
  fawaidIds: string[];
  relatedScholarIds: string[];
  avatarColor: string;
  isClassical?: boolean;
}

export interface Lesson {
  id: string;
  title: string;
  titleAr: string;
  scholarId: string;
  duration: string;
  durationSeconds: number;
  category: string;
  description: string;
  audioUrl?: string;
  date: string;
  views: number;
  progress?: number;
  isNew?: boolean;
}

export interface Faidah {
  id: string;
  text: string;
  textAr: string;
  source: string;
  scholarId: string;
  category: string;
  tags: string[];
  date: string;
  isFavorite?: boolean;
}

export interface Category {
  id: string;
  name: string;
  nameAr: string;
  icon: string;
  color: string;
  bookCount: number;
  lessonCount: number;
}

export interface ReadingPlan {
  id: string;
  name: string;
  dailyPages: number;
  weeklyLessons: number;
  currentStreak: number;
  longestStreak: number;
  totalPagesRead: number;
  totalLessonsCompleted: number;
  startDate: string;
  goal: string;
  weeklyProgress: number[];
  completionPercent: number;
}

export interface Goal {
  id: string;
  title: string;
  titleAr: string;
  description: string;
  type: 'books' | 'pages' | 'lessons' | 'fawaid';
  target: number;
  current: number;
  deadline: string;
  startDate: string;
  color: string;
  icon: string;
  isCompleted: boolean;
  history: { date: string; value: number }[];
}

export interface NavItem {
  id: string;
  label: string;
  labelAr: string;
  icon: string;
  path: string;
}
