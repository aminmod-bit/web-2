import { useState, useCallback } from 'react';
import { BottomNav, SideNav } from './components/layout/BottomNav';
import { HomePage } from './pages/HomePage';
import { BooksPage } from './pages/BooksPage';
import { BookDetailPage } from './pages/BookDetailPage';
import { ScholarsPage } from './pages/ScholarsPage';
import { ScholarDetailPage } from './pages/ScholarDetailPage';
import { LessonsPage } from './pages/LessonsPage';
import { FawaidPage } from './pages/FawaidPage';
import { GoalsPage } from './pages/GoalsPage';
import { SearchPage } from './pages/SearchPage';
import { DashboardPage } from './pages/DashboardPage';

type Page =
  | 'home'
  | 'books'
  | 'book'
  | 'scholars'
  | 'scholar'
  | 'lessons'
  | 'fawaid'
  | 'goals'
  | 'search'
  | 'dashboard';

interface NavState {
  page: Page;
  id?: string;
}

export default function App() {
  const [nav, setNav] = useState<NavState>({ page: 'home' });

  const handleNavigate = useCallback((page: string, id?: string) => {
    setNav({ page: page as Page, id });
    // Scroll to top on page change
    window.scrollTo(0, 0);
  }, []);

  const renderPage = () => {
    switch (nav.page) {
      case 'home':
        return <HomePage onNavigate={handleNavigate} />;
      case 'books':
        return <BooksPage onNavigate={handleNavigate} />;
      case 'book':
        return nav.id ? (
          <BookDetailPage bookId={nav.id} onNavigate={handleNavigate} />
        ) : (
          <BooksPage onNavigate={handleNavigate} />
        );
      case 'scholars':
        return <ScholarsPage onNavigate={handleNavigate} />;
      case 'scholar':
        return nav.id ? (
          <ScholarDetailPage scholarId={nav.id} onNavigate={handleNavigate} />
        ) : (
          <ScholarsPage onNavigate={handleNavigate} />
        );
      case 'lessons':
        return <LessonsPage onNavigate={handleNavigate} />;
      case 'fawaid':
        return <FawaidPage onNavigate={handleNavigate} />;
      case 'goals':
        return <GoalsPage onNavigate={handleNavigate} />;
      case 'search':
        return <SearchPage onNavigate={handleNavigate} />;
      case 'dashboard':
        return <DashboardPage onNavigate={handleNavigate} />;
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  const activePage = ['book', 'scholar'].includes(nav.page)
    ? nav.page === 'book' ? 'books' : 'scholars'
    : nav.page;

  return (
    <div className="min-h-screen bg-[#0f0f14] text-white flex">
      {/* Sidebar for desktop */}
      <SideNav
        activePage={activePage}
        onNavigate={handleNavigate}
      />

      {/* Main content */}
      <main className="flex-1 flex flex-col md:ml-56 min-h-screen">
        <div className="flex-1 flex flex-col max-w-2xl w-full mx-auto md:px-6">
          {renderPage()}
        </div>
      </main>

      {/* Bottom nav for mobile */}
      <BottomNav
        activePage={activePage}
        onNavigate={handleNavigate}
      />
    </div>
  );
}
