import React from 'react';
import { GoldDivider } from './GoldDivider';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

const navItems = [
  {
    id: 'home',
    label: 'الرئيسية',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-5 h-5">
        <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" strokeLinecap="round" strokeLinejoin="round" />
        <polyline points="9 22 9 12 15 12 15 22" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    id: 'books',
    label: 'الكتب',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-5 h-5">
        <path d="M4 19.5A2.5 2.5 0 016.5 17H20" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    id: 'scholars',
    label: 'التراجم',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-5 h-5">
        <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="12" cy="7" r="4" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    id: 'audio',
    label: 'المقاطع الصوتية',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-5 h-5">
        <path d="M9 18V5l12-2v13" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="6" cy="18" r="3" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="18" cy="16" r="3" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    id: 'fawaid',
    label: 'الفوائد',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-5 h-5">
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    id: 'search',
    label: 'البحث',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-5 h-5">
        <circle cx="11" cy="11" r="8" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M21 21l-4.35-4.35" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
];

const bottomItems = [
  {
    id: 'dashboard',
    label: 'لوحة التحكم',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-5 h-5">
        <rect x="3" y="3" width="7" height="7" rx="1" strokeLinecap="round" strokeLinejoin="round" />
        <rect x="14" y="3" width="7" height="7" rx="1" strokeLinecap="round" strokeLinejoin="round" />
        <rect x="3" y="14" width="7" height="7" rx="1" strokeLinecap="round" strokeLinejoin="round" />
        <rect x="14" y="14" width="7" height="7" rx="1" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    id: 'admin',
    label: 'الإدارة',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-5 h-5">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
];

export const Sidebar: React.FC<SidebarProps> = ({ currentPage, onNavigate, isOpen, onClose }) => {
  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 right-0 h-full w-72 z-50 glass flex flex-col transform transition-transform duration-300 ease-in-out
          ${isOpen ? 'translate-x-0' : 'translate-x-full'}
          lg:translate-x-0 lg:static lg:h-screen`}
        style={{
          background: 'linear-gradient(180deg, rgba(4, 20, 12, 0.98) 0%, rgba(6, 24, 15, 0.98) 100%)',
          borderLeft: '1px solid rgba(212, 175, 55, 0.12)',
        }}
      >
        {/* Logo */}
        <div className="p-6 relative overflow-hidden">
          <div className="absolute inset-0 opacity-5">
            <div className="absolute top-0 left-0 w-32 h-32 bg-amber-400 rounded-full blur-3xl" />
          </div>
          <div className="relative flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl flex items-center justify-center animate-glow"
              style={{
                background: 'linear-gradient(135deg, #d4af37, #b8962e)',
                boxShadow: '0 4px 20px rgba(212, 175, 55, 0.4)',
              }}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2} className="w-6 h-6">
                <path d="M4 19.5A2.5 2.5 0 016.5 17H20" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <div>
              <h1 className="text-amber-300 font-bold text-lg leading-tight" style={{ fontFamily: 'Cairo, sans-serif' }}>
                مكتبة السلف
              </h1>
              <p className="text-emerald-400/60 text-xs font-medium tracking-wider">SALAF LIBRARY</p>
            </div>
          </div>
        </div>

        <GoldDivider />

        {/* Search bar */}
        <div className="px-4 py-3">
          <div className="relative">
            <input
              type="text"
              placeholder="ابحث في المكتبة..."
              className="w-full input-premium rounded-xl px-4 py-2.5 text-sm pr-10"
              style={{ fontFamily: 'Cairo, sans-serif' }}
            />
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-4 h-4 text-amber-400/50 absolute right-3 top-1/2 -translate-y-1/2">
              <circle cx="11" cy="11" r="8" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M21 21l-4.35-4.35" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-2 overflow-y-auto">
          <p className="text-xs text-amber-400/40 font-semibold tracking-widest uppercase px-3 mb-3" style={{ fontFamily: 'Cairo, sans-serif' }}>
            القائمة الرئيسية
          </p>
          <ul className="space-y-1">
            {navItems.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => { onNavigate(item.id); onClose(); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 text-right
                    ${currentPage === item.id
                      ? 'sidebar-item-active'
                      : 'text-emerald-100/60 hover:text-emerald-100 hover:bg-white/5'
                    }`}
                  style={{ fontFamily: 'Cairo, sans-serif' }}
                >
                  <span className={currentPage === item.id ? 'text-amber-400' : 'text-emerald-400/50'}>
                    {item.icon}
                  </span>
                  <span>{item.label}</span>
                  {currentPage === item.id && (
                    <span className="mr-auto w-1.5 h-1.5 rounded-full bg-amber-400" />
                  )}
                </button>
              </li>
            ))}
          </ul>

          <div className="my-4">
            <GoldDivider withIcon />
          </div>

          <p className="text-xs text-amber-400/40 font-semibold tracking-widest uppercase px-3 mb-3" style={{ fontFamily: 'Cairo, sans-serif' }}>
            الإدارة
          </p>
          <ul className="space-y-1">
            {bottomItems.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => { onNavigate(item.id); onClose(); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 text-right
                    ${currentPage === item.id
                      ? 'sidebar-item-active'
                      : 'text-emerald-100/60 hover:text-emerald-100 hover:bg-white/5'
                    }`}
                  style={{ fontFamily: 'Cairo, sans-serif' }}
                >
                  <span className={currentPage === item.id ? 'text-amber-400' : 'text-emerald-400/50'}>
                    {item.icon}
                  </span>
                  <span>{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>

        <GoldDivider />

        {/* User profile */}
        <div className="p-4">
          <div className="flex items-center gap-3 p-3 rounded-xl glass-light cursor-pointer hover:bg-white/5 transition-all">
            <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold"
              style={{ background: 'linear-gradient(135deg, #166534, #14532d)', color: '#d4af37' }}>
              م
            </div>
            <div className="flex-1 text-right">
              <p className="text-emerald-100 text-sm font-semibold" style={{ fontFamily: 'Cairo, sans-serif' }}>محمد أحمد</p>
              <p className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo, sans-serif' }}>مدير المكتبة</p>
            </div>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-4 h-4 text-amber-400/40 rotate-180">
              <polyline points="9 18 15 12 9 6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        </div>
      </aside>
    </>
  );
};
