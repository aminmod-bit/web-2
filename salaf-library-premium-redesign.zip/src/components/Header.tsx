import React, { useState } from 'react';

interface HeaderProps {
  currentPage: string;
  onMenuToggle: () => void;
  onNavigate: (page: string) => void;
}

const pageTitles: Record<string, { ar: string; en: string }> = {
  home: { ar: 'الرئيسية', en: 'Home' },
  books: { ar: 'الكتب والمخطوطات', en: 'Books & Manuscripts' },
  scholars: { ar: 'تراجم العلماء', en: 'Scholars\' Biographies' },
  audio: { ar: 'المقاطع الصوتية', en: 'Audio Library' },
  fawaid: { ar: 'الفوائد والدرر', en: 'Fawaid & Pearls' },
  search: { ar: 'البحث الشامل', en: 'Advanced Search' },
  dashboard: { ar: 'لوحة التحكم', en: 'Dashboard' },
  admin: { ar: 'إدارة المكتبة', en: 'Library Administration' },
};

export const Header: React.FC<HeaderProps> = ({ currentPage, onMenuToggle, onNavigate }) => {
  const [notifOpen, setNotifOpen] = useState(false);
  const pageInfo = pageTitles[currentPage] || pageTitles.home;

  return (
    <header
      className="sticky top-0 z-30 h-16 flex items-center px-4 lg:px-6 gap-4"
      style={{
        background: 'rgba(5, 18, 11, 0.9)',
        backdropFilter: 'blur(20px)',
        borderBottom: '1px solid rgba(212, 175, 55, 0.1)',
        boxShadow: '0 4px 30px rgba(0,0,0,0.3)',
      }}
    >
      {/* Mobile menu button */}
      <button
        onClick={onMenuToggle}
        className="lg:hidden w-9 h-9 flex items-center justify-center rounded-xl text-amber-400/70 hover:text-amber-400 hover:bg-white/5 transition-all"
      >
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-5 h-5">
          <line x1="3" y1="6" x2="21" y2="6" strokeLinecap="round" />
          <line x1="3" y1="12" x2="21" y2="12" strokeLinecap="round" />
          <line x1="3" y1="18" x2="21" y2="18" strokeLinecap="round" />
        </svg>
      </button>

      {/* Breadcrumb */}
      <div className="flex items-center gap-2 flex-1">
        <div>
          <h2 className="text-emerald-100 font-semibold text-base" style={{ fontFamily: 'Cairo, sans-serif' }}>
            {pageInfo.ar}
          </h2>
          <p className="text-emerald-400/40 text-xs tracking-wider">{pageInfo.en}</p>
        </div>
      </div>

      {/* Right actions */}
      <div className="flex items-center gap-2">
        {/* Search */}
        <button
          onClick={() => onNavigate('search')}
          className="w-9 h-9 flex items-center justify-center rounded-xl text-emerald-400/60 hover:text-amber-400 hover:bg-white/5 transition-all"
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-5 h-5">
            <circle cx="11" cy="11" r="8" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M21 21l-4.35-4.35" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setNotifOpen(!notifOpen)}
            className="w-9 h-9 flex items-center justify-center rounded-xl text-emerald-400/60 hover:text-amber-400 hover:bg-white/5 transition-all relative"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-5 h-5">
              <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M13.73 21a2 2 0 01-3.46 0" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span className="absolute top-1.5 left-1.5 w-2 h-2 bg-amber-400 rounded-full" style={{ boxShadow: '0 0 6px rgba(212,175,55,0.8)' }} />
          </button>

          {notifOpen && (
            <div
              className="absolute left-0 top-12 w-72 rounded-2xl p-4 z-50"
              style={{
                background: 'rgba(4, 20, 12, 0.98)',
                border: '1px solid rgba(212, 175, 55, 0.15)',
                boxShadow: '0 20px 60px rgba(0,0,0,0.6)',
                backdropFilter: 'blur(20px)',
              }}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-amber-400 text-xs font-bold tracking-wider uppercase" style={{ fontFamily: 'Cairo' }}>الإشعارات</span>
                <span className="badge-gold text-xs px-2 py-0.5 rounded-full">3 جديد</span>
              </div>
              {[
                { text: 'تمت إضافة كتاب جديد: صحيح الجامع', time: 'منذ 5 دقائق' },
                { text: 'تم رفع محاضرة جديدة للشيخ الفوزان', time: 'منذ 2 ساعة' },
                { text: 'تحديث جديد في قسم الفوائد', time: 'منذ يوم' },
              ].map((n, i) => (
                <div key={i} className="py-2.5 border-b border-white/5 last:border-0">
                  <p className="text-emerald-100/80 text-xs mb-1" style={{ fontFamily: 'Cairo' }}>{n.text}</p>
                  <p className="text-emerald-400/40 text-xs" style={{ fontFamily: 'Cairo' }}>{n.time}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Divider */}
        <div className="w-px h-6 gold-divider-v mx-1" />

        {/* User avatar */}
        <button className="flex items-center gap-2 px-3 py-1.5 rounded-xl hover:bg-white/5 transition-all">
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
            style={{ background: 'linear-gradient(135deg, #166534, #14532d)', color: '#d4af37', boxShadow: '0 0 12px rgba(212,175,55,0.2)' }}>
            م
          </div>
          <span className="text-emerald-100/70 text-sm hidden sm:block" style={{ fontFamily: 'Cairo' }}>محمد</span>
        </button>
      </div>
    </header>
  );
};
