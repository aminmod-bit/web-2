import React from 'react';

interface GoldDividerProps {
  className?: string;
  withIcon?: boolean;
}

export const GoldDivider: React.FC<GoldDividerProps> = ({ className = '', withIcon = false }) => {
  if (withIcon) {
    return (
      <div className={`flex items-center gap-4 ${className}`}>
        <div className="flex-1 gold-divider" />
        <div className="text-amber-400/60 text-lg">✦</div>
        <div className="flex-1 gold-divider" />
      </div>
    );
  }

  return <div className={`gold-divider ${className}`} />;
};
