import React from 'react';

interface IslamicPatternProps {
  className?: string;
  opacity?: number;
}

export const IslamicPattern: React.FC<IslamicPatternProps> = ({
  className = '',
  opacity = 0.03,
}) => {
  const svgContent = `<svg width="120" height="120" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <pattern id="p1" x="0" y="0" width="120" height="120" patternUnits="userSpaceOnUse">
        <path d="M60 10 L68 42 L100 42 L76 62 L84 94 L60 74 L36 94 L44 62 L20 42 L52 42 Z" fill="#d4af37" fill-opacity="${opacity * 1.5}"/>
        <path d="M60 25 L65 45 L85 45 L70 58 L75 78 L60 66 L45 78 L50 58 L35 45 L55 45 Z" fill="#d4af37" fill-opacity="${opacity}"/>
        <rect x="0" y="0" width="2" height="2" fill="#d4af37" fill-opacity="${opacity}"/>
        <rect x="118" y="0" width="2" height="2" fill="#d4af37" fill-opacity="${opacity}"/>
        <rect x="0" y="118" width="2" height="2" fill="#d4af37" fill-opacity="${opacity}"/>
        <rect x="118" y="118" width="2" height="2" fill="#d4af37" fill-opacity="${opacity}"/>
      </pattern>
    </defs>
    <rect width="120" height="120" fill="url(#p1)"/>
  </svg>`;

  return (
    <div
      className={`absolute inset-0 overflow-hidden pointer-events-none ${className}`}
      style={{ zIndex: 0 }}
    >
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `url("data:image/svg+xml,${encodeURIComponent(svgContent)}")`,
          backgroundSize: '120px 120px',
        }}
      />
    </div>
  );
};
