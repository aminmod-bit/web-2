import React from 'react';
import { GoldDivider } from './GoldDivider';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="mt-auto" style={{ borderTop: '1px solid rgba(212, 175, 55, 0.1)' }}>
      <GoldDivider />
      <div
        className="px-6 py-8"
        style={{ background: 'rgba(3, 12, 7, 0.8)' }}
      >
        {/* Logo & Description */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #d4af37, #b8962e)' }}>
              <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2} className="w-5 h-5">
                <path d="M4 19.5A2.5 2.5 0 016.5 17H20" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <div className="text-right">
              <p className="text-amber-300 font-bold text-base" style={{ fontFamily: 'Cairo' }}>مكتبة السلف</p>
              <p className="text-emerald-400/50 text-xs tracking-wider">SALAF LIBRARY</p>
            </div>
          </div>
          <p className="text-emerald-400/50 text-xs max-w-xs leading-relaxed" style={{ fontFamily: 'Cairo' }}>
            مكتبة رقمية متكاملة تجمع أمهات الكتب الإسلامية على منهج السلف الصالح
          </p>
        </div>

        <GoldDivider withIcon className="mb-6" />

        {/* Links */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          {[
            { title: 'المحتوى', links: [{ label: 'الكتب', page: 'books' }, { label: 'التراجم', page: 'scholars' }, { label: 'الصوتيات', page: 'audio' }, { label: 'الفوائد', page: 'fawaid' }] },
            { title: 'التصفح', links: [{ label: 'الرئيسية', page: 'home' }, { label: 'البحث', page: 'search' }, { label: 'لوحة التحكم', page: 'dashboard' }, { label: 'الإدارة', page: 'admin' }] },
            { title: 'التصنيفات', links: [{ label: 'الحديث النبوي', page: 'books' }, { label: 'العقيدة', page: 'books' }, { label: 'الفقه', page: 'books' }, { label: 'التفسير', page: 'books' }] },
            { title: 'المعلومات', links: [{ label: 'عن المكتبة', page: 'home' }, { label: 'سياسة الخصوصية', page: 'home' }, { label: 'شروط الاستخدام', page: 'home' }, { label: 'تواصل معنا', page: 'home' }] },
          ].map((section, i) => (
            <div key={i}>
              <h4 className="text-amber-400/80 text-xs font-bold mb-3 tracking-wider" style={{ fontFamily: 'Cairo' }}>
                {section.title}
              </h4>
              <ul className="space-y-2">
                {section.links.map((link, j) => (
                  <li key={j}>
                    <button
                      onClick={() => onNavigate(link.page)}
                      className="text-emerald-400/50 text-xs hover:text-amber-400/80 transition-colors text-right w-full"
                      style={{ fontFamily: 'Cairo' }}
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <GoldDivider className="mb-4" />

        {/* Bottom */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-emerald-400/30 text-xs" style={{ fontFamily: 'Cairo' }}>
            © 1446 هـ — مكتبة السلف. جميع الحقوق محفوظة.
          </p>
          <p className="text-emerald-400/20 text-xs flex items-center gap-1" style={{ fontFamily: 'Cairo' }}>
            <span>صُنع بـ</span>
            <span className="text-amber-400/30">♥</span>
            <span>لخدمة العلم الشرعي</span>
          </p>
        </div>
      </div>
    </footer>
  );
};
