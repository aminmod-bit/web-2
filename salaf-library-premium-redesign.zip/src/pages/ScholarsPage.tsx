import React, { useState } from 'react';
import { IslamicPattern } from '../components/IslamicPattern';
import { GoldDivider } from '../components/GoldDivider';
import { scholarsData, Scholar } from '../data/scholars';

const ScholarModal: React.FC<{ scholar: Scholar; onClose: () => void }> = ({ scholar, onClose }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-overlay animate-fade-in" onClick={onClose}>
    <div
      className="w-full max-w-lg rounded-3xl overflow-hidden animate-fade-in-up"
      style={{
        background: 'linear-gradient(135deg, #031a0d, #0a2e18)',
        border: '1px solid rgba(212, 175, 55, 0.25)',
        boxShadow: '0 40px 100px rgba(0,0,0,0.8)',
      }}
      onClick={e => e.stopPropagation()}
    >
      {/* Header */}
      <div className={`p-8 relative overflow-hidden bg-gradient-to-br ${scholar.gradient}`}>
        <IslamicPattern opacity={0.08} />
        <button onClick={onClose} className="absolute top-4 left-4 w-8 h-8 rounded-full bg-black/30 flex items-center justify-center text-white/70 hover:text-white transition-all">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
            <line x1="18" y1="6" x2="6" y2="18" strokeLinecap="round" />
            <line x1="6" y1="6" x2="18" y2="18" strokeLinecap="round" />
          </svg>
        </button>
        <div className="relative z-10 text-center">
          <div className="w-20 h-20 rounded-3xl mx-auto mb-4 flex items-center justify-center text-4xl font-bold"
            style={{
              background: 'rgba(0,0,0,0.3)',
              color: '#d4af37',
              border: '2px solid rgba(212,175,55,0.4)',
              fontFamily: 'Amiri, serif',
              backdropFilter: 'blur(10px)',
            }}>
            {scholar.initials}
          </div>
          {scholar.isVerified && (
            <div className="flex items-center justify-center gap-1 badge-gold px-3 py-1 rounded-full mx-auto w-fit mb-3 text-xs" style={{ fontFamily: 'Cairo' }}>
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              موثّق
            </div>
          )}
          <h2 className="text-amber-200 font-bold text-2xl mb-1" style={{ fontFamily: 'Amiri, serif' }}>{scholar.nameAr}</h2>
          <p className="text-amber-400/70 text-sm" style={{ fontFamily: 'Cairo' }}>{scholar.titleAr}</p>
        </div>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-3 gap-3 mb-5">
          {[
            { label: 'الولادة', value: scholar.born },
            { label: 'الوفاة', value: scholar.died },
            { label: 'المؤلفات', value: `${scholar.books}+` },
          ].map((s, i) => (
            <div key={i} className="glass-light rounded-xl p-3 text-center">
              <p className="text-amber-300 font-bold text-sm" style={{ fontFamily: 'Cairo' }}>{s.value}</p>
              <p className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>{s.label}</p>
            </div>
          ))}
        </div>

        <GoldDivider className="mb-4" />

        <p className="text-emerald-100/70 text-sm leading-relaxed mb-5" style={{ fontFamily: 'Cairo', lineHeight: '2' }}>
          {scholar.description}
        </p>

        <div className="flex flex-wrap gap-2 mb-5">
          {[scholar.school, ...scholar.specialtyAr.split('، ')].map((tag, i) => (
            <span key={i} className="badge-gold text-xs px-3 py-1 rounded-full" style={{ fontFamily: 'Cairo' }}>{tag}</span>
          ))}
          <span className="glass-light text-emerald-400/70 text-xs px-3 py-1 rounded-full" style={{ fontFamily: 'Cairo' }}>{scholar.era}</span>
        </div>

        <button className="w-full btn-emerald py-3 rounded-xl text-sm flex items-center justify-center gap-2" style={{ fontFamily: 'Cairo' }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
            <path d="M4 19.5A2.5 2.5 0 016.5 17H20" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          استعرض مؤلفاته ({scholar.books}+ كتاب)
        </button>
      </div>
    </div>
  </div>
);

const ScholarCard: React.FC<{ scholar: Scholar; onClick: () => void; index: number }> = ({ scholar, onClick, index }) => (
  <div
    className="glass-card card-glow rounded-2xl overflow-hidden cursor-pointer group hover:scale-[1.02] transition-all duration-300 animate-fade-in-up"
    style={{ animationDelay: `${index * 80}ms`, animationFillMode: 'forwards' }}
    onClick={onClick}
  >
    {/* Top gradient banner */}
    <div className={`h-24 relative overflow-hidden bg-gradient-to-br ${scholar.gradient}`}>
      <IslamicPattern opacity={0.07} />
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-px h-12 opacity-20" style={{ background: 'linear-gradient(180deg, transparent, #d4af37, transparent)' }} />
      </div>
    </div>

    {/* Avatar - overlapping */}
    <div className="px-5 pb-5 -mt-8 relative">
      <div className={`w-16 h-16 rounded-2xl mb-3 flex items-center justify-center text-2xl font-bold bg-gradient-to-br ${scholar.gradient} relative`}
        style={{
          color: '#d4af37',
          border: '3px solid rgba(7, 26, 18, 1)',
          boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
          fontFamily: 'Amiri, serif',
        }}>
        {scholar.initials}
        {scholar.isVerified && (
          <div className="absolute -bottom-1 -left-1 w-5 h-5 rounded-full flex items-center justify-center"
            style={{ background: '#d4af37' }}>
            <svg viewBox="0 0 24 24" fill="#071a12" className="w-3 h-3">
              <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
        )}
      </div>

      <h3 className="text-amber-200 font-bold text-base mb-0.5" style={{ fontFamily: 'Amiri, serif' }}>
        {scholar.nameAr}
      </h3>
      <p className="text-amber-400/60 text-xs mb-2" style={{ fontFamily: 'Cairo' }}>{scholar.titleAr}</p>

      <div className="flex items-center gap-1.5 mb-3 text-emerald-400/50">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-3 h-3">
          <rect x="3" y="4" width="18" height="18" rx="2" ry="2" strokeLinecap="round" strokeLinejoin="round" />
          <line x1="16" y1="2" x2="16" y2="6" strokeLinecap="round" strokeLinejoin="round" />
          <line x1="8" y1="2" x2="8" y2="6" strokeLinecap="round" strokeLinejoin="round" />
          <line x1="3" y1="10" x2="21" y2="10" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <span className="text-xs" style={{ fontFamily: 'Cairo' }}>{scholar.born} — {scholar.died}</span>
      </div>

      <div className="flex items-center justify-between">
        <span className="badge-gold text-xs px-2 py-0.5 rounded-full" style={{ fontFamily: 'Cairo', fontSize: '10px' }}>
          {scholar.school}
        </span>
        <div className="flex items-center gap-1 text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-3 h-3">
            <path d="M4 19.5A2.5 2.5 0 016.5 17H20" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          {scholar.books}+ مؤلَّف
        </div>
      </div>
    </div>
  </div>
);

export const ScholarsPage: React.FC = () => {
  const [selected, setSelected] = useState<Scholar | null>(null);
  const [search, setSearch] = useState('');
  const [eraFilter, setEraFilter] = useState('all');

  const eras = ['all', ...Array.from(new Set(scholarsData.map(s => s.era)))];

  const filtered = scholarsData.filter(s => {
    const matchSearch = !search || s.nameAr.includes(search) || s.titleAr.includes(search);
    const matchEra = eraFilter === 'all' || s.era === eraFilter;
    return matchSearch && matchEra;
  });

  return (
    <div className="relative min-h-full p-4">
      <IslamicPattern opacity={0.02} />

      {/* Header */}
      <div className="mb-6 flex items-center gap-3">
        <div className="w-8 h-8 rounded-xl flex items-center justify-center"
          style={{ background: 'linear-gradient(135deg, #d4af37, #b8962e)', boxShadow: '0 4px 12px rgba(212,175,55,0.3)' }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2} className="w-4 h-4">
            <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" strokeLinecap="round" strokeLinejoin="round" />
            <circle cx="12" cy="7" r="4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <div>
          <h1 className="text-emerald-100 font-bold text-xl" style={{ fontFamily: 'Cairo' }}>تراجم العلماء</h1>
          <p className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>Scholars' Biographies</p>
        </div>
      </div>

      {/* Filters */}
      <div className="glass-card rounded-2xl p-4 mb-5">
        <div className="flex gap-3 mb-3">
          <div className="flex-1 relative">
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="ابحث عن عالم..."
              className="w-full input-premium rounded-xl px-4 py-3 text-sm pr-10"
              style={{ fontFamily: 'Cairo' }}
            />
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-4 h-4 text-amber-400/50 absolute right-3 top-1/2 -translate-y-1/2">
              <circle cx="11" cy="11" r="8" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M21 21l-4.35-4.35" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          {eras.map(era => (
            <button
              key={era}
              onClick={() => setEraFilter(era)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${eraFilter === era ? 'btn-gold' : 'btn-ghost'}`}
              style={{ fontFamily: 'Cairo' }}
            >
              {era === 'all' ? 'جميع العصور' : era}
            </button>
          ))}
        </div>
      </div>

      {/* Featured Scholar Banner */}
      <div className="mb-6 rounded-2xl overflow-hidden relative"
        style={{
          background: 'linear-gradient(135deg, rgba(20, 83, 45, 0.3), rgba(7, 26, 18, 0.8))',
          border: '1px solid rgba(212, 175, 55, 0.2)',
        }}>
        <IslamicPattern opacity={0.05} />
        <div className="relative z-10 p-5 flex items-center gap-5">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl font-bold flex-shrink-0"
            style={{
              background: 'linear-gradient(135deg, #1a5c35, #0d3320)',
              color: '#d4af37',
              border: '1px solid rgba(212,175,55,0.3)',
              fontFamily: 'Amiri, serif',
            }}>
            ت
          </div>
          <div>
            <div className="badge-gold text-xs px-2 py-0.5 rounded-full mb-2 inline-block" style={{ fontFamily: 'Cairo' }}>عالم الشهر</div>
            <h2 className="text-amber-200 font-bold text-xl" style={{ fontFamily: 'Amiri, serif' }}>ابن تيمية</h2>
            <p className="text-emerald-400/60 text-xs" style={{ fontFamily: 'Cairo' }}>شيخ الإسلام • 661 – 728 هـ</p>
          </div>
          <div className="mr-auto hidden sm:block">
            <button className="btn-gold px-4 py-2 rounded-xl text-xs" style={{ fontFamily: 'Cairo' }}>
              اقرأ ترجمته
            </button>
          </div>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 mb-8">
        {filtered.map((scholar, i) => (
          <ScholarCard key={scholar.id} scholar={scholar} onClick={() => setSelected(scholar)} index={i} />
        ))}
      </div>

      {selected && <ScholarModal scholar={selected} onClose={() => setSelected(null)} />}
    </div>
  );
};
