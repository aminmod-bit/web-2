import React, { useState } from 'react';
import { IslamicPattern } from '../components/IslamicPattern';
import { GoldDivider } from '../components/GoldDivider';

type AdminTab = 'books' | 'scholars' | 'audio' | 'fawaid' | 'users';

const AdminBookForm: React.FC = () => (
  <div className="glass-card rounded-2xl p-6">
    <h3 className="text-amber-300 font-bold text-base mb-5 flex items-center gap-2" style={{ fontFamily: 'Cairo' }}>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-5 h-5 text-amber-400">
        <circle cx="12" cy="12" r="10" strokeLinecap="round" strokeLinejoin="round" />
        <line x1="12" y1="8" x2="12" y2="16" strokeLinecap="round" strokeLinejoin="round" />
        <line x1="8" y1="12" x2="16" y2="12" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      إضافة كتاب جديد
    </h3>
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      <div>
        <label className="text-emerald-400/70 text-xs mb-1.5 block" style={{ fontFamily: 'Cairo' }}>عنوان الكتاب (عربي) *</label>
        <input type="text" placeholder="مثال: صحيح البخاري" className="w-full input-premium rounded-xl px-4 py-3 text-sm" style={{ fontFamily: 'Amiri, serif' }} />
      </div>
      <div>
        <label className="text-emerald-400/70 text-xs mb-1.5 block" style={{ fontFamily: 'Cairo' }}>عنوان الكتاب (إنجليزي)</label>
        <input type="text" placeholder="e.g., Sahih al-Bukhari" className="w-full input-premium rounded-xl px-4 py-3 text-sm" />
      </div>
      <div>
        <label className="text-emerald-400/70 text-xs mb-1.5 block" style={{ fontFamily: 'Cairo' }}>المؤلف *</label>
        <input type="text" placeholder="اسم المؤلف" className="w-full input-premium rounded-xl px-4 py-3 text-sm" style={{ fontFamily: 'Cairo' }} />
      </div>
      <div>
        <label className="text-emerald-400/70 text-xs mb-1.5 block" style={{ fontFamily: 'Cairo' }}>القسم *</label>
        <select className="w-full input-premium rounded-xl px-4 py-3 text-sm" style={{ fontFamily: 'Cairo' }}>
          <option>اختر القسم</option>
          <option>حديث</option>
          <option>عقيدة</option>
          <option>فقه</option>
          <option>تفسير</option>
          <option>سيرة</option>
          <option>زهد وتزكية</option>
        </select>
      </div>
      <div>
        <label className="text-emerald-400/70 text-xs mb-1.5 block" style={{ fontFamily: 'Cairo' }}>سنة الوفاة (هـ)</label>
        <input type="number" placeholder="مثال: 256" className="w-full input-premium rounded-xl px-4 py-3 text-sm" style={{ fontFamily: 'Cairo' }} />
      </div>
      <div>
        <label className="text-emerald-400/70 text-xs mb-1.5 block" style={{ fontFamily: 'Cairo' }}>عدد الصفحات</label>
        <input type="number" placeholder="مثال: 1400" className="w-full input-premium rounded-xl px-4 py-3 text-sm" style={{ fontFamily: 'Cairo' }} />
      </div>
      <div className="sm:col-span-2">
        <label className="text-emerald-400/70 text-xs mb-1.5 block" style={{ fontFamily: 'Cairo' }}>الوصف</label>
        <textarea rows={3} placeholder="وصف مختصر للكتاب..." className="w-full input-premium rounded-xl px-4 py-3 text-sm resize-none" style={{ fontFamily: 'Cairo', lineHeight: '1.8' }} />
      </div>
      <div className="sm:col-span-2">
        <label className="text-emerald-400/70 text-xs mb-1.5 block" style={{ fontFamily: 'Cairo' }}>رفع ملف الكتاب (PDF)</label>
        <div
          className="rounded-xl p-8 text-center cursor-pointer hover:bg-white/5 transition-all"
          style={{ border: '2px dashed rgba(212, 175, 55, 0.2)' }}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-8 h-8 text-amber-400/40 mx-auto mb-2">
            <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" strokeLinecap="round" strokeLinejoin="round" />
            <polyline points="17 8 12 3 7 8" strokeLinecap="round" strokeLinejoin="round" />
            <line x1="12" y1="3" x2="12" y2="15" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <p className="text-emerald-400/50 text-sm" style={{ fontFamily: 'Cairo' }}>اسحب الملف هنا أو انقر للتحميل</p>
          <p className="text-emerald-400/30 text-xs mt-1" style={{ fontFamily: 'Cairo' }}>PDF, حتى 50 ميجابايت</p>
        </div>
      </div>
    </div>
    <GoldDivider className="my-5" />
    <div className="flex gap-3 justify-end">
      <button className="btn-ghost px-5 py-2.5 rounded-xl text-sm" style={{ fontFamily: 'Cairo' }}>إلغاء</button>
      <button className="btn-gold px-6 py-2.5 rounded-xl text-sm font-bold" style={{ fontFamily: 'Cairo' }}>
        حفظ الكتاب
      </button>
    </div>
  </div>
);

const tableData = [
  { id: 1, title: 'صحيح البخاري', author: 'الإمام البخاري', category: 'حديث', date: '2024/01/15', status: 'منشور' },
  { id: 2, title: 'العقيدة الواسطية', author: 'ابن تيمية', category: 'عقيدة', date: '2024/01/20', status: 'منشور' },
  { id: 3, title: 'زاد المعاد', author: 'ابن القيم', category: 'سيرة', date: '2024/01/25', status: 'منشور' },
  { id: 4, title: 'رياض الصالحين', author: 'الإمام النووي', category: 'حديث', date: '2024/02/01', status: 'مسودة' },
  { id: 5, title: 'كتاب التوحيد', author: 'ابن عبد الوهاب', category: 'عقيدة', date: '2024/02/05', status: 'منشور' },
];

export const AdminPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AdminTab>('books');
  const [showForm, setShowForm] = useState(false);

  const tabs: { id: AdminTab; label: string; icon: React.ReactNode }[] = [
    {
      id: 'books',
      label: 'الكتب',
      icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-4 h-4"><path d="M4 19.5A2.5 2.5 0 016.5 17H20" strokeLinecap="round" strokeLinejoin="round" /><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" strokeLinecap="round" strokeLinejoin="round" /></svg>,
    },
    {
      id: 'scholars',
      label: 'العلماء',
      icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-4 h-4"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" strokeLinecap="round" strokeLinejoin="round" /><circle cx="12" cy="7" r="4" strokeLinecap="round" strokeLinejoin="round" /></svg>,
    },
    {
      id: 'audio',
      label: 'الصوتيات',
      icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-4 h-4"><path d="M9 18V5l12-2v13" strokeLinecap="round" strokeLinejoin="round" /><circle cx="6" cy="18" r="3" strokeLinecap="round" strokeLinejoin="round" /><circle cx="18" cy="16" r="3" strokeLinecap="round" strokeLinejoin="round" /></svg>,
    },
    {
      id: 'fawaid',
      label: 'الفوائد',
      icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-4 h-4"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" strokeLinecap="round" strokeLinejoin="round" /></svg>,
    },
    {
      id: 'users',
      label: 'المستخدمون',
      icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-4 h-4"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" strokeLinecap="round" strokeLinejoin="round" /><circle cx="9" cy="7" r="4" strokeLinecap="round" strokeLinejoin="round" /><path d="M23 21v-2a4 4 0 00-3-3.87" strokeLinecap="round" strokeLinejoin="round" /><path d="M16 3.13a4 4 0 010 7.75" strokeLinecap="round" strokeLinejoin="round" /></svg>,
    },
  ];

  return (
    <div className="relative min-h-full p-4">
      <IslamicPattern opacity={0.02} />

      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg, #d4af37, #b8962e)', boxShadow: '0 4px 12px rgba(212,175,55,0.3)' }}>
            <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2} className="w-4 h-4">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <div>
            <h1 className="text-emerald-100 font-bold text-xl" style={{ fontFamily: 'Cairo' }}>إدارة المكتبة</h1>
            <p className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>Library Administration</p>
          </div>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="btn-gold px-4 py-2 rounded-xl text-sm flex items-center gap-2 font-bold"
          style={{ fontFamily: 'Cairo' }}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} className="w-4 h-4">
            <circle cx="12" cy="12" r="10" strokeLinecap="round" strokeLinejoin="round" />
            <line x1="12" y1="8" x2="12" y2="16" strokeLinecap="round" strokeLinejoin="round" />
            <line x1="8" y1="12" x2="16" y2="12" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          إضافة جديد
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="mb-6 animate-fade-in-up">
          <AdminBookForm />
        </div>
      )}

      {/* Tabs */}
      <div className="glass-card rounded-2xl p-2 mb-5 flex gap-1 flex-wrap">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${activeTab === tab.id ? 'btn-gold' : 'text-emerald-400/60 hover:text-emerald-300 hover:bg-white/5'}`}
            style={{ fontFamily: 'Cairo' }}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* Search & quick stats */}
      <div className="flex flex-col sm:flex-row gap-3 mb-5">
        <div className="flex-1 relative">
          <input
            type="text"
            placeholder={`ابحث في ${tabs.find(t => t.id === activeTab)?.label}...`}
            className="w-full input-premium rounded-xl px-4 py-3 text-sm pr-10"
            style={{ fontFamily: 'Cairo' }}
          />
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-4 h-4 text-amber-400/50 absolute right-3 top-1/2 -translate-y-1/2">
            <circle cx="11" cy="11" r="8" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M21 21l-4.35-4.35" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <select className="input-premium rounded-xl px-4 py-3 text-sm" style={{ fontFamily: 'Cairo' }}>
          <option>الكل</option>
          <option>منشور</option>
          <option>مسودة</option>
          <option>مؤرشف</option>
        </select>
        <button className="btn-ghost px-4 py-3 rounded-xl text-sm flex items-center gap-2" style={{ fontFamily: 'Cairo' }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-4 h-4">
            <path d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          فلترة
        </button>
      </div>

      {/* Table */}
      {activeTab === 'books' && (
        <div className="glass-card rounded-2xl overflow-hidden mb-8">
          {/* Table header */}
          <div className="grid gap-4 px-5 py-3 text-xs font-semibold text-amber-400/70 border-b border-white/5"
            style={{ gridTemplateColumns: '1fr 1fr 100px 100px 80px 80px', fontFamily: 'Cairo' }}>
            <span>عنوان الكتاب</span>
            <span>المؤلف</span>
            <span>القسم</span>
            <span>تاريخ الإضافة</span>
            <span>الحالة</span>
            <span>إجراءات</span>
          </div>
          {tableData.map((row, i) => (
            <div
              key={row.id}
              className={`grid gap-4 px-5 py-4 text-sm items-center border-b border-white/5 last:border-0 hover:bg-white/3 transition-all
                ${i % 2 === 0 ? '' : 'bg-white/[0.02]'}`}
              style={{ gridTemplateColumns: '1fr 1fr 100px 100px 80px 80px' }}
            >
              <span className="text-amber-200 font-semibold line-clamp-1" style={{ fontFamily: 'Amiri, serif' }}>{row.title}</span>
              <span className="text-emerald-100/70 text-xs" style={{ fontFamily: 'Cairo' }}>{row.author}</span>
              <span>
                <span className="badge-emerald text-xs px-2 py-0.5 rounded-full" style={{ fontFamily: 'Cairo', fontSize: '10px' }}>{row.category}</span>
              </span>
              <span className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>{row.date}</span>
              <span>
                <span
                  className={`text-xs px-2 py-0.5 rounded-full font-semibold ${row.status === 'منشور' ? 'text-emerald-400 bg-emerald-400/10' : 'text-amber-400 bg-amber-400/10'}`}
                  style={{ fontFamily: 'Cairo' }}
                >
                  {row.status}
                </span>
              </span>
              <div className="flex items-center gap-1.5">
                <button className="w-7 h-7 rounded-lg flex items-center justify-center text-emerald-400/50 hover:text-amber-400 hover:bg-white/5 transition-all">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-3.5 h-3.5">
                    <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
                <button className="w-7 h-7 rounded-lg flex items-center justify-center text-emerald-400/50 hover:text-red-400 hover:bg-red-400/10 transition-all">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-3.5 h-3.5">
                    <polyline points="3 6 5 6 21 6" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M10 11v6" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M14 11v6" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M9 6V4h6v2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab !== 'books' && (
        <div className="glass-card rounded-2xl p-10 text-center mb-8">
          <div className="text-4xl mb-3 opacity-30">🚧</div>
          <p className="text-emerald-100/50 text-base" style={{ fontFamily: 'Cairo' }}>
            قسم إدارة {tabs.find(t => t.id === activeTab)?.label} قيد التطوير
          </p>
          <p className="text-emerald-400/30 text-sm mt-1" style={{ fontFamily: 'Cairo' }}>سيكون متاحاً قريباً</p>
        </div>
      )}

      {/* System status */}
      <div className="glass-card rounded-2xl p-5 mb-5">
        <h3 className="text-emerald-100 font-semibold text-sm mb-4" style={{ fontFamily: 'Cairo' }}>حالة النظام</h3>
        <div className="space-y-3">
          {[
            { label: 'قاعدة البيانات', status: 'يعمل', pct: 98, color: '#22c55e' },
            { label: 'خادم الملفات', status: 'يعمل', pct: 72, color: '#d4af37' },
            { label: 'نظام البحث', status: 'يعمل', pct: 95, color: '#22c55e' },
            { label: 'مساحة التخزين', status: 'تحذير', pct: 85, color: '#f97316' },
          ].map((item, i) => (
            <div key={i}>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-emerald-100/70 text-xs" style={{ fontFamily: 'Cairo' }}>{item.label}</span>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold" style={{ color: item.color, fontFamily: 'Cairo' }}>{item.pct}%</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-semibold`}
                    style={{ color: item.color, background: `${item.color}15`, fontFamily: 'Cairo' }}>
                    {item.status}
                  </span>
                </div>
              </div>
              <div className="h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.05)' }}>
                <div className="h-full rounded-full transition-all" style={{ width: `${item.pct}%`, background: item.color, boxShadow: `0 0 8px ${item.color}50` }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick actions */}
      <div className="glass-card rounded-2xl p-5">
        <h3 className="text-emerald-100 font-semibold text-sm mb-4" style={{ fontFamily: 'Cairo' }}>إجراءات سريعة</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: 'نسخ احتياطي', icon: '💾', color: '#d4af37' },
            { label: 'استيراد بيانات', icon: '📥', color: '#22c55e' },
            { label: 'تصدير بيانات', icon: '📤', color: '#3b82f6' },
            { label: 'مسح الكاش', icon: '🗑️', color: '#f97316' },
          ].map((action, i) => (
            <button key={i} className="glass-light rounded-xl p-3 text-center hover:bg-white/5 transition-all group">
              <div className="text-2xl mb-2">{action.icon}</div>
              <p className="text-xs font-semibold" style={{ color: action.color, fontFamily: 'Cairo' }}>{action.label}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
