import React, { useState } from 'react';
import { IslamicPattern } from '../components/IslamicPattern';
import { GoldDivider } from '../components/GoldDivider';
import { fawaidData, Faida } from '../data/fawaid';

const FaidaCard: React.FC<{ faida: Faida; index: number }> = ({ faida, index }) => {
  const [liked, setLiked] = useState(false);
  const [bookmarked, setBookmarked] = useState(faida.isBookmarked || false);

  return (
    <div
      className={`glass-card card-glow rounded-2xl p-5 relative overflow-hidden group animate-fade-in-up
        ${faida.isPinned ? 'ring-1 ring-amber-400/20' : ''}`}
      style={{ animationDelay: `${index * 80}ms`, animationFillMode: 'forwards' }}
    >
      <IslamicPattern opacity={0.03} />

      {/* Pinned indicator */}
      {faida.isPinned && (
        <div className="absolute top-3 left-3">
          <span className="badge-gold text-xs px-2 py-0.5 rounded-full" style={{ fontFamily: 'Cairo', fontSize: '10px' }}>
            📌 مثبّت
          </span>
        </div>
      )}

      <div className="relative z-10">
        {/* Category */}
        <div className="flex items-center justify-between mb-4">
          <span className="badge-emerald text-xs px-3 py-1 rounded-full" style={{ fontFamily: 'Cairo' }}>
            {faida.categoryAr}
          </span>
          <div className="flex items-center gap-1 text-amber-400/30">
            <div className="text-xl opacity-20">❝</div>
          </div>
        </div>

        {/* Arabic text */}
        <blockquote
          className="text-amber-100/90 text-lg leading-loose mb-4 text-center"
          style={{ fontFamily: 'Amiri, serif', lineHeight: '2.2' }}
        >
          {faida.textAr}
        </blockquote>

        <div className="gold-divider mb-3" />

        {/* Source */}
        <p className="text-emerald-400/60 text-xs text-center mb-4" style={{ fontFamily: 'Cairo' }}>
          — رواه {faida.sourceAr}
        </p>

        {/* Actions */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setLiked(!liked)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs transition-all ${
                liked ? 'bg-amber-400/20 text-amber-300' : 'text-emerald-400/50 hover:text-amber-400 hover:bg-white/5'
              }`}
              style={{ fontFamily: 'Cairo' }}
            >
              <svg viewBox="0 0 24 24" fill={liked ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={2} className="w-4 h-4">
                <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              {faida.likes + (liked ? 1 : 0)}
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setBookmarked(!bookmarked)}
              className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                bookmarked ? 'bg-amber-400/20 text-amber-300' : 'text-emerald-400/40 hover:text-amber-400 hover:bg-white/5'
              }`}
            >
              <svg viewBox="0 0 24 24" fill={bookmarked ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={2} className="w-4 h-4">
                <path d="M19 21l-7-5-7 5V5a2 2 0 012-2h10a2 2 0 012 2z" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
            <button className="w-8 h-8 rounded-xl flex items-center justify-center text-emerald-400/40 hover:text-amber-400 hover:bg-white/5 transition-all">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
                <circle cx="18" cy="5" r="3" strokeLinecap="round" strokeLinejoin="round" />
                <circle cx="6" cy="12" r="3" strokeLinecap="round" strokeLinejoin="round" />
                <circle cx="18" cy="19" r="3" strokeLinecap="round" strokeLinejoin="round" />
                <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" strokeLinecap="round" strokeLinejoin="round" />
                <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export const FawaidPage: React.FC = () => {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');
  const [view, setView] = useState<'grid' | 'list'>('grid');

  const categories = ['all', ...Array.from(new Set(fawaidData.map(f => f.categoryAr)))];
  const filtered = fawaidData.filter(f => {
    const matchSearch = !search || f.textAr.includes(search) || f.sourceAr.includes(search);
    const matchCat = category === 'all' || f.categoryAr === category;
    return matchSearch && matchCat;
  });

  const pinned = fawaidData.filter(f => f.isPinned);

  return (
    <div className="relative min-h-full p-4">
      <IslamicPattern opacity={0.02} />

      {/* Header */}
      <div className="mb-6 flex items-center gap-3">
        <div className="w-8 h-8 rounded-xl flex items-center justify-center"
          style={{ background: 'linear-gradient(135deg, #d4af37, #b8962e)', boxShadow: '0 4px 12px rgba(212,175,55,0.3)' }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2} className="w-4 h-4">
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <div>
          <h1 className="text-emerald-100 font-bold text-xl" style={{ fontFamily: 'Cairo' }}>الفوائد والدرر</h1>
          <p className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>Fawaid & Pearls of Wisdom</p>
        </div>
      </div>

      {/* Pinned highlight */}
      {pinned.length > 0 && (
        <div
          className="mb-6 rounded-2xl p-5 relative overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, rgba(20, 83, 45, 0.2), rgba(7, 26, 18, 0.8))',
            border: '1px solid rgba(212, 175, 55, 0.2)',
          }}
        >
          <IslamicPattern opacity={0.05} />
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-4">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4 text-amber-400">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span className="text-amber-400 font-bold text-sm" style={{ fontFamily: 'Cairo' }}>فائدة مثبّتة</span>
            </div>
            <blockquote
              className="text-amber-200/90 text-xl text-center leading-loose"
              style={{ fontFamily: 'Amiri, serif', lineHeight: '2.2' }}
            >
              «{pinned[0].textAr}»
            </blockquote>
            <GoldDivider withIcon className="mt-4" />
            <p className="text-emerald-400/60 text-xs text-center mt-3" style={{ fontFamily: 'Cairo' }}>
              — رواه {pinned[0].sourceAr}
            </p>
          </div>
        </div>
      )}

      {/* Search & Filter */}
      <div className="glass-card rounded-2xl p-4 mb-5">
        <div className="flex gap-3 mb-3">
          <div className="flex-1 relative">
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="ابحث في الفوائد..."
              className="w-full input-premium rounded-xl px-4 py-3 text-sm pr-10"
              style={{ fontFamily: 'Cairo' }}
            />
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-4 h-4 text-amber-400/50 absolute right-3 top-1/2 -translate-y-1/2">
              <circle cx="11" cy="11" r="8" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M21 21l-4.35-4.35" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setView('grid')} className={`px-3 py-2 rounded-xl transition-all ${view === 'grid' ? 'btn-gold' : 'btn-ghost'}`}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
                <rect x="3" y="3" width="7" height="7" rx="1" strokeLinecap="round" />
                <rect x="14" y="3" width="7" height="7" rx="1" strokeLinecap="round" />
                <rect x="3" y="14" width="7" height="7" rx="1" strokeLinecap="round" />
                <rect x="14" y="14" width="7" height="7" rx="1" strokeLinecap="round" />
              </svg>
            </button>
            <button onClick={() => setView('list')} className={`px-3 py-2 rounded-xl transition-all ${view === 'list' ? 'btn-gold' : 'btn-ghost'}`}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
                <line x1="8" y1="6" x2="21" y2="6" strokeLinecap="round" />
                <line x1="8" y1="12" x2="21" y2="12" strokeLinecap="round" />
                <line x1="8" y1="18" x2="21" y2="18" strokeLinecap="round" />
                <line x1="3" y1="6" x2="3.01" y2="6" strokeLinecap="round" />
                <line x1="3" y1="12" x2="3.01" y2="12" strokeLinecap="round" />
                <line x1="3" y1="18" x2="3.01" y2="18" strokeLinecap="round" />
              </svg>
            </button>
          </div>
        </div>

        <div className="flex gap-2 flex-wrap">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${category === cat ? 'btn-gold' : 'btn-ghost'}`}
              style={{ fontFamily: 'Cairo' }}
            >
              {cat === 'all' ? 'الكل' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Fawaid */}
      <div className={view === 'grid' ? 'grid grid-cols-1 lg:grid-cols-2 gap-4 mb-8' : 'space-y-4 mb-8'}>
        {filtered.map((faida, i) => (
          <FaidaCard key={faida.id} faida={faida} index={i} />
        ))}
      </div>

      {/* Add new faida */}
      <div className="glass-card rounded-2xl p-5 mb-8">
        <div className="flex items-center gap-2 mb-4">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4 text-amber-400">
            <circle cx="12" cy="12" r="10" strokeLinecap="round" strokeLinejoin="round" />
            <line x1="12" y1="8" x2="12" y2="16" strokeLinecap="round" strokeLinejoin="round" />
            <line x1="8" y1="12" x2="16" y2="12" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <h2 className="text-emerald-100 font-semibold text-sm" style={{ fontFamily: 'Cairo' }}>إضافة فائدة جديدة</h2>
        </div>
        <textarea
          placeholder="اكتب الفائدة هنا..."
          rows={3}
          className="w-full input-premium rounded-xl px-4 py-3 text-sm resize-none mb-3"
          style={{ fontFamily: 'Amiri, serif', fontSize: '16px', lineHeight: '2' }}
        />
        <div className="flex gap-3">
          <input
            type="text"
            placeholder="المصدر..."
            className="flex-1 input-premium rounded-xl px-4 py-2.5 text-sm"
            style={{ fontFamily: 'Cairo' }}
          />
          <button className="btn-gold px-5 py-2.5 rounded-xl text-sm font-bold" style={{ fontFamily: 'Cairo' }}>
            إضافة
          </button>
        </div>
      </div>
    </div>
  );
};
