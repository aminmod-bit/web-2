import React, { useState } from 'react';
import { IslamicPattern } from '../components/IslamicPattern';
import { booksData } from '../data/books';
import { scholarsData } from '../data/scholars';
import { audioData } from '../data/audio';

type SearchSection = 'all' | 'books' | 'scholars' | 'audio' | 'fawaid';

interface SearchPageProps {
  onNavigate: (page: string) => void;
}

const popularSearches = ['صحيح البخاري', 'ابن تيمية', 'العقيدة الواسطية', 'زاد المعاد', 'الفوزان', 'التفسير'];

export const SearchPage: React.FC<SearchPageProps> = ({ onNavigate }) => {
  const [query, setQuery] = useState('');
  const [section, setSection] = useState<SearchSection>('all');
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = (q: string) => {
    setQuery(q);
    setHasSearched(true);
  };

  const bookResults = booksData.filter(b =>
    b.titleAr.includes(query) || b.authorAr.includes(query) || b.categoryAr.includes(query)
  );
  const scholarResults = scholarsData.filter(s =>
    s.nameAr.includes(query) || s.titleAr.includes(query)
  );
  const audioResults = audioData.filter(a =>
    a.titleAr.includes(query) || a.sheikhAr.includes(query)
  );

  const totalResults = bookResults.length + scholarResults.length + audioResults.length;

  const sections: { id: SearchSection; label: string; count?: number }[] = [
    { id: 'all', label: 'الكل', count: hasSearched ? totalResults : undefined },
    { id: 'books', label: 'الكتب', count: hasSearched ? bookResults.length : undefined },
    { id: 'scholars', label: 'العلماء', count: hasSearched ? scholarResults.length : undefined },
    { id: 'audio', label: 'الصوتيات', count: hasSearched ? audioResults.length : undefined },
    { id: 'fawaid', label: 'الفوائد' },
  ];

  return (
    <div className="relative min-h-full p-4">
      <IslamicPattern opacity={0.02} />

      {/* Header */}
      <div className="mb-6 flex items-center gap-3">
        <div className="w-8 h-8 rounded-xl flex items-center justify-center"
          style={{ background: 'linear-gradient(135deg, #d4af37, #b8962e)', boxShadow: '0 4px 12px rgba(212,175,55,0.3)' }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2} className="w-4 h-4">
            <circle cx="11" cy="11" r="8" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M21 21l-4.35-4.35" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <div>
          <h1 className="text-emerald-100 font-bold text-xl" style={{ fontFamily: 'Cairo' }}>البحث الشامل</h1>
          <p className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>Advanced Search</p>
        </div>
      </div>

      {/* Hero search */}
      <div
        className="rounded-3xl p-8 mb-6 relative overflow-hidden text-center"
        style={{
          background: 'linear-gradient(135deg, #031a0d 0%, #0a3320 40%, #062213 100%)',
          border: '1px solid rgba(212, 175, 55, 0.15)',
          boxShadow: '0 20px 60px rgba(0,0,0,0.4)',
        }}
      >
        <IslamicPattern opacity={0.05} />
        <div className="absolute top-0 right-0 w-48 h-48 rounded-full opacity-10 blur-3xl"
          style={{ background: 'radial-gradient(circle, #d4af37, transparent)' }} />

        <div className="relative z-10">
          <h2 className="text-amber-300 text-2xl font-bold mb-2" style={{ fontFamily: 'Amiri, serif' }}>
            ابحث في المكتبة
          </h2>
          <p className="text-emerald-400/60 text-sm mb-6" style={{ fontFamily: 'Cairo' }}>
            اكتب اسم كتاب، عالم، أو كلمة مفتاحية
          </p>

          {/* Main search input */}
          <div className="relative max-w-lg mx-auto">
            <input
              type="text"
              value={query}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSearch(query)}
              placeholder="ابحث هنا..."
              className="w-full rounded-2xl px-6 py-4 text-base pr-14 text-right"
              style={{
                fontFamily: 'Cairo',
                background: 'rgba(7, 26, 18, 0.9)',
                border: '1px solid rgba(212, 175, 55, 0.25)',
                color: '#f0ede4',
                outline: 'none',
                boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
              }}
              autoFocus
            />
            <button
              onClick={() => handleSearch(query)}
              className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #d4af37, #b8962e)' }}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="#071a12" strokeWidth={2.5} className="w-5 h-5">
                <circle cx="11" cy="11" r="8" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M21 21l-4.35-4.35" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
          </div>

          {/* Popular searches */}
          {!hasSearched && (
            <div className="mt-5">
              <p className="text-emerald-400/50 text-xs mb-3" style={{ fontFamily: 'Cairo' }}>بحث شائع:</p>
              <div className="flex flex-wrap gap-2 justify-center">
                {popularSearches.map(s => (
                  <button
                    key={s}
                    onClick={() => handleSearch(s)}
                    className="px-3 py-1.5 rounded-xl text-xs transition-all"
                    style={{
                      background: 'rgba(212, 175, 55, 0.08)',
                      border: '1px solid rgba(212, 175, 55, 0.15)',
                      color: '#d4af37',
                      fontFamily: 'Cairo',
                    }}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Section filters */}
      {hasSearched && (
        <>
          <div className="flex gap-2 mb-5 flex-wrap">
            {sections.map(sec => (
              <button
                key={sec.id}
                onClick={() => setSection(sec.id)}
                className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-2 ${section === sec.id ? 'btn-gold' : 'btn-ghost'}`}
                style={{ fontFamily: 'Cairo' }}
              >
                {sec.label}
                {sec.count !== undefined && (
                  <span className={`text-xs px-1.5 py-0.5 rounded-full ${section === sec.id ? 'bg-black/20' : 'bg-white/10'}`}>
                    {sec.count}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Results summary */}
          <p className="text-emerald-400/50 text-sm mb-4" style={{ fontFamily: 'Cairo' }}>
            نتائج البحث عن "<span className="text-amber-400">{query}</span>": {totalResults} نتيجة
          </p>

          {/* Books results */}
          {(section === 'all' || section === 'books') && bookResults.length > 0 && (
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-1 h-5 rounded-full" style={{ background: 'linear-gradient(180deg, #d4af37, #b8962e)' }} />
                <h3 className="text-emerald-100 font-semibold" style={{ fontFamily: 'Cairo' }}>الكتب ({bookResults.length})</h3>
              </div>
              <div className="space-y-2">
                {bookResults.map(book => (
                  <div key={book.id} className="glass-card card-glow rounded-xl p-4 flex items-center gap-4 cursor-pointer hover:scale-[1.01] transition-all"
                    onClick={() => onNavigate('books')}>
                    <div className={`w-10 h-14 rounded-lg flex-shrink-0 bg-gradient-to-br ${book.coverColor} flex items-center justify-center`}
                      style={{ border: '1px solid rgba(212,175,55,0.2)' }}>
                      <svg viewBox="0 0 24 24" fill="none" stroke="#d4af37" strokeWidth={1.5} className="w-5 h-5 opacity-60">
                        <path d="M4 19.5A2.5 2.5 0 016.5 17H20" strokeLinecap="round" strokeLinejoin="round" />
                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </div>
                    <div className="flex-1">
                      <p className="text-amber-200 font-bold text-sm" style={{ fontFamily: 'Amiri, serif' }}>{book.titleAr}</p>
                      <p className="text-emerald-400/60 text-xs" style={{ fontFamily: 'Cairo' }}>{book.authorAr}</p>
                    </div>
                    <span className="badge-emerald text-xs px-2 py-0.5 rounded-full" style={{ fontFamily: 'Cairo', fontSize: '10px' }}>{book.categoryAr}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Scholar results */}
          {(section === 'all' || section === 'scholars') && scholarResults.length > 0 && (
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-1 h-5 rounded-full" style={{ background: 'linear-gradient(180deg, #d4af37, #b8962e)' }} />
                <h3 className="text-emerald-100 font-semibold" style={{ fontFamily: 'Cairo' }}>العلماء ({scholarResults.length})</h3>
              </div>
              <div className="space-y-2">
                {scholarResults.map(scholar => (
                  <div key={scholar.id} className="glass-card card-glow rounded-xl p-4 flex items-center gap-4 cursor-pointer hover:scale-[1.01] transition-all"
                    onClick={() => onNavigate('scholars')}>
                    <div className={`w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center font-bold bg-gradient-to-br ${scholar.gradient}`}
                      style={{ color: '#d4af37', fontFamily: 'Amiri, serif' }}>
                      {scholar.initials}
                    </div>
                    <div className="flex-1">
                      <p className="text-amber-200 font-bold text-sm" style={{ fontFamily: 'Amiri, serif' }}>{scholar.nameAr}</p>
                      <p className="text-emerald-400/60 text-xs" style={{ fontFamily: 'Cairo' }}>{scholar.titleAr}</p>
                    </div>
                    <span className="badge-gold text-xs px-2 py-0.5 rounded-full" style={{ fontFamily: 'Cairo', fontSize: '10px' }}>{scholar.school}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Audio results */}
          {(section === 'all' || section === 'audio') && audioResults.length > 0 && (
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-1 h-5 rounded-full" style={{ background: 'linear-gradient(180deg, #d4af37, #b8962e)' }} />
                <h3 className="text-emerald-100 font-semibold" style={{ fontFamily: 'Cairo' }}>الصوتيات ({audioResults.length})</h3>
              </div>
              <div className="space-y-2">
                {audioResults.map(audio => (
                  <div key={audio.id} className="glass-card card-glow rounded-xl p-4 flex items-center gap-4 cursor-pointer hover:scale-[1.01] transition-all"
                    onClick={() => onNavigate('audio')}>
                    <div className={`w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center font-bold bg-gradient-to-br ${audio.gradient}`}
                      style={{ color: '#d4af37', fontFamily: 'Amiri, serif' }}>
                      {audio.initials}
                    </div>
                    <div className="flex-1">
                      <p className="text-amber-200 font-bold text-sm" style={{ fontFamily: 'Cairo' }}>{audio.titleAr}</p>
                      <p className="text-emerald-400/60 text-xs" style={{ fontFamily: 'Cairo' }}>{audio.sheikhAr}</p>
                    </div>
                    <span className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>{audio.duration}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {totalResults === 0 && (
            <div className="text-center py-16">
              <div className="text-5xl mb-4 opacity-30">🔍</div>
              <p className="text-emerald-100/50 text-lg mb-2" style={{ fontFamily: 'Cairo' }}>لا توجد نتائج</p>
              <p className="text-emerald-400/40 text-sm" style={{ fontFamily: 'Cairo' }}>جرب البحث بكلمة أخرى</p>
            </div>
          )}
        </>
      )}

      {/* Categories quick links */}
      {!hasSearched && (
        <div>
          <div className="flex items-center gap-2 mb-4">
            <div className="w-1 h-5 rounded-full" style={{ background: 'linear-gradient(180deg, #d4af37, #b8962e)' }} />
            <h2 className="text-emerald-100 font-semibold" style={{ fontFamily: 'Cairo' }}>تصفح حسب القسم</h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {[
              { id: 'books', label: 'الكتب', icon: '📚', count: '2,480+', sub: 'كتاب ومخطوطة' },
              { id: 'scholars', label: 'التراجم', icon: '👤', count: '380+', sub: 'عالم وإمام' },
              { id: 'audio', label: 'الصوتيات', icon: '🎙️', count: '1,200+', sub: 'محاضرة مسجلة' },
              { id: 'fawaid', label: 'الفوائد', icon: '✨', count: '5,000+', sub: 'فائدة ودرة' },
              { id: 'home', label: 'الرئيسية', icon: '🏠', count: '', sub: 'الصفحة الرئيسية' },
              { id: 'dashboard', label: 'الإحصاءات', icon: '📊', count: '', sub: 'لوحة التحكم' },
            ].map(item => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className="glass-card card-glow rounded-2xl p-4 text-right hover:scale-[1.02] transition-all"
              >
                <div className="text-2xl mb-2">{item.icon}</div>
                <p className="text-amber-300 font-bold text-sm" style={{ fontFamily: 'Cairo' }}>{item.label}</p>
                {item.count && <p className="text-amber-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>{item.count} {item.sub}</p>}
                {!item.count && <p className="text-emerald-400/40 text-xs" style={{ fontFamily: 'Cairo' }}>{item.sub}</p>}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
