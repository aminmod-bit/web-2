import React, { useState } from 'react';
import { IslamicPattern } from '../components/IslamicPattern';
import { GoldDivider } from '../components/GoldDivider';
import { booksData, categories, Book } from '../data/books';

const BookModal: React.FC<{ book: Book; onClose: () => void }> = ({ book, onClose }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-overlay animate-fade-in"
    onClick={onClose}>
    <div
      className="w-full max-w-lg rounded-3xl overflow-hidden animate-fade-in-up relative"
      style={{
        background: 'linear-gradient(135deg, #031a0d, #0a2e18)',
        border: '1px solid rgba(212, 175, 55, 0.25)',
        boxShadow: '0 40px 100px rgba(0,0,0,0.8)',
      }}
      onClick={e => e.stopPropagation()}
    >
      {/* Header */}
      <div className={`h-48 relative overflow-hidden bg-gradient-to-br ${book.coverColor}`}>
        <IslamicPattern opacity={0.08} />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center relative z-10">
            <p className="text-amber-200 text-3xl mb-2" style={{ fontFamily: 'Amiri, serif' }}>{book.titleAr}</p>
            <div className="w-16 h-px mx-auto" style={{ background: 'linear-gradient(90deg, transparent, #d4af37, transparent)' }} />
          </div>
        </div>
        <button
          onClick={onClose}
          className="absolute top-4 left-4 w-8 h-8 rounded-full bg-black/30 flex items-center justify-center text-white/70 hover:text-white hover:bg-black/50 transition-all"
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
            <line x1="18" y1="6" x2="6" y2="18" strokeLinecap="round" />
            <line x1="6" y1="6" x2="18" y2="18" strokeLinecap="round" />
          </svg>
        </button>
      </div>

      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h2 className="text-amber-200 font-bold text-xl mb-1" style={{ fontFamily: 'Amiri, serif' }}>{book.titleAr}</h2>
            <p className="text-emerald-400/70 text-sm" style={{ fontFamily: 'Cairo' }}>{book.authorAr}</p>
          </div>
          <span className="badge-emerald text-xs px-3 py-1 rounded-full" style={{ fontFamily: 'Cairo' }}>{book.categoryAr}</span>
        </div>

        <GoldDivider className="mb-4" />

        <p className="text-emerald-100/70 text-sm leading-relaxed mb-5" style={{ fontFamily: 'Cairo', lineHeight: '1.9' }}>
          {book.description}
        </p>

        <div className="grid grid-cols-3 gap-3 mb-5">
          {[
            { label: 'الصفحات', value: book.pages.toLocaleString() },
            { label: 'السنة', value: `${book.year} هـ` },
            { label: 'التحميلات', value: `${(book.downloads / 1000).toFixed(1)}k` },
          ].map((stat, i) => (
            <div key={i} className="glass-light rounded-xl p-3 text-center">
              <p className="text-amber-300 font-bold text-base" style={{ fontFamily: 'Cairo' }}>{stat.value}</p>
              <p className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="flex gap-3">
          <button className="flex-1 btn-gold py-3 rounded-xl text-sm flex items-center justify-center gap-2" style={{ fontFamily: 'Cairo' }}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
              <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" strokeLinecap="round" strokeLinejoin="round" />
              <polyline points="7 10 12 15 17 10" strokeLinecap="round" strokeLinejoin="round" />
              <line x1="12" y1="15" x2="12" y2="3" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            تحميل الكتاب
          </button>
          <button className="btn-ghost px-5 py-3 rounded-xl" style={{ fontFamily: 'Cairo' }}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
              <path d="M19 21l-7-5-7 5V5a2 2 0 012-2h10a2 2 0 012 2z" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  </div>
);

const BookCard: React.FC<{ book: Book; onClick: () => void; index: number }> = ({ book, onClick, index }) => (
  <div
    className="glass-card card-glow rounded-2xl overflow-hidden group cursor-pointer hover:scale-[1.02] transition-all duration-300 animate-fade-in-up"
    style={{ animationDelay: `${index * 60}ms`, animationFillMode: 'forwards' }}
    onClick={onClick}
  >
    {/* Cover */}
    <div className={`h-44 relative overflow-hidden bg-gradient-to-br ${book.coverColor}`}>
      <IslamicPattern opacity={0.07} />
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 relative z-10 p-4">
        <div className="w-8 h-8 opacity-50">
          <svg viewBox="0 0 24 24" fill="none" stroke="#d4af37" strokeWidth={1.5}>
            <path d="M4 19.5A2.5 2.5 0 016.5 17H20" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <p className="text-amber-200/70 text-sm text-center line-clamp-2" style={{ fontFamily: 'Amiri, serif' }}>
          {book.titleAr}
        </p>
        <div className="w-10 h-px" style={{ background: 'linear-gradient(90deg, transparent, #d4af37, transparent)' }} />
      </div>

      {book.tag && (
        <span className="absolute top-2 right-2 badge-gold text-xs px-2 py-0.5 rounded-full z-20" style={{ fontFamily: 'Cairo', fontSize: '10px' }}>
          {book.tag}
        </span>
      )}

      {/* Hover overlay */}
      <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
        <div className="glass px-4 py-2 rounded-xl text-amber-300 text-xs font-semibold" style={{ fontFamily: 'Cairo' }}>
          عرض التفاصيل
        </div>
      </div>
    </div>

    {/* Info */}
    <div className="p-4">
      <h3 className="text-amber-200 font-bold text-base mb-1 line-clamp-1" style={{ fontFamily: 'Amiri, serif' }}>
        {book.titleAr}
      </h3>
      <p className="text-emerald-400/60 text-xs mb-2" style={{ fontFamily: 'Cairo' }}>{book.authorAr}</p>

      <div className="flex items-center justify-between">
        <span className="badge-emerald text-xs px-2 py-0.5 rounded-full" style={{ fontFamily: 'Cairo', fontSize: '10px' }}>
          {book.categoryAr}
        </span>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1">
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3 text-amber-400">
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
            </svg>
            <span className="text-amber-300/70 text-xs">{book.rating}</span>
          </div>
          <div className="flex items-center gap-1 text-emerald-400/40">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-3 h-3">
              <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" strokeLinecap="round" strokeLinejoin="round" />
              <polyline points="7 10 12 15 17 10" strokeLinecap="round" strokeLinejoin="round" />
              <line x1="12" y1="15" x2="12" y2="3" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span className="text-xs">{(book.downloads / 1000).toFixed(1)}k</span>
          </div>
        </div>
      </div>
    </div>
  </div>
);

export const BooksPage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('popular');
  const [view, setView] = useState<'grid' | 'list'>('grid');

  const filtered = booksData.filter(b => {
    const matchCat = selectedCategory === 'all' || b.categoryAr.includes(categories.find(c => c.id === selectedCategory)?.name || '');
    const matchSearch = !searchQuery || b.titleAr.includes(searchQuery) || b.authorAr.includes(searchQuery);
    return matchCat && matchSearch;
  });

  return (
    <div className="relative min-h-full p-4">
      <IslamicPattern opacity={0.02} />

      {/* Page Header */}
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-1">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg, #d4af37, #b8962e)', boxShadow: '0 4px 12px rgba(212,175,55,0.3)' }}>
            <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2} className="w-4 h-4">
              <path d="M4 19.5A2.5 2.5 0 016.5 17H20" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <div>
            <h1 className="text-emerald-100 font-bold text-xl" style={{ fontFamily: 'Cairo' }}>الكتب والمخطوطات</h1>
            <p className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>Books & Manuscripts</p>
          </div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="glass-card rounded-2xl p-4 mb-5">
        <div className="flex flex-col sm:flex-row gap-3 mb-4">
          <div className="flex-1 relative">
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="ابحث عن كتاب أو مؤلف..."
              className="w-full input-premium rounded-xl px-4 py-3 text-sm pr-10"
              style={{ fontFamily: 'Cairo' }}
            />
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-4 h-4 text-amber-400/50 absolute right-3 top-1/2 -translate-y-1/2">
              <circle cx="11" cy="11" r="8" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M21 21l-4.35-4.35" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value)}
            className="input-premium rounded-xl px-4 py-3 text-sm cursor-pointer"
            style={{ fontFamily: 'Cairo' }}
          >
            <option value="popular">الأكثر تحميلاً</option>
            <option value="newest">الأحدث</option>
            <option value="rating">الأعلى تقييماً</option>
            <option value="alpha">أبجدياً</option>
          </select>
          <div className="flex gap-2">
            <button
              onClick={() => setView('grid')}
              className={`px-3 py-2 rounded-xl transition-all ${view === 'grid' ? 'btn-gold' : 'btn-ghost'}`}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
                <rect x="3" y="3" width="7" height="7" rx="1" strokeLinecap="round" />
                <rect x="14" y="3" width="7" height="7" rx="1" strokeLinecap="round" />
                <rect x="3" y="14" width="7" height="7" rx="1" strokeLinecap="round" />
                <rect x="14" y="14" width="7" height="7" rx="1" strokeLinecap="round" />
              </svg>
            </button>
            <button
              onClick={() => setView('list')}
              className={`px-3 py-2 rounded-xl transition-all ${view === 'list' ? 'btn-gold' : 'btn-ghost'}`}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
                <line x1="8" y1="6" x2="21" y2="6" strokeLinecap="round" />
                <line x1="8" y1="12" x2="21" y2="12" strokeLinecap="round" />
                <line x1="8" y1="18" x2="21" y2="18" strokeLinecap="round" />
                <line x1="3" y1="6" x2="3.01" y2="6" strokeLinecap="round" />
                <line x1="3" y1="12" x2="3.01" y2="12" strokeLinecap="round" />
                <line x1="3" y1="18" x2="3.01" y2="18" strokeLinecap="round" />
              </svg>
            </button>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex gap-2 flex-wrap">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${selectedCategory === cat.id ? 'btn-gold' : 'btn-ghost'}`}
              style={{ fontFamily: 'Cairo' }}
            >
              {cat.name}
              <span className={`mr-1.5 text-xs opacity-60`}>{cat.count}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Results count */}
      <div className="flex items-center justify-between mb-4">
        <p className="text-emerald-400/50 text-sm" style={{ fontFamily: 'Cairo' }}>
          عرض <span className="text-amber-400">{filtered.length}</span> كتاب
        </p>
      </div>

      {/* Books Grid */}
      {view === 'grid' ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 mb-8">
          {filtered.map((book, i) => (
            <BookCard key={book.id} book={book} onClick={() => setSelectedBook(book)} index={i} />
          ))}
        </div>
      ) : (
        <div className="space-y-3 mb-8">
          {filtered.map((book, i) => (
            <div
              key={book.id}
              className="glass-card card-glow rounded-2xl p-4 flex items-center gap-4 cursor-pointer hover:scale-[1.01] transition-all animate-fade-in-up"
              style={{ animationDelay: `${i * 40}ms`, animationFillMode: 'forwards' }}
              onClick={() => setSelectedBook(book)}
            >
              <div className={`w-14 h-20 rounded-xl bg-gradient-to-br ${book.coverColor} flex-shrink-0 flex items-center justify-center`}
                style={{ border: '1px solid rgba(212,175,55,0.2)' }}>
                <svg viewBox="0 0 24 24" fill="none" stroke="#d4af37" strokeWidth={1.5} className="w-6 h-6 opacity-60">
                  <path d="M4 19.5A2.5 2.5 0 016.5 17H20" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
              <div className="flex-1">
                <h3 className="text-amber-200 font-bold text-base mb-0.5" style={{ fontFamily: 'Amiri, serif' }}>{book.titleAr}</h3>
                <p className="text-emerald-400/60 text-xs mb-2" style={{ fontFamily: 'Cairo' }}>{book.authorAr}</p>
                <p className="text-emerald-100/50 text-xs line-clamp-1" style={{ fontFamily: 'Cairo' }}>{book.description}</p>
              </div>
              <div className="flex flex-col items-end gap-2">
                <span className="badge-emerald text-xs px-2 py-0.5 rounded-full" style={{ fontFamily: 'Cairo', fontSize: '10px' }}>{book.categoryAr}</span>
                <div className="flex items-center gap-1">
                  <svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3 text-amber-400">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                  </svg>
                  <span className="text-amber-300/70 text-xs">{book.rating}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {selectedBook && <BookModal book={selectedBook} onClose={() => setSelectedBook(null)} />}
    </div>
  );
};
