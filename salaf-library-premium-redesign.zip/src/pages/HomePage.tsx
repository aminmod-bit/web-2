import React, { useState, useEffect } from 'react';
import { IslamicPattern } from '../components/IslamicPattern';
import { GoldDivider } from '../components/GoldDivider';
import { booksData } from '../data/books';
import { scholarsData } from '../data/scholars';
import { fawaidData } from '../data/fawaid';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

const StatCard: React.FC<{ value: string; label: string; icon: React.ReactNode; delay?: number }> = ({ value, label, icon, delay = 0 }) => (
  <div
    className="glass-card card-glow rounded-2xl p-5 flex items-center gap-4 animate-fade-in-up shimmer"
    style={{ animationDelay: `${delay}ms`, animationFillMode: 'forwards' }}
  >
    <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
      style={{ background: 'linear-gradient(135deg, rgba(22,101,52,0.5), rgba(20,83,45,0.3))', border: '1px solid rgba(212,175,55,0.2)' }}>
      <span className="text-amber-400">{icon}</span>
    </div>
    <div>
      <p className="text-2xl font-bold text-amber-300" style={{ fontFamily: 'Cairo' }}>{value}</p>
      <p className="text-emerald-400/60 text-xs font-medium" style={{ fontFamily: 'Cairo' }}>{label}</p>
    </div>
  </div>
);

const FeaturedBookCard: React.FC<{ book: typeof booksData[0]; index: number }> = ({ book, index }) => (
  <div
    className="glass-card card-glow rounded-2xl overflow-hidden group cursor-pointer animate-fade-in-up"
    style={{ animationDelay: `${index * 100}ms`, animationFillMode: 'forwards' }}
  >
    {/* Book Cover */}
    <div className={`h-40 relative overflow-hidden bg-gradient-to-br ${book.coverColor}`}>
      <IslamicPattern opacity={0.06} />
      {/* Decorative elements */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center relative z-10">
          <p className="text-amber-300/80 text-2xl mb-1" style={{ fontFamily: 'Amiri, serif' }}>
            {book.titleAr.split(' ').slice(0, 2).join(' ')}
          </p>
          <div className="w-12 h-0.5 mx-auto" style={{ background: 'linear-gradient(90deg, transparent, #d4af37, transparent)' }} />
        </div>
      </div>
      {book.tag && (
        <div className="absolute top-3 right-3">
          <span className="badge-gold text-xs px-2.5 py-1 rounded-full font-semibold" style={{ fontFamily: 'Cairo' }}>
            {book.tag}
          </span>
        </div>
      )}
      {/* Shine effect on hover */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
    </div>

    {/* Book Info */}
    <div className="p-4">
      <h3 className="text-amber-200 font-bold text-base mb-1 line-clamp-1" style={{ fontFamily: 'Amiri, serif' }}>
        {book.titleAr}
      </h3>
      <p className="text-emerald-400/60 text-xs mb-3" style={{ fontFamily: 'Cairo' }}>{book.authorAr}</p>
      <p className="text-emerald-100/50 text-xs mb-3 line-clamp-2 leading-relaxed" style={{ fontFamily: 'Cairo' }}>
        {book.description}
      </p>
      <div className="flex items-center justify-between">
        <span className="badge-emerald text-xs px-2 py-0.5 rounded-full" style={{ fontFamily: 'Cairo' }}>
          {book.categoryAr}
        </span>
        <div className="flex items-center gap-1">
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3 text-amber-400">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
          </svg>
          <span className="text-amber-300/70 text-xs">{book.rating}</span>
        </div>
      </div>
    </div>
  </div>
);

const fawaidRotate = [
  fawaidData[0],
  fawaidData[3],
  fawaidData[5],
];

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const [currentFaida, setCurrentFaida] = useState(0);
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setCurrentFaida(p => (p + 1) % fawaidRotate.length), 6000);
    const t2 = setInterval(() => setTime(new Date()), 1000);
    return () => { clearInterval(t); clearInterval(t2); };
  }, []);

  let hijriDate = '';
  try {
    hijriDate = new Intl.DateTimeFormat('ar-SA-u-ca-islamic', {
      year: 'numeric', month: 'long', day: 'numeric'
    }).format(time);
  } catch {
    hijriDate = new Intl.DateTimeFormat('ar', { year: 'numeric', month: 'long', day: 'numeric' }).format(time);
  }

  return (
    <div className="relative min-h-full">
      <IslamicPattern opacity={0.025} />

      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-3xl mx-4 mt-4 mb-6"
        style={{
          background: 'linear-gradient(135deg, #031a0d 0%, #0a3320 30%, #062213 60%, #0d2e1a 100%)',
          border: '1px solid rgba(212, 175, 55, 0.15)',
          boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
          minHeight: '280px',
        }}>
        <IslamicPattern opacity={0.05} />

        {/* Glow orbs */}
        <div className="absolute top-0 right-0 w-64 h-64 rounded-full opacity-10 blur-3xl"
          style={{ background: 'radial-gradient(circle, #d4af37, transparent)' }} />
        <div className="absolute bottom-0 left-0 w-48 h-48 rounded-full opacity-8 blur-3xl"
          style={{ background: 'radial-gradient(circle, #22c55e, transparent)' }} />

        <div className="relative z-10 p-8 flex flex-col lg:flex-row items-center gap-8">
          <div className="flex-1 text-center lg:text-right">
            {/* Hijri date badge */}
            <div className="inline-flex items-center gap-2 badge-gold px-4 py-1.5 rounded-full mb-5 text-xs font-medium"
              style={{ fontFamily: 'Cairo' }}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-3.5 h-3.5">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2" strokeLinecap="round" strokeLinejoin="round" />
                <line x1="16" y1="2" x2="16" y2="6" strokeLinecap="round" strokeLinejoin="round" />
                <line x1="8" y1="2" x2="8" y2="6" strokeLinecap="round" strokeLinejoin="round" />
                <line x1="3" y1="10" x2="21" y2="10" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span>{hijriDate}</span>
            </div>

            <h1 className="text-4xl lg:text-5xl font-bold mb-3 leading-tight" style={{ fontFamily: 'Amiri, serif' }}>
              <span className="text-shimmer">مكتبة السلف</span>
            </h1>
            <p className="text-emerald-300/60 text-base mb-2 tracking-widest font-light">SALAF LIBRARY</p>
            <p className="text-emerald-100/70 text-sm leading-relaxed max-w-lg mx-auto lg:mr-0" style={{ fontFamily: 'Cairo' }}>
              مكتبة رقمية متكاملة تجمع أمهات الكتب الإسلامية من الحديث والعقيدة والفقه والتفسير والسيرة على منهج السلف الصالح
            </p>

            <div className="flex flex-wrap gap-3 mt-6 justify-center lg:justify-start">
              <button
                onClick={() => onNavigate('books')}
                className="btn-gold px-6 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2"
                style={{ fontFamily: 'Cairo' }}
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
                  <path d="M4 19.5A2.5 2.5 0 016.5 17H20" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                استعرض الكتب
              </button>
              <button
                onClick={() => onNavigate('search')}
                className="btn-ghost px-6 py-2.5 rounded-xl text-sm font-semibold flex items-center gap-2"
                style={{ fontFamily: 'Cairo' }}
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
                  <circle cx="11" cy="11" r="8" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M21 21l-4.35-4.35" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                بحث متقدم
              </button>
            </div>
          </div>

          {/* Decorative element - Arabic quote panel */}
          <div className="flex-shrink-0 hidden lg:block">
            <div
              className="rounded-3xl p-5 text-center relative overflow-hidden animate-float"
              style={{
                background: 'rgba(212, 175, 55, 0.06)',
                border: '1px solid rgba(212, 175, 55, 0.2)',
                width: '200px',
                boxShadow: '0 8px 32px rgba(0,0,0,0.3), inset 0 1px 0 rgba(212,175,55,0.15)',
              }}
            >
              <div className="absolute top-0 left-0 right-0 h-px" style={{ background: 'linear-gradient(90deg, transparent, #d4af37, transparent)' }} />
              <p className="text-amber-300/70 text-3xl leading-loose mb-2" style={{ fontFamily: 'Amiri, serif', lineHeight: '2' }}>
                «اقرأ باسم ربك»
              </p>
              <div className="gold-divider mb-2" />
              <p className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>سورة العلق — الآية الأولى</p>

              {/* Decorative books */}
              <div className="flex justify-center gap-1.5 mt-3">
                {['from-emerald-800', 'from-teal-800', 'from-amber-900'].map((color, i) => (
                  <div key={i}
                    className={`rounded bg-gradient-to-t ${color} to-transparent`}
                    style={{
                      width: `${18 + i * 4}px`,
                      height: `${44 + i * 8}px`,
                      border: '1px solid rgba(212,175,55,0.15)',
                      transform: `rotate(${(i - 1) * 4}deg)`,
                    }} />
                ))}
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-px" style={{ background: 'linear-gradient(90deg, transparent, #d4af37, transparent)' }} />
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 px-4 mb-6">
        {[
          { value: '2,480+', label: 'كتاب ومخطوطة', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-6 h-6"><path d="M4 19.5A2.5 2.5 0 016.5 17H20" strokeLinecap="round" strokeLinejoin="round" /><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" strokeLinecap="round" strokeLinejoin="round" /></svg>, delay: 0 },
          { value: '380+', label: 'عالم وفقيه', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-6 h-6"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" strokeLinecap="round" strokeLinejoin="round" /><circle cx="12" cy="7" r="4" strokeLinecap="round" strokeLinejoin="round" /></svg>, delay: 100 },
          { value: '1,200+', label: 'محاضرة صوتية', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-6 h-6"><path d="M9 18V5l12-2v13" strokeLinecap="round" strokeLinejoin="round" /><circle cx="6" cy="18" r="3" strokeLinecap="round" strokeLinejoin="round" /><circle cx="18" cy="16" r="3" strokeLinecap="round" strokeLinejoin="round" /></svg>, delay: 200 },
          { value: '5,000+', label: 'فائدة ودُرّة', icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-6 h-6"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" strokeLinecap="round" strokeLinejoin="round" /></svg>, delay: 300 },
        ].map((s, i) => (
          <StatCard key={i} {...s} />
        ))}
      </div>

      {/* Daily Faida */}
      <div className="mx-4 mb-6">
        <div
          className="rounded-2xl p-6 relative overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, rgba(20, 83, 45, 0.3), rgba(7, 26, 18, 0.8))',
            border: '1px solid rgba(212, 175, 55, 0.2)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
          }}
        >
          <IslamicPattern opacity={0.04} />
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-4">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4 text-amber-400">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span className="text-amber-400 text-xs font-bold tracking-wider uppercase" style={{ fontFamily: 'Cairo' }}>فائدة اليوم</span>
            </div>

            <div className="transition-all duration-700" key={currentFaida}>
              <p className="text-amber-200/90 text-xl leading-relaxed mb-4 text-center"
                style={{ fontFamily: 'Amiri, serif', lineHeight: '2' }}>
                «{fawaidRotate[currentFaida].textAr}»
              </p>
              <div className="gold-divider mb-3" />
              <p className="text-emerald-400/70 text-xs text-center" style={{ fontFamily: 'Cairo' }}>
                — {fawaidRotate[currentFaida].sourceAr}
              </p>
            </div>

            {/* Dots */}
            <div className="flex justify-center gap-1.5 mt-4">
              {fawaidRotate.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentFaida(i)}
                  className={`rounded-full transition-all ${i === currentFaida ? 'w-4 h-1.5 bg-amber-400' : 'w-1.5 h-1.5 bg-emerald-600/50'}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Featured Books */}
      <div className="px-4 mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-1 h-6 rounded-full" style={{ background: 'linear-gradient(180deg, #d4af37, #b8962e)' }} />
            <h2 className="text-emerald-100 font-bold text-lg" style={{ fontFamily: 'Cairo' }}>الكتب المميزة</h2>
          </div>
          <button
            onClick={() => onNavigate('books')}
            className="text-amber-400/70 text-sm flex items-center gap-1.5 hover:text-amber-400 transition-colors"
            style={{ fontFamily: 'Cairo' }}
          >
            عرض الكل
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4 rotate-180">
              <polyline points="9 18 15 12 9 6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {booksData.filter(b => b.isFeatured).slice(0, 4).map((book, i) => (
            <FeaturedBookCard key={book.id} book={book} index={i} />
          ))}
        </div>
      </div>

      <GoldDivider withIcon className="mx-4 mb-6" />

      {/* Quick Access */}
      <div className="px-4 mb-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-1 h-6 rounded-full" style={{ background: 'linear-gradient(180deg, #d4af37, #b8962e)' }} />
          <h2 className="text-emerald-100 font-bold text-lg" style={{ fontFamily: 'Cairo' }}>الأقسام</h2>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {[
            { id: 'books', label: 'الكتب', count: '2,480+', emoji: '📚', desc: 'أمهات الكتب والمراجع' },
            { id: 'scholars', label: 'التراجم', count: '380+', emoji: '👤', desc: 'سير العلماء والأئمة' },
            { id: 'audio', label: 'الصوتيات', count: '1,200+', emoji: '🎙️', desc: 'محاضرات ودروس مسجلة' },
            { id: 'fawaid', label: 'الفوائد', count: '5,000+', emoji: '✨', desc: 'درر وفرائد العلماء' },
            { id: 'search', label: 'البحث', count: 'شامل', emoji: '🔍', desc: 'بحث في المكتبة كاملة' },
            { id: 'dashboard', label: 'الإحصاءات', count: 'لوحة', emoji: '📊', desc: 'تقارير وإحصاءات المكتبة' },
          ].map((item, i) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="glass-card card-glow rounded-2xl p-4 text-right group hover:scale-[1.02] transition-all duration-200 animate-fade-in-up"
              style={{ animationDelay: `${i * 80}ms`, animationFillMode: 'forwards' }}
            >
              <div className="text-2xl mb-2">{item.emoji}</div>
              <h3 className="text-amber-300 font-bold text-sm mb-0.5" style={{ fontFamily: 'Cairo' }}>{item.label}</h3>
              <p className="text-emerald-400/50 text-xs mb-1" style={{ fontFamily: 'Cairo' }}>{item.desc}</p>
              <span className="text-xs text-amber-400/60 font-semibold" style={{ fontFamily: 'Cairo' }}>{item.count}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Recent Scholars */}
      <div className="px-4 mb-8">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-1 h-6 rounded-full" style={{ background: 'linear-gradient(180deg, #d4af37, #b8962e)' }} />
            <h2 className="text-emerald-100 font-bold text-lg" style={{ fontFamily: 'Cairo' }}>أبرز العلماء</h2>
          </div>
          <button
            onClick={() => onNavigate('scholars')}
            className="text-amber-400/70 text-sm hover:text-amber-400 transition-colors"
            style={{ fontFamily: 'Cairo' }}
          >
            عرض الكل ←
          </button>
        </div>
        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-thin">
          {scholarsData.slice(0, 5).map((scholar) => (
            <div key={scholar.id}
              className="flex-shrink-0 glass-card card-glow rounded-2xl p-4 w-48 text-center cursor-pointer hover:scale-[1.03] transition-all">
              <div className={`w-14 h-14 rounded-2xl mx-auto mb-3 flex items-center justify-center text-2xl font-bold bg-gradient-to-br ${scholar.gradient}`}
                style={{ color: '#d4af37', boxShadow: '0 4px 16px rgba(0,0,0,0.3)' }}>
                {scholar.initials}
              </div>
              <p className="text-amber-200 font-bold text-sm mb-1" style={{ fontFamily: 'Amiri, serif' }}>{scholar.nameAr}</p>
              <p className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>{scholar.titleAr}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
