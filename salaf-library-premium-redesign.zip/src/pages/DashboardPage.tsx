import React from 'react';
import { IslamicPattern } from '../components/IslamicPattern';
import { GoldDivider } from '../components/GoldDivider';

interface StatBoxProps {
  label: string;
  value: string;
  change: string;
  positive: boolean;
  icon: React.ReactNode;
  color: string;
}

const StatBox: React.FC<StatBoxProps> = ({ label, value, change, positive, icon, color }) => (
  <div className="glass-card card-glow rounded-2xl p-5 relative overflow-hidden">
    <div className="absolute top-0 left-0 right-0 h-0.5" style={{ background: color }} />
    <div className="flex items-start justify-between mb-3">
      <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${color}20`, border: `1px solid ${color}30` }}>
        <span style={{ color }}>{icon}</span>
      </div>
      <span className={`text-xs px-2 py-1 rounded-full font-semibold ${positive ? 'text-emerald-400 bg-emerald-400/10' : 'text-red-400 bg-red-400/10'}`} style={{ fontFamily: 'Cairo' }}>
        {positive ? '↑' : '↓'} {change}
      </span>
    </div>
    <p className="text-2xl font-bold text-emerald-100 mb-1" style={{ fontFamily: 'Cairo' }}>{value}</p>
    <p className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>{label}</p>
  </div>
);

const barData = [
  { label: 'حديث', value: 64, color: '#d4af37' },
  { label: 'فقه', value: 58, color: '#22c55e' },
  { label: 'عقيدة', value: 42, color: '#3b82f6' },
  { label: 'تفسير', value: 31, color: '#8b5cf6' },
  { label: 'سيرة', value: 27, color: '#f97316' },
  { label: 'زهد', value: 26, color: '#ec4899' },
];

const recentActivities = [
  { action: 'تم رفع كتاب جديد', detail: 'تفسير ابن كثير — المجلد الأول', time: 'منذ 10 دقائق', icon: '📚' },
  { action: 'تم إضافة عالم جديد', detail: 'الإمام الشافعي — ترجمة موسعة', time: 'منذ 1 ساعة', icon: '👤' },
  { action: 'تحديث قسم الفوائد', detail: 'إضافة 15 فائدة جديدة', time: 'منذ 3 ساعات', icon: '✨' },
  { action: 'رفع محاضرة صوتية', detail: 'شرح الأربعين النووية — الحلقة 5', time: 'منذ 5 ساعات', icon: '🎙️' },
  { action: 'تعديل بيانات كتاب', detail: 'صحيح البخاري — تحديث الوصف', time: 'أمس', icon: '✏️' },
];

export const DashboardPage: React.FC = () => {
  return (
    <div className="relative min-h-full p-4">
      <IslamicPattern opacity={0.02} />

      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg, #d4af37, #b8962e)', boxShadow: '0 4px 12px rgba(212,175,55,0.3)' }}>
            <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2} className="w-4 h-4">
              <rect x="3" y="3" width="7" height="7" rx="1" strokeLinecap="round" strokeLinejoin="round" />
              <rect x="14" y="3" width="7" height="7" rx="1" strokeLinecap="round" strokeLinejoin="round" />
              <rect x="3" y="14" width="7" height="7" rx="1" strokeLinecap="round" strokeLinejoin="round" />
              <rect x="14" y="14" width="7" height="7" rx="1" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <div>
            <h1 className="text-emerald-100 font-bold text-xl" style={{ fontFamily: 'Cairo' }}>لوحة التحكم</h1>
            <p className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>Dashboard & Analytics</p>
          </div>
        </div>
        <button className="btn-gold px-4 py-2 rounded-xl text-xs flex items-center gap-2" style={{ fontFamily: 'Cairo' }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-3.5 h-3.5">
            <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" strokeLinecap="round" strokeLinejoin="round" />
            <polyline points="7 10 12 15 17 10" strokeLinecap="round" strokeLinejoin="round" />
            <line x1="12" y1="15" x2="12" y2="3" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          تصدير التقرير
        </button>
      </div>

      {/* Welcome banner */}
      <div
        className="rounded-2xl p-5 mb-6 relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, rgba(20, 83, 45, 0.3) 0%, rgba(7, 26, 18, 0.8) 100%)',
          border: '1px solid rgba(212, 175, 55, 0.15)',
        }}
      >
        <IslamicPattern opacity={0.04} />
        <div className="relative z-10 flex items-center justify-between">
          <div>
            <p className="text-amber-400 text-xs font-semibold mb-1" style={{ fontFamily: 'Cairo' }}>مرحباً بك</p>
            <h2 className="text-emerald-100 font-bold text-lg" style={{ fontFamily: 'Cairo' }}>محمد أحمد</h2>
            <p className="text-emerald-400/50 text-xs mt-0.5" style={{ fontFamily: 'Cairo' }}>مدير مكتبة السلف</p>
          </div>
          <div className="text-5xl opacity-20">📊</div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        <StatBox
          label="إجمالي الكتب"
          value="2,480"
          change="12%"
          positive={true}
          color="#d4af37"
          icon={<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-5 h-5"><path d="M4 19.5A2.5 2.5 0 016.5 17H20" strokeLinecap="round" strokeLinejoin="round" /><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" strokeLinecap="round" strokeLinejoin="round" /></svg>}
        />
        <StatBox
          label="إجمالي العلماء"
          value="380"
          change="8%"
          positive={true}
          color="#22c55e"
          icon={<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-5 h-5"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" strokeLinecap="round" strokeLinejoin="round" /><circle cx="12" cy="7" r="4" strokeLinecap="round" strokeLinejoin="round" /></svg>}
        />
        <StatBox
          label="إجمالي المحاضرات"
          value="1,204"
          change="23%"
          positive={true}
          color="#3b82f6"
          icon={<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-5 h-5"><path d="M9 18V5l12-2v13" strokeLinecap="round" strokeLinejoin="round" /><circle cx="6" cy="18" r="3" strokeLinecap="round" strokeLinejoin="round" /><circle cx="18" cy="16" r="3" strokeLinecap="round" strokeLinejoin="round" /></svg>}
        />
        <StatBox
          label="إجمالي التحميلات"
          value="845k"
          change="31%"
          positive={true}
          color="#8b5cf6"
          icon={<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-5 h-5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" strokeLinecap="round" strokeLinejoin="round" /><polyline points="7 10 12 15 17 10" strokeLinecap="round" strokeLinejoin="round" /><line x1="12" y1="15" x2="12" y2="3" strokeLinecap="round" strokeLinejoin="round" /></svg>}
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        {/* Bar chart - Books by category */}
        <div className="glass-card rounded-2xl p-5">
          <h3 className="text-emerald-100 font-semibold text-sm mb-4" style={{ fontFamily: 'Cairo' }}>توزيع الكتب حسب القسم</h3>
          <div className="space-y-3">
            {barData.map((item, i) => (
              <div key={i}>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-emerald-100/70 text-xs" style={{ fontFamily: 'Cairo' }}>{item.label}</span>
                  <span className="text-xs font-semibold" style={{ color: item.color, fontFamily: 'Cairo' }}>{item.value}</span>
                </div>
                <div className="h-2 rounded-full" style={{ background: 'rgba(255,255,255,0.05)' }}>
                  <div
                    className="h-full rounded-full transition-all duration-1000"
                    style={{
                      width: `${(item.value / 70) * 100}%`,
                      background: `linear-gradient(90deg, ${item.color}80, ${item.color})`,
                      boxShadow: `0 0 8px ${item.color}40`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Donut-style stats */}
        <div className="glass-card rounded-2xl p-5">
          <h3 className="text-emerald-100 font-semibold text-sm mb-4" style={{ fontFamily: 'Cairo' }}>ملخص المحتوى</h3>
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'كتب PDF', value: '1,840', pct: '74%', color: '#d4af37' },
              { label: 'مخطوطات', value: '640', pct: '26%', color: '#22c55e' },
              { label: 'محاضرات MP3', value: '980', pct: '81%', color: '#3b82f6' },
              { label: 'مقاطع فيديو', value: '224', pct: '19%', color: '#8b5cf6' },
            ].map((item, i) => (
              <div key={i} className="glass-light rounded-xl p-3 relative overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-0.5 rounded-t-xl" style={{ background: item.color }} />
                <p className="text-xs mb-1" style={{ color: item.color, fontFamily: 'Cairo' }}>{item.label}</p>
                <p className="text-emerald-100 font-bold text-lg" style={{ fontFamily: 'Cairo' }}>{item.value}</p>
                <p className="text-emerald-400/40 text-xs" style={{ fontFamily: 'Cairo' }}>{item.pct} من الكل</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Weekly downloads chart (improved) */}
      <div className="glass-card rounded-2xl p-5 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-emerald-100 font-semibold text-sm" style={{ fontFamily: 'Cairo' }}>التحميلات الأسبوعية</h3>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-sm" style={{ background: 'linear-gradient(135deg, #d4af37, #b8962e)' }} />
              <span className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>هذا الأسبوع</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-sm" style={{ background: 'rgba(22,101,52,0.6)' }} />
              <span className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>الأسبوع الماضي</span>
            </div>
          </div>
        </div>
        <div className="flex items-end gap-2 h-32">
          {[
            { curr: 40, prev: 30 },
            { curr: 65, prev: 50 },
            { curr: 45, prev: 60 },
            { curr: 80, prev: 65 },
            { curr: 55, prev: 45 },
            { curr: 90, prev: 70 },
            { curr: 70, prev: 55 },
          ].map((data, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-0.5">
              <div className="w-full flex gap-0.5 items-end" style={{ height: '100px' }}>
                <div
                  className="flex-1 rounded-t-lg transition-all"
                  style={{
                    height: `${data.prev}%`,
                    background: 'rgba(22,101,52,0.35)',
                    border: '1px solid rgba(22,101,52,0.4)',
                    borderBottom: 'none',
                  }}
                />
                <div
                  className="flex-1 rounded-t-lg transition-all"
                  style={{
                    height: `${data.curr}%`,
                    background: i === 5 ? 'linear-gradient(180deg, #d4af37, #b8962e)' : 'linear-gradient(180deg, rgba(22,101,52,0.8), rgba(20,83,45,0.5))',
                    boxShadow: i === 5 ? '0 0 12px rgba(212,175,55,0.3)' : 'none',
                    border: i === 5 ? '1px solid rgba(212,175,55,0.3)' : '1px solid rgba(22,101,52,0.5)',
                    borderBottom: 'none',
                  }}
                />
              </div>
              <span className="text-emerald-400/40 text-xs" style={{ fontFamily: 'Cairo', fontSize: '10px' }}>
                {['أح', 'إث', 'ثل', 'أر', 'خم', 'جم', 'سب'][i]}
              </span>
            </div>
          ))}
        </div>
        <div className="mt-3 flex items-center justify-between">
          <span className="text-emerald-400/40 text-xs" style={{ fontFamily: 'Cairo' }}>إجمالي هذا الأسبوع: 12,480 تحميل</span>
          <span className="text-emerald-400 text-xs font-semibold" style={{ fontFamily: 'Cairo' }}>↑ 18.5% من الأسبوع الماضي</span>
        </div>
      </div>

      <GoldDivider withIcon className="mb-6" />

      {/* Recent activity */}
      <div className="glass-card rounded-2xl p-5 mb-8">
        <h3 className="text-emerald-100 font-semibold text-sm mb-4" style={{ fontFamily: 'Cairo' }}>النشاط الأخير</h3>
        <div className="space-y-3">
          {recentActivities.map((activity, i) => (
            <div key={i} className="flex items-start gap-3 pb-3 border-b border-white/5 last:border-0">
              <div className="w-8 h-8 rounded-xl flex items-center justify-center text-base flex-shrink-0"
                style={{ background: 'rgba(255,255,255,0.05)' }}>
                {activity.icon}
              </div>
              <div className="flex-1">
                <p className="text-emerald-100/80 text-xs font-semibold" style={{ fontFamily: 'Cairo' }}>{activity.action}</p>
                <p className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>{activity.detail}</p>
              </div>
              <span className="text-emerald-400/40 text-xs flex-shrink-0" style={{ fontFamily: 'Cairo' }}>{activity.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
