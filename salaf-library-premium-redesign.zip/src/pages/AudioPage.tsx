import React, { useState } from 'react';
import { IslamicPattern } from '../components/IslamicPattern';
import { GoldDivider } from '../components/GoldDivider';
import { audioData, AudioTrack } from '../data/audio';

const AudioPlayerBar: React.FC<{ track: AudioTrack; onClose: () => void }> = ({ track, onClose }) => {
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(30);

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-50 p-4"
      style={{
        background: 'rgba(3, 15, 8, 0.97)',
        borderTop: '1px solid rgba(212, 175, 55, 0.2)',
        backdropFilter: 'blur(20px)',
        boxShadow: '0 -8px 40px rgba(0,0,0,0.5)',
      }}
    >
      <div className="max-w-4xl mx-auto flex items-center gap-4">
        {/* Track info */}
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 bg-gradient-to-br ${track.gradient}`}
          style={{ color: '#d4af37', fontFamily: 'Amiri, serif', fontWeight: 'bold' }}>
          {track.initials}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-amber-200 text-xs font-semibold line-clamp-1" style={{ fontFamily: 'Cairo' }}>{track.titleAr}</p>
          <p className="text-emerald-400/50 text-xs line-clamp-1" style={{ fontFamily: 'Cairo' }}>{track.sheikhAr}</p>
          {/* Progress bar */}
          <div className="mt-1.5 relative">
            <div className="h-1 rounded-full" style={{ background: 'rgba(212,175,55,0.15)' }}>
              <div
                className="h-full rounded-full transition-all"
                style={{ width: `${progress}%`, background: 'linear-gradient(90deg, #d4af37, #b8962e)' }}
              />
            </div>
            <input
              type="range" min="0" max="100" value={progress}
              onChange={e => setProgress(Number(e.target.value))}
              className="absolute inset-0 w-full opacity-0 cursor-pointer h-1"
            />
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <button className="w-8 h-8 flex items-center justify-center text-emerald-400/50 hover:text-emerald-300 transition-colors">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
              <polygon points="19 20 9 12 19 4 19 20" strokeLinecap="round" strokeLinejoin="round" />
              <line x1="5" y1="19" x2="5" y2="5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <button
            onClick={() => setPlaying(!playing)}
            className="w-10 h-10 rounded-full flex items-center justify-center transition-all"
            style={{ background: 'linear-gradient(135deg, #d4af37, #b8962e)', boxShadow: '0 4px 15px rgba(212,175,55,0.4)' }}
          >
            {playing ? (
              <svg viewBox="0 0 24 24" fill="white" className="w-4 h-4">
                <rect x="6" y="4" width="4" height="16" rx="1" />
                <rect x="14" y="4" width="4" height="16" rx="1" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" fill="white" className="w-4 h-4">
                <polygon points="5 3 19 12 5 21 5 3" />
              </svg>
            )}
          </button>
          <button className="w-8 h-8 flex items-center justify-center text-emerald-400/50 hover:text-emerald-300 transition-colors">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
              <polygon points="5 4 15 12 5 20 5 4" strokeLinecap="round" strokeLinejoin="round" />
              <line x1="19" y1="5" x2="19" y2="19" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>

        {/* Time */}
        <span className="text-emerald-400/50 text-xs hidden sm:block" style={{ fontFamily: 'Cairo' }}>
          {Math.floor(progress * 0.01 * 48)}:{String(Math.floor((progress * 0.01 * 48 * 60) % 60)).padStart(2, '0')} / {track.duration}
        </span>

        {/* Close */}
        <button onClick={onClose} className="w-7 h-7 flex items-center justify-center text-emerald-400/40 hover:text-red-400 transition-colors">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
            <line x1="18" y1="6" x2="6" y2="18" strokeLinecap="round" />
            <line x1="6" y1="6" x2="18" y2="18" strokeLinecap="round" />
          </svg>
        </button>
      </div>
    </div>
  );
};

const AudioCard: React.FC<{ track: AudioTrack; onPlay: () => void; isPlaying: boolean; index: number }> = ({ track, onPlay, isPlaying, index }) => (
  <div
    className={`glass-card card-glow rounded-2xl p-4 cursor-pointer hover:scale-[1.01] transition-all duration-200 animate-fade-in-up
      ${isPlaying ? 'ring-1 ring-amber-400/40' : ''}`}
    style={{ animationDelay: `${index * 60}ms`, animationFillMode: 'forwards' }}
  >
    <div className="flex items-start gap-4">
      {/* Cover */}
      <div className={`w-14 h-14 rounded-xl flex-shrink-0 flex items-center justify-center text-xl font-bold bg-gradient-to-br ${track.gradient} relative`}
        style={{ color: '#d4af37', fontFamily: 'Amiri, serif', boxShadow: '0 4px 16px rgba(0,0,0,0.4)' }}>
        {track.initials}
        {isPlaying && (
          <div className="absolute inset-0 rounded-xl flex items-center justify-center bg-black/40">
            <div className="flex items-end gap-0.5 h-5">
              {[0.6, 1, 0.7, 1, 0.8].map((h, i) => (
                <div key={i} className="w-0.5 rounded-full animate-pulse"
                  style={{ height: `${h * 20}px`, background: '#d4af37', animationDelay: `${i * 0.1}s` }} />
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <div>
            <h3 className="text-amber-200 font-bold text-sm line-clamp-1 mb-0.5" style={{ fontFamily: 'Cairo' }}>{track.titleAr}</h3>
            <p className="text-emerald-400/60 text-xs" style={{ fontFamily: 'Cairo' }}>{track.sheikhAr}</p>
          </div>
          {track.isNew && (
            <span className="badge-gold text-xs px-2 py-0.5 rounded-full flex-shrink-0" style={{ fontFamily: 'Cairo', fontSize: '10px' }}>
              جديد
            </span>
          )}
        </div>

        <p className="text-emerald-100/40 text-xs mt-1.5 line-clamp-1" style={{ fontFamily: 'Cairo' }}>{track.description}</p>

        <div className="flex items-center justify-between mt-3">
          <div className="flex items-center gap-3">
            <span className="badge-emerald text-xs px-2 py-0.5 rounded-full" style={{ fontFamily: 'Cairo', fontSize: '10px' }}>
              {track.categoryAr}
            </span>
            <div className="flex items-center gap-1 text-emerald-400/40 text-xs" style={{ fontFamily: 'Cairo' }}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-3 h-3">
                <polygon points="5 3 19 12 5 21 5 3" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              {(track.plays / 1000).toFixed(1)}k
            </div>
            <div className="flex items-center gap-1 text-emerald-400/40 text-xs" style={{ fontFamily: 'Cairo' }}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-3 h-3">
                <circle cx="12" cy="12" r="10" strokeLinecap="round" strokeLinejoin="round" />
                <polyline points="12 6 12 12 16 14" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              {track.duration}
            </div>
          </div>

          <button
            onClick={onPlay}
            className="w-9 h-9 rounded-xl flex items-center justify-center transition-all"
            style={isPlaying
              ? { background: 'rgba(212,175,55,0.2)', border: '1px solid rgba(212,175,55,0.4)' }
              : { background: 'linear-gradient(135deg, #166534, #14532d)', border: '1px solid rgba(212,175,55,0.2)' }}
          >
            {isPlaying ? (
              <svg viewBox="0 0 24 24" fill="#d4af37" className="w-4 h-4">
                <rect x="6" y="4" width="4" height="16" rx="1" />
                <rect x="14" y="4" width="4" height="16" rx="1" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" fill="#d4af37" className="w-4 h-4">
                <polygon points="5 3 19 12 5 21 5 3" />
              </svg>
            )}
          </button>
        </div>
      </div>
    </div>
  </div>
);

export const AudioPage: React.FC = () => {
  const [currentTrack, setCurrentTrack] = useState<AudioTrack | null>(null);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');

  const categories = ['all', ...Array.from(new Set(audioData.map(a => a.categoryAr)))];
  const filtered = audioData.filter(a => {
    const matchSearch = !search || a.titleAr.includes(search) || a.sheikhAr.includes(search);
    const matchCat = category === 'all' || a.categoryAr === category;
    return matchSearch && matchCat;
  });

  const featured = audioData.filter(a => a.isFeatured);

  return (
    <div className="relative min-h-full p-4" style={{ paddingBottom: currentTrack ? '100px' : '32px' }}>
      <IslamicPattern opacity={0.02} />

      {/* Header */}
      <div className="mb-6 flex items-center gap-3">
        <div className="w-8 h-8 rounded-xl flex items-center justify-center"
          style={{ background: 'linear-gradient(135deg, #d4af37, #b8962e)', boxShadow: '0 4px 12px rgba(212,175,55,0.3)' }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2} className="w-4 h-4">
            <path d="M9 18V5l12-2v13" strokeLinecap="round" strokeLinejoin="round" />
            <circle cx="6" cy="18" r="3" strokeLinecap="round" strokeLinejoin="round" />
            <circle cx="18" cy="16" r="3" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <div>
          <h1 className="text-emerald-100 font-bold text-xl" style={{ fontFamily: 'Cairo' }}>المقاطع الصوتية</h1>
          <p className="text-emerald-400/50 text-xs" style={{ fontFamily: 'Cairo' }}>Audio Library</p>
        </div>
      </div>

      {/* Featured */}
      <div className="mb-5">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-1 h-5 rounded-full" style={{ background: 'linear-gradient(180deg, #d4af37, #b8962e)' }} />
          <h2 className="text-emerald-100 font-semibold text-base" style={{ fontFamily: 'Cairo' }}>المحاضرات المميزة</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {featured.map((track) => (
            <div
              key={track.id}
              className="rounded-2xl p-4 cursor-pointer relative overflow-hidden group hover:scale-[1.02] transition-all"
              style={{
                background: 'linear-gradient(135deg, rgba(20, 83, 45, 0.25), rgba(7, 26, 18, 0.7))',
                border: '1px solid rgba(212, 175, 55, 0.15)',
              }}
              onClick={() => setCurrentTrack(track)}
            >
              <IslamicPattern opacity={0.04} />
              <div className="relative z-10 flex items-center gap-3">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl font-bold bg-gradient-to-br ${track.gradient}`}
                  style={{ color: '#d4af37', fontFamily: 'Amiri, serif', boxShadow: '0 4px 12px rgba(0,0,0,0.4)' }}>
                  {track.initials}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-amber-200 font-semibold text-sm line-clamp-1" style={{ fontFamily: 'Cairo' }}>{track.titleAr}</h3>
                  <p className="text-emerald-400/60 text-xs" style={{ fontFamily: 'Cairo' }}>{track.sheikhAr}</p>
                  <p className="text-emerald-400/40 text-xs mt-0.5" style={{ fontFamily: 'Cairo' }}>⏱ {track.duration}</p>
                </div>
                <button
                  className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ background: 'linear-gradient(135deg, #d4af37, #b8962e)', boxShadow: '0 4px 12px rgba(212,175,55,0.3)' }}
                >
                  <svg viewBox="0 0 24 24" fill="#071a12" className="w-4 h-4">
                    <polygon points="5 3 19 12 5 21 5 3" />
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <GoldDivider withIcon className="mb-5" />

      {/* Search & Filter */}
      <div className="glass-card rounded-2xl p-4 mb-5">
        <div className="flex gap-3 mb-3">
          <div className="flex-1 relative">
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="ابحث في المحاضرات..."
              className="w-full input-premium rounded-xl px-4 py-3 text-sm pr-10"
              style={{ fontFamily: 'Cairo' }}
            />
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-4 h-4 text-amber-400/50 absolute right-3 top-1/2 -translate-y-1/2">
              <circle cx="11" cy="11" r="8" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M21 21l-4.35-4.35" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${category === cat ? 'btn-gold' : 'btn-ghost'}`}
              style={{ fontFamily: 'Cairo' }}
            >
              {cat === 'all' ? 'الكل' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Track list */}
      <div className="space-y-3">
        {filtered.map((track, i) => (
          <AudioCard
            key={track.id}
            track={track}
            onPlay={() => setCurrentTrack(currentTrack?.id === track.id ? null : track)}
            isPlaying={currentTrack?.id === track.id}
            index={i}
          />
        ))}
      </div>

      {currentTrack && <AudioPlayerBar track={currentTrack} onClose={() => setCurrentTrack(null)} />}
    </div>
  );
};
