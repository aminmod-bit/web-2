export interface Book {
  id: number;
  title: string;
  titleAr: string;
  author: string;
  authorAr: string;
  category: string;
  categoryAr: string;
  description: string;
  pages: number;
  year: number;
  rating: number;
  downloads: number;
  isFeatured?: boolean;
  isNew?: boolean;
  coverColor: string;
  coverPattern: string;
  tag?: string;
}

export const booksData: Book[] = [
  {
    id: 1,
    title: "Sahih al-Bukhari",
    titleAr: "صحيح البخاري",
    author: "Imam al-Bukhari",
    authorAr: "الإمام البخاري",
    category: "Hadith",
    categoryAr: "حديث",
    description: "أصح كتاب بعد كتاب الله العزيز، جمع فيه الإمام البخاري الأحاديث الصحيحة المسندة",
    pages: 1400,
    year: 256,
    rating: 5.0,
    downloads: 45200,
    isFeatured: true,
    coverColor: "from-emerald-900 to-emerald-700",
    coverPattern: "geometric-1",
    tag: "الأكثر تحميلاً"
  },
  {
    id: 2,
    title: "Sahih Muslim",
    titleAr: "صحيح مسلم",
    author: "Imam Muslim",
    authorAr: "الإمام مسلم",
    category: "Hadith",
    categoryAr: "حديث",
    description: "من أصح كتب الحديث وأجلّها، رتّبه الإمام مسلم على أبواب الفقه",
    pages: 1200,
    year: 261,
    rating: 4.9,
    downloads: 38700,
    isFeatured: true,
    coverColor: "from-teal-900 to-teal-700",
    coverPattern: "geometric-2",
    tag: "كلاسيكي"
  },
  {
    id: 3,
    title: "Minhaj al-Qasideen",
    titleAr: "منهاج القاصدين",
    author: "Ibn Qudama al-Maqdisi",
    authorAr: "ابن قدامة المقدسي",
    category: "Zuhd & Tazkiyah",
    categoryAr: "زهد وتزكية",
    description: "مختصر إحياء علوم الدين، يجمع أسس التزكية والسلوك للمبتدئين والمتقدمين",
    pages: 600,
    year: 620,
    rating: 4.8,
    downloads: 29400,
    isFeatured: true,
    coverColor: "from-amber-900 to-amber-700",
    coverPattern: "geometric-3",
    tag: "مميز"
  },
  {
    id: 4,
    title: "Aqeedah al-Wasitiyya",
    titleAr: "العقيدة الواسطية",
    author: "Ibn Taymiyyah",
    authorAr: "ابن تيمية",
    category: "Aqeedah",
    categoryAr: "عقيدة",
    description: "رسالة في بيان عقيدة أهل السنة والجماعة في الأسماء والصفات",
    pages: 180,
    year: 698,
    rating: 4.9,
    downloads: 33100,
    isNew: true,
    coverColor: "from-green-900 to-green-700",
    coverPattern: "geometric-4",
    tag: "جديد"
  },
  {
    id: 5,
    title: "Zaad al-Ma'ad",
    titleAr: "زاد المعاد",
    author: "Ibn al-Qayyim",
    authorAr: "ابن القيم",
    category: "Seerah",
    categoryAr: "سيرة",
    description: "كتاب جامع في هدي النبي ﷺ في عباداته ومعاملاته وسيرته",
    pages: 1800,
    year: 751,
    rating: 4.9,
    downloads: 41000,
    isFeatured: true,
    coverColor: "from-slate-800 to-slate-600",
    coverPattern: "geometric-1",
    tag: "مرجع"
  },
  {
    id: 6,
    title: "Riyadh al-Saliheen",
    titleAr: "رياض الصالحين",
    author: "Imam al-Nawawi",
    authorAr: "الإمام النووي",
    category: "Hadith",
    categoryAr: "حديث",
    description: "كتاب جامع للأحاديث في الآداب والأخلاق والعبادات والمعاملات",
    pages: 800,
    year: 676,
    rating: 4.8,
    downloads: 52300,
    coverColor: "from-emerald-900 to-teal-800",
    coverPattern: "geometric-2",
    tag: "شائع"
  },
  {
    id: 7,
    title: "Kitab al-Tawhid",
    titleAr: "كتاب التوحيد",
    author: "Muhammad ibn Abd al-Wahhab",
    authorAr: "محمد بن عبد الوهاب",
    category: "Aqeedah",
    categoryAr: "عقيدة",
    description: "أهم مؤلفات الشيخ محمد بن عبد الوهاب في بيان معنى التوحيد وأنواعه",
    pages: 350,
    year: 1206,
    rating: 4.7,
    downloads: 27800,
    isNew: true,
    coverColor: "from-yellow-900 to-yellow-700",
    coverPattern: "geometric-3",
    tag: "جديد"
  },
  {
    id: 8,
    title: "Al-Muwatta",
    titleAr: "موطأ الإمام مالك",
    author: "Imam Malik",
    authorAr: "الإمام مالك",
    category: "Hadith",
    categoryAr: "حديث",
    description: "أقدم كتب الحديث المرتبة، قال الإمام الشافعي: ما بعد كتاب الله أصح من موطأ مالك",
    pages: 750,
    year: 179,
    rating: 4.8,
    downloads: 19500,
    coverColor: "from-stone-800 to-stone-700",
    coverPattern: "geometric-4",
    tag: "تراث"
  }
];

export const categories = [
  { id: 'all', name: 'الكل', nameEn: 'All', count: 248 },
  { id: 'hadith', name: 'حديث', nameEn: 'Hadith', count: 64 },
  { id: 'aqeedah', name: 'عقيدة', nameEn: 'Aqeedah', count: 42 },
  { id: 'fiqh', name: 'فقه', nameEn: 'Fiqh', count: 58 },
  { id: 'tafsir', name: 'تفسير', nameEn: 'Tafsir', count: 31 },
  { id: 'seerah', name: 'سيرة', nameEn: 'Seerah', count: 27 },
  { id: 'zuhd', name: 'زهد وتزكية', nameEn: 'Tazkiyah', count: 26 },
];
