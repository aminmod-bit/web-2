export interface AudioTrack {
  id: number;
  title: string;
  titleAr: string;
  sheikh: string;
  sheikhAr: string;
  category: string;
  categoryAr: string;
  duration: string;
  plays: number;
  isNew?: boolean;
  isFeatured?: boolean;
  gradient: string;
  initials: string;
  description: string;
}

export const audioData: AudioTrack[] = [
  {
    id: 1,
    title: "Explanation of Aqeedah al-Wasitiyya",
    titleAr: "شرح العقيدة الواسطية",
    sheikh: "Sheikh Salih al-Fawzan",
    sheikhAr: "الشيخ صالح الفوزان",
    category: "Aqeedah",
    categoryAr: "عقيدة",
    duration: "48:32",
    plays: 24700,
    isFeatured: true,
    gradient: "from-emerald-800 to-emerald-600",
    initials: "ف",
    description: "شرح مفصّل لعقيدة أهل السنة والجماعة من كتاب ابن تيمية"
  },
  {
    id: 2,
    title: "Tafsir of Surah Al-Fatiha",
    titleAr: "تفسير سورة الفاتحة",
    sheikh: "Sheikh Ibn Uthaymin",
    sheikhAr: "الشيخ ابن عثيمين",
    category: "Tafsir",
    categoryAr: "تفسير",
    duration: "1:12:05",
    plays: 31200,
    isFeatured: true,
    gradient: "from-teal-800 to-teal-600",
    initials: "ع",
    description: "تفسير جامع لأم الكتاب مع بيان فوائدها ومسائلها"
  },
  {
    id: 3,
    title: "The Life of the Prophet ﷺ",
    titleAr: "السيرة النبوية",
    sheikh: "Sheikh al-Albani",
    sheikhAr: "الشيخ الألباني",
    category: "Seerah",
    categoryAr: "سيرة",
    duration: "2:05:18",
    plays: 18900,
    gradient: "from-amber-800 to-amber-600",
    initials: "ل",
    description: "محاضرة في سيرة النبي ﷺ من الميلاد حتى الوفاة"
  },
  {
    id: 4,
    title: "Fundamentals of Hadith Sciences",
    titleAr: "أصول علم الحديث",
    sheikh: "Sheikh Muqbil al-Wadi'i",
    sheikhAr: "الشيخ مقبل الوادعي",
    category: "Hadith",
    categoryAr: "حديث",
    duration: "55:47",
    plays: 14300,
    isNew: true,
    gradient: "from-green-800 to-green-600",
    initials: "و",
    description: "شرح مبسّط لمصطلح الحديث والجرح والتعديل"
  },
  {
    id: 5,
    title: "Heart Softeners",
    titleAr: "الرقائق",
    sheikh: "Sheikh Abd al-Razzaq al-Badr",
    sheikhAr: "الشيخ عبد الرزاق البدر",
    category: "Tazkiyah",
    categoryAr: "تزكية",
    duration: "38:22",
    plays: 22100,
    isFeatured: true,
    gradient: "from-rose-900 to-rose-700",
    initials: "ب",
    description: "دروس في تزكية النفس وتطهير القلب"
  },
  {
    id: 6,
    title: "Conditions of Prayer",
    titleAr: "شروط الصلاة",
    sheikh: "Sheikh Salih al-Fawzan",
    sheikhAr: "الشيخ صالح الفوزان",
    category: "Fiqh",
    categoryAr: "فقه",
    duration: "1:25:10",
    plays: 16800,
    isNew: true,
    gradient: "from-sky-900 to-sky-700",
    initials: "ف",
    description: "بيان شروط صحة الصلاة وأركانها وواجباتها"
  },
];
