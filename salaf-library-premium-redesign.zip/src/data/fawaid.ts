export interface Faida {
  id: number;
  text: string;
  textAr: string;
  source: string;
  sourceAr: string;
  category: string;
  categoryAr: string;
  likes: number;
  isBookmarked?: boolean;
  isPinned?: boolean;
}

export const fawaidData: Faida[] = [
  {
    id: 1,
    text: "Whoever reads Surah Al-Kahf on Friday, a light will shine for him between the two Fridays.",
    textAr: "مَنْ قَرَأَ سُورَةَ الكَهْفِ فِي يَوْمِ الجُمُعَةِ أَضَاءَ لَهُ مِنَ النُّورِ مَا بَيْنَ الجُمُعَتَيْنِ",
    source: "Al-Bayhaqi",
    sourceAr: "البيهقي",
    category: "Quran",
    categoryAr: "قرآن",
    likes: 1240,
    isPinned: true,
    isBookmarked: true,
  },
  {
    id: 2,
    text: "The best of you are those who learn the Quran and teach it.",
    textAr: "خَيْرُكُمْ مَنْ تَعَلَّمَ القُرْآنَ وَعَلَّمَهُ",
    source: "Sahih al-Bukhari",
    sourceAr: "صحيح البخاري",
    category: "Hadith",
    categoryAr: "حديث",
    likes: 2180,
    isPinned: true,
  },
  {
    id: 3,
    text: "The world is cursed, and what is in it is cursed, except the remembrance of Allah, and what is connected to it, and the scholar, and the student.",
    textAr: "الدُّنْيَا مَلْعُونَةٌ مَلْعُونٌ مَا فِيهَا إِلاَّ ذِكْرُ اللَّهِ وَمَا وَالاَهُ وَعَالِمٌ أَوْ مُتَعَلِّمٌ",
    source: "Sunan al-Tirmidhi",
    sourceAr: "سنن الترمذي",
    category: "Hadith",
    categoryAr: "حديث",
    likes: 876,
  },
  {
    id: 4,
    text: "Take advantage of five before five: your youth before your old age, your health before your sickness, your wealth before your poverty, your free time before you become occupied, and your life before your death.",
    textAr: "اغْتَنِمْ خَمْسًا قَبْلَ خَمْسٍ: شَبَابَكَ قَبْلَ هَرَمِكَ، وَصِحَّتَكَ قَبْلَ سَقَمِكَ، وَغِنَاكَ قَبْلَ فَقْرِكَ، وَفَرَاغَكَ قَبْلَ شُغْلِكَ، وَحَيَاتَكَ قَبْلَ مَوْتِكَ",
    source: "Shu'ab al-Iman",
    sourceAr: "شعب الإيمان",
    category: "Wisdom",
    categoryAr: "حكمة",
    likes: 3420,
    isBookmarked: true,
  },
  {
    id: 5,
    text: "Seek knowledge from the cradle to the grave.",
    textAr: "طَلَبُ الْعِلْمِ فَرِيضَةٌ عَلَى كُلِّ مُسْلِمٍ",
    source: "Ibn Majah",
    sourceAr: "ابن ماجه",
    category: "Knowledge",
    categoryAr: "علم",
    likes: 1890,
  },
  {
    id: 6,
    text: "Indeed, Allah does not look at your forms and your wealth, but He looks at your hearts and your deeds.",
    textAr: "إِنَّ اللَّهَ لاَ يَنْظُرُ إِلَى أَجْسَامِكُمْ وَلاَ إِلَى صُوَرِكُمْ وَلَكِنْ يَنْظُرُ إِلَى قُلُوبِكُمْ وَأَعْمَالِكُمْ",
    source: "Sahih Muslim",
    sourceAr: "صحيح مسلم",
    category: "Hadith",
    categoryAr: "حديث",
    likes: 2670,
    isPinned: true,
  },
];
