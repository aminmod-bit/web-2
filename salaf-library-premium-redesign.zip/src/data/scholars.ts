export interface Scholar {
  id: number;
  name: string;
  nameAr: string;
  title: string;
  titleAr: string;
  born: string;
  died: string;
  era: string;
  school: string;
  description: string;
  books: number;
  specialty: string;
  specialtyAr: string;
  gradient: string;
  initials: string;
  isVerified?: boolean;
}

export const scholarsData: Scholar[] = [
  {
    id: 1,
    name: "Ibn Taymiyyah",
    nameAr: "ابن تيمية",
    title: "Shaykh al-Islam",
    titleAr: "شيخ الإسلام",
    born: "661 هـ",
    died: "728 هـ",
    era: "العصر المملوكي",
    school: "حنبلي",
    description: "تقي الدين أبو العباس أحمد بن عبد الحليم بن تيمية الحنبلي، إمام جليل وعالم رباني، له مؤلفات نفيسة في العقيدة والفقه وعلوم القرآن",
    books: 350,
    specialty: "Aqeedah, Fiqh",
    specialtyAr: "عقيدة، فقه",
    gradient: "from-emerald-800 to-emerald-600",
    initials: "ت",
    isVerified: true,
  },
  {
    id: 2,
    name: "Ibn al-Qayyim",
    nameAr: "ابن القيم",
    title: "Imam al-Muhaqqiqeen",
    titleAr: "إمام المحققين",
    born: "691 هـ",
    died: "751 هـ",
    era: "العصر المملوكي",
    school: "حنبلي",
    description: "محمد بن أبي بكر بن أيوب الزرعي الدمشقي، تلميذ ابن تيمية وأعلم أصحابه، صاحب مؤلفات نفيسة في السلوك والعقيدة",
    books: 80,
    specialty: "Tazkiyah, Aqeedah",
    specialtyAr: "تزكية، عقيدة",
    gradient: "from-teal-800 to-teal-600",
    initials: "ق",
    isVerified: true,
  },
  {
    id: 3,
    name: "Imam al-Bukhari",
    nameAr: "الإمام البخاري",
    title: "Amir al-Mu'mineen fil-Hadith",
    titleAr: "أمير المؤمنين في الحديث",
    born: "194 هـ",
    died: "256 هـ",
    era: "العصر العباسي",
    school: "محدّث",
    description: "محمد بن إسماعيل البخاري، إمام المحدثين ومصنف أصح الكتب بعد القرآن الكريم",
    books: 25,
    specialty: "Hadith Sciences",
    specialtyAr: "علوم الحديث",
    gradient: "from-amber-800 to-amber-600",
    initials: "ب",
    isVerified: true,
  },
  {
    id: 4,
    name: "Imam al-Nawawi",
    nameAr: "الإمام النووي",
    title: "Muhyi al-Din",
    titleAr: "محيي الدين",
    born: "631 هـ",
    died: "676 هـ",
    era: "العصر الأيوبي",
    school: "شافعي",
    description: "يحيى بن شرف النووي، إمام حافظ فقيه ومحدث، من أبرز علماء الشافعية",
    books: 60,
    specialty: "Hadith, Fiqh",
    specialtyAr: "حديث، فقه",
    gradient: "from-green-800 to-green-600",
    initials: "ن",
    isVerified: true,
  },
  {
    id: 5,
    name: "Ibn Katheer",
    nameAr: "ابن كثير",
    title: "Al-Hafidh al-Mujtahid",
    titleAr: "الحافظ المجتهد",
    born: "701 هـ",
    died: "774 هـ",
    era: "العصر المملوكي",
    school: "شافعي",
    description: "إسماعيل بن عمر بن كثير القرشي، حافظ مفسر ومؤرخ، صاحب التفسير المشهور وكتاب البداية والنهاية",
    books: 40,
    specialty: "Tafsir, History",
    specialtyAr: "تفسير، تاريخ",
    gradient: "from-slate-700 to-slate-600",
    initials: "ك",
    isVerified: true,
  },
  {
    id: 6,
    name: "Imam Ahmad",
    nameAr: "الإمام أحمد",
    title: "Imam Ahl al-Sunnah",
    titleAr: "إمام أهل السنة",
    born: "164 هـ",
    died: "241 هـ",
    era: "العصر العباسي",
    school: "حنبلي",
    description: "أحمد بن محمد بن حنبل، إمام أهل السنة الذي صبر في المحنة، صاحب المسند الشهير",
    books: 15,
    specialty: "Hadith, Fiqh",
    specialtyAr: "حديث، فقه",
    gradient: "from-yellow-800 to-yellow-700",
    initials: "أ",
    isVerified: true,
  },
];
