import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { BooksPage } from './pages/BooksPage';
import { ScholarsPage } from './pages/ScholarsPage';
import { AudioPage } from './pages/AudioPage';
import { FawaidPage } from './pages/FawaidPage';
import { SearchPage } from './pages/SearchPage';
import { DashboardPage } from './pages/DashboardPage';
import { AdminPage } from './pages/AdminPage';

type Page = 'home' | 'books' | 'scholars' | 'audio' | 'fawaid' | 'search' | 'dashboard' | 'admin';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navigate = (page: string) => {
    setCurrentPage(page as Page);
    setSidebarOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home': return <HomePage onNavigate={navigate} />;
      case 'books': return <BooksPage />;
      case 'scholars': return <ScholarsPage />;
      case 'audio': return <AudioPage />;
      case 'fawaid': return <FawaidPage />;
      case 'search': return <SearchPage onNavigate={navigate} />;
      case 'dashboard': return <DashboardPage />;
      case 'admin': return <AdminPage />;
      default: return <HomePage onNavigate={navigate} />;
    }
  };

  return (
    <div
      className="min-h-screen flex"
      style={{
        background: 'linear-gradient(135deg, #030d07 0%, #071a12 40%, #040e09 70%, #071a12 100%)',
        direction: 'rtl',
      }}
    >
      {/* Background glow effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 0 }}>
        <div className="absolute top-0 right-0 w-96 h-96 rounded-full opacity-5 blur-3xl"
          style={{ background: 'radial-gradient(circle, #d4af37, transparent)' }} />
        <div className="absolute bottom-0 left-0 w-80 h-80 rounded-full opacity-5 blur-3xl"
          style={{ background: 'radial-gradient(circle, #22c55e, transparent)' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 rounded-full opacity-3 blur-3xl"
          style={{ background: 'radial-gradient(circle, #d4af37, transparent)' }} />
      </div>

      {/* Sidebar */}
      <div className="relative z-10 hidden lg:block flex-shrink-0">
        <Sidebar
          currentPage={currentPage}
          onNavigate={navigate}
          isOpen={true}
          onClose={() => setSidebarOpen(false)}
        />
      </div>

      {/* Mobile Sidebar */}
      <div className="lg:hidden">
        <Sidebar
          currentPage={currentPage}
          onNavigate={navigate}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-h-screen overflow-hidden relative z-10">
        <Header
          currentPage={currentPage}
          onMenuToggle={() => setSidebarOpen(!sidebarOpen)}
          onNavigate={navigate}
        />

        <main className="flex-1 overflow-y-auto">
          <div key={currentPage} className="animate-fade-in min-h-full">
            {renderPage()}
          </div>
        </main>

        <Footer onNavigate={navigate} />
      </div>
    </div>
  );
}
